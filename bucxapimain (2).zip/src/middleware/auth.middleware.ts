import type { Request, Response, NextFunction } from "express"
import jwt from "jsonwebtoken"
import { User } from "../models/user"

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: any
    }
  }
}

export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const authHeader = req.headers.authorization

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Authentication required" })
    }

    const token = authHeader.split(" ")[1]

    if (!token) {
      return res.status(401).json({ message: "Authentication required" })
    }

    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || "secret") as { userId: string }

      // Get user from database
      const user = await User.findById(decoded.userId)

      if (!user) {
        return res.status(401).json({ message: "Authentication failed" })
      }

      // Attach user to request
      req.user = user
      next()
    } catch (error) {
      return res.status(401).json({ message: "Authentication failed" })
    }
  } catch (error) {
    next(error)
  }
}

