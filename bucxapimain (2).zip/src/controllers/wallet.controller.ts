import type { Request, Response } from "express"
import { WalletService } from "../wallet/service"
import { Wallet, usdWallet } from "../models/wallet"
import { BridgeService } from "../services/bridge.service"
import { User } from "../models/user"
import logger from "../utils/logger"

export class WalletController {
  /**
   * Get user's wallet information
   */
  async getWallet(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Find wallet with populated references
      const wallet = await Wallet.findOne({ user: user._id }).populate("solWallet").populate("usdWallet")

      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" })
      }

      return res.status(200).json(wallet)
    } catch (error: any) {
      logger.error(`Get wallet error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get wallet" })
    }
  }

  /**
   * Create a new wallet for the user
   */
  async createWallet(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Check if user already has a wallet
      const existingWallet = await Wallet.findOne({ user: user._id })
      if (existingWallet) {
        return res.status(400).json({ message: "User already has a wallet" })
      }

      const wallet = await WalletService.createWallet({ userId: user._id })

      return res.status(201).json({
        message: "Wallet created successfully",
        walletId: wallet._id,
      })
    } catch (error: any) {
      logger.error(`Create wallet error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create wallet" })
    }
  }

  /**
   * Create a USD wallet for the user
   */
  async createUsdWallet(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Check if user has a Solana wallet
      const wallet = await Wallet.findOne({ user: user._id }).populate("solWallet")
      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found. Please create a wallet first." })
      }

      if (!wallet.solWallet) {
        return res.status(400).json({ message: "Solana wallet not found" })
      }

      // Check if user already has a USD wallet
      if (wallet.usdWallet) {
        return res.status(400).json({ message: "User already has a USD wallet" })
      }

      const solWalletDoc = wallet.solWallet as any
      const usdWalletDoc = await WalletService.createUsdWallet({
        user: user._id,
        solAddress: solWalletDoc.address,
      })

      return res.status(201).json({
        message: "USD wallet created successfully",
        walletId: usdWalletDoc._id,
      })
    } catch (error: any) {
      logger.error(`Create USD wallet error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create USD wallet" })
    }
  }

  /**
   * Get deposit instructions for USD wallet
   */
  async getDepositInstructions(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Find wallet with populated references
      const wallet = await Wallet.findOne({ user: user._id }).populate("usdWallet")

      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" })
      }

      if (!wallet.usdWallet) {
        return res.status(404).json({ message: "USD wallet not found" })
      }

      const usdWalletDoc = wallet.usdWallet as any

      return res.status(200).json({
        depositInstructions: usdWalletDoc.source_deposit_instructions,
      })
    } catch (error: any) {
      logger.error(`Get deposit instructions error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get deposit instructions" })
    }
  }

  /**
   * Initiate a transfer from USD to USDC
   */
  async initiateTransfer(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { amount } = req.body

      if (!amount) {
        return res.status(400).json({ message: "Amount is required" })
      }

      // Find user's Bridge customer ID
      const userDoc = await User.findById(user._id)
      if (!userDoc || !userDoc.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID. Please onboard the user first.",
        })
      }

      // Find wallet with populated references
      const wallet = await Wallet.findOne({ user: user._id }).populate("solWallet").populate("usdWallet")

      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" })
      }

      if (!wallet.usdWallet) {
        return res.status(404).json({ message: "USD wallet not found" })
      }

      if (!wallet.solWallet) {
        return res.status(404).json({ message: "Solana wallet not found" })
      }

      const usdWalletDoc = wallet.usdWallet as any
      const solWalletDoc = wallet.solWallet as any

      // Create transfer request
      const transferData = {
        amount: amount.toString(),
        on_behalf_of: userDoc.bridgeCustomerId,
        source: {
          payment_rail: "ach",
          currency: "usd",
        },
        destination: {
          payment_rail: "solana",
          currency: "usdc",
          to_address: solWalletDoc.address,
        },
      }

      const transfer = await BridgeService.createTransfer(transferData)

      return res.status(201).json({
        message: "Transfer initiated successfully",
        transferId: transfer.id,
        status: transfer.status,
      })
    } catch (error: any) {
      logger.error(`Initiate transfer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to initiate transfer" })
    }
  }

  /**
   * Update wallet with virtual account information
   */
  async updateVirtualAccount(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { virtualAccountId } = req.body

      if (!virtualAccountId) {
        return res.status(400).json({ message: "Virtual account ID is required" })
      }

      // Find wallet with populated references
      const wallet = await Wallet.findOne({ user: user._id })

      if (!wallet) {
        return res.status(404).json({ message: "Wallet not found" })
      }

      // Get virtual account details from Bridge
      let virtualAccount
      try {
        // Enable mock mode for testing if needed
        if (req.query.mock === "true") {
          process.env.USE_MOCKS = "true"
          logger.info("Enabling mock mode for this request")
        }

        // Get the user's Bridge customer ID
        const userDoc = await User.findById(user._id)
        if (!userDoc || !userDoc.bridgeCustomerId) {
          return res.status(400).json({
            message: "User does not have a Bridge customer ID. Please onboard the user first.",
          })
        }

        // Get virtual account details
        const virtualAccounts = await BridgeService.getVirtualAccounts(userDoc.bridgeCustomerId)

        // Reset mock mode
        if (req.query.mock === "true") {
          process.env.USE_MOCKS = "false"
        }

        // Find the specific virtual account
        virtualAccount = virtualAccounts.data.find((account: any) => account.id === virtualAccountId)

        if (!virtualAccount) {
          return res.status(404).json({ message: "Virtual account not found" })
        }
      } catch (error: any) {
        logger.error(`Get virtual account error: ${error.message}`)
        return res.status(500).json({ message: error.message || "Failed to get virtual account" })
      }

      // Create or update USD wallet
      let usdWalletDoc
      if (wallet.usdWallet) {
        // Update existing USD wallet
        usdWalletDoc = await usdWallet.findByIdAndUpdate(
          wallet.usdWallet,
          {
            wid: virtualAccount.id,
            status: virtualAccount.status,
            customer_id: virtualAccount.customer_id,
            source_deposit_instructions: virtualAccount.source_deposit_instructions,
            destination: virtualAccount.destination,
            developer_fee_percent: virtualAccount.developer_fee_percent,
          },
          { new: true },
        )
      } else {
        // Create new USD wallet
        usdWalletDoc = await usdWallet.create({
          user: user._id,
          wid: virtualAccount.id,
          status: virtualAccount.status,
          customer_id: virtualAccount.customer_id,
          source_deposit_instructions: virtualAccount.source_deposit_instructions,
          destination: virtualAccount.destination,
          developer_fee_percent: virtualAccount.developer_fee_percent,
        })

        // Update wallet with USD wallet reference
        wallet.usdWallet = usdWalletDoc._id
        await wallet.save()
      }

      return res.status(200).json({
        message: "Wallet updated with virtual account successfully",
        usdWallet: usdWalletDoc,
      })
    } catch (error: any) {
      logger.error(`Update virtual account error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to update virtual account" })
    }
  }
}

