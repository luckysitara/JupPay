-- Seed Nigerian states
INSERT INTO states (code, name) VALUES
('AB', 'Abuja'),
('AD', 'Adamawa'),
('AK', 'Akwa Ibom'),
('AN', 'Anambra'),
('BA', 'Bauchi'),
('BY', 'Bayelsa'),
('BE', 'Benue'),
('BO', 'Borno'),
('CR', 'Cross River'),
('DE', 'Delta'),
('EB', 'Ebonyi'),
('ED', 'Edo'),
('EK', 'Ekiti'),
('EN', 'Enugu'),
('GO', 'Gombe'),
('IM', 'Imo'),
('JI', 'Jigawa'),
('KD', 'Kaduna'),
('KN', 'Kano'),
('KT', 'Katsina'),
('KE', 'Kebbi'),
('KO', 'Kogi'),
('KW', 'Kwara'),
('LA', 'Lagos'),
('NA', 'Nasarawa'),
('NI', 'Niger'),
('OG', 'Ogun'),
('ON', 'Ondo'),
('OS', 'Osun'),
('OY', 'Oyo'),
('PL', 'Plateau'),
('RI', 'Rivers'),
('SO', 'Sokoto'),
('TA', 'Taraba'),
('YO', 'Yobe'),
('ZA', 'Zamfara');

-- Seed admin users
INSERT INTO admin_users (email, name, role, state) VALUES
('admin@nigerianxp.com', 'Super Admin', 'SUPER_ADMIN', NULL),
('lagos@nigerianxp.com', 'Lagos Admin', 'STATE_ADMIN', 'LA'),
('abuja@nigerianxp.com', 'Abuja Admin', 'STATE_ADMIN', 'AB'),
('rivers@nigerianxp.com', 'Rivers Admin', 'STATE_ADMIN', 'RI');

-- Seed users
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at) VALUES
('Oluwaseun Adebayo', 'seun_adebayo', 'LA', 26866, 700, ARRAY['Operations', 'Strategy', 'Development'], '2022-01-15T00:00:00Z'),
('Chioma Okonkwo', 'chioma_o', 'AB', 23965, 650, ARRAY['Operations', 'Strategy', 'Writing'], '2022-02-20T00:00:00Z'),
('Emeka Nwosu', 'emeka_n', 'EN', 23191, 800, ARRAY['Development', 'Operations', 'Strategy', 'Design'], '2022-03-10T00:00:00Z'),
('Amina Ibrahim', 'amina_i', 'KN', 21412, 500, ARRAY['Development', 'Operations'], '2022-04-05T00:00:00Z'),
('Tunde Bakare', 'tunde_b', 'OY', 20910, 750, ARRAY['Operations', 'Strategy', 'Writing'], '2022-05-12T00:00:00Z'),
('Ngozi Okafor', 'ngozi_o', 'IM', 19500, 600, ARRAY['Development', 'Design'], '2022-06-18T00:00:00Z'),
('Yusuf Mohammed', 'yusuf_m', 'KD', 18200, 450, ARRAY['Strategy', 'Operations'], '2022-07-22T00:00:00Z'),
('Blessing Eze', 'blessing_e', 'RI', 17800, 550, ARRAY['Writing', 'Strategy'], '2022-08-30T00:00:00Z'),
('Ibrahim Musa', 'ibrahim_m', 'KN', 16500, 400, ARRAY['Development', 'Operations'], '2022-09-15T00:00:00Z'),
('Folake Adeleke', 'folake_a', 'LA', 15900, 600, ARRAY['Design', 'Writing'], '2022-10-05T00:00:00Z'),
('Chinedu Eze', 'chinedu_e', 'EN', 15200, 350, ARRAY['Development', 'Strategy'], '2022-11-12T00:00:00Z'),
('Fatima Abubakar', 'fatima_a', 'KD', 14800, 500, ARRAY['Operations', 'Writing'], '2022-12-20T00:00:00Z');

-- Seed some XP transactions
DO $$
DECLARE
  user_id UUID;
  admin_id UUID;
BEGIN
  -- Get the first user ID
  SELECT id INTO user_id FROM users WHERE username = 'seun_adebayo' LIMIT 1;
  
  -- Get the super admin ID
  SELECT id INTO admin_id FROM admin_users WHERE role = 'SUPER_ADMIN' LIMIT 1;
  
  -- Insert transaction if both IDs exist
  IF user_id IS NOT NULL AND admin_id IS NOT NULL THEN
    INSERT INTO xp_transactions (user_id, admin_id, amount, reason, skills, created_at)
    VALUES (
      user_id,
      admin_id,
      500,
      'Initial contribution to Project Alpha',
      ARRAY['Development'],
      (SELECT joined_at + interval '1 week' FROM users WHERE id = user_id)
    );
  END IF;
  
  -- Get another user ID
  SELECT id INTO user_id FROM users WHERE username = 'chioma_o' LIMIT 1;
  
  -- Get a state admin ID for Abuja
  SELECT id INTO admin_id FROM admin_users WHERE state = 'AB' LIMIT 1;
  
  -- Insert transaction if both IDs exist
  IF user_id IS NOT NULL AND admin_id IS NOT NULL THEN
    INSERT INTO xp_transactions (user_id, admin_id, amount, reason, skills, created_at)
    VALUES (
      user_id,
      admin_id,
      300,
      'Documentation for Project Beta',
      ARRAY['Writing'],
      (SELECT joined_at + interval '2 weeks' FROM users WHERE id = user_id)
    );
  END IF;
  
  -- Get another user ID
  SELECT id INTO user_id FROM users WHERE username = 'emeka_n' LIMIT 1;
  
  -- Get the super admin ID again
  SELECT id INTO admin_id FROM admin_users WHERE role = 'SUPER_ADMIN' LIMIT 1;
  
  -- Insert transaction if both IDs exist
  IF user_id IS NOT NULL AND admin_id IS NOT NULL THEN
    INSERT INTO xp_transactions (user_id, admin_id, amount, reason, skills, created_at)
    VALUES (
      user_id,
      admin_id,
      700,
      'Backend development for Project Gamma',
      ARRAY['Development'],
      NOW() - interval '1 week'
    );
  END IF;
END $$;

