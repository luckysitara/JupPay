-- Add secret_key column to admin_users table if it doesn't exist
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT FROM information_schema.columns 
        WHERE table_name = 'admin_users' AND column_name = 'secret_key'
    ) THEN
        ALTER TABLE admin_users ADD COLUMN secret_key TEXT NOT NULL DEFAULT md5(random()::text);
    END IF;
END $$;

-- Update existing admin users with unique secret keys
UPDATE admin_users 
SET secret_key = md5(id::text || now()::text)
WHERE secret_key = md5(random()::text);

-- Create index for faster lookups by secret key
CREATE INDEX IF NOT EXISTS idx_admin_users_secret_key ON admin_users(secret_key);

-- Add constraint to ensure secret keys are unique
ALTER TABLE admin_users 
DROP CONSTRAINT IF EXISTS admin_users_secret_key_key;

ALTER TABLE admin_users 
ADD CONSTRAINT admin_users_secret_key_key UNIQUE (secret_key);

