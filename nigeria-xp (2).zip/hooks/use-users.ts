"use client"

import { useState, useEffect } from "react"
import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { User } from "@/types"

// Mock data as fallback if database connection fails
const mockUsers: User[] = [
  {
    id: "1",
    name: "Oluwaseun Adebayo",
    username: "seun_adebayo",
    state: "LA",
    stateName: "Lagos",
    totalXp: 26866,
    monthlyXp: 700,
    skills: ["Operations", "Strategy", "Development"],
    joinedAt: new Date("2022-01-15T00:00:00Z"),
  },
  {
    id: "2",
    name: "Chioma Okonkwo",
    username: "chioma_o",
    state: "AB",
    stateName: "Abuja",
    totalXp: 23965,
    monthlyXp: 650,
    skills: ["Operations", "Strategy", "Writing"],
    joinedAt: new Date("2022-02-20T00:00:00Z"),
  },
  {
    id: "3",
    name: "Emeka Nwosu",
    username: "emeka_n",
    state: "EN",
    stateName: "Enugu",
    totalXp: 23191,
    monthlyXp: 800,
    skills: ["Development", "Operations", "Strategy", "Design"],
    joinedAt: new Date("2022-03-10T00:00:00Z"),
  },
  {
    id: "4",
    name: "Amina Ibrahim",
    username: "amina_i",
    state: "KN",
    stateName: "Kano",
    totalXp: 21412,
    monthlyXp: 500,
    skills: ["Development", "Operations"],
    joinedAt: new Date("2022-04-05T00:00:00Z"),
  },
  {
    id: "5",
    name: "Tunde Bakare",
    username: "tunde_b",
    state: "OY",
    stateName: "Oyo",
    totalXp: 20910,
    monthlyXp: 750,
    skills: ["Operations", "Strategy", "Writing"],
    joinedAt: new Date("2022-05-12T00:00:00Z"),
  },
  {
    id: "6",
    name: "Ngozi Okafor",
    username: "ngozi_o",
    state: "IM",
    stateName: "Imo",
    totalXp: 19500,
    monthlyXp: 600,
    skills: ["Development", "Design"],
    joinedAt: new Date("2022-06-18T00:00:00Z"),
  },
  {
    id: "7",
    name: "Yusuf Mohammed",
    username: "yusuf_m",
    state: "KD",
    stateName: "Kaduna",
    totalXp: 18200,
    monthlyXp: 450,
    skills: ["Strategy", "Operations"],
    joinedAt: new Date("2022-07-22T00:00:00Z"),
  },
  {
    id: "8",
    name: "Blessing Eze",
    username: "blessing_e",
    state: "RI",
    stateName: "Rivers",
    totalXp: 17800,
    monthlyXp: 550,
    skills: ["Writing", "Strategy"],
    joinedAt: new Date("2022-08-30T00:00:00Z"),
  },
  {
    id: "9",
    name: "Ibrahim Musa",
    username: "ibrahim_m",
    state: "KN",
    stateName: "Kano",
    totalXp: 16500,
    monthlyXp: 400,
    skills: ["Development", "Operations"],
    joinedAt: new Date("2022-09-15T00:00:00Z"),
  },
  {
    id: "10",
    name: "Folake Adeleke",
    username: "folake_a",
    state: "LA",
    stateName: "Lagos",
    totalXp: 15900,
    monthlyXp: 600,
    skills: ["Design", "Writing"],
    joinedAt: new Date("2022-10-05T00:00:00Z"),
  },
  {
    id: "11",
    name: "Chinedu Eze",
    username: "chinedu_e",
    state: "EN",
    stateName: "Enugu",
    totalXp: 15200,
    monthlyXp: 350,
    skills: ["Development", "Strategy"],
    joinedAt: new Date("2022-11-12T00:00:00Z"),
  },
  {
    id: "12",
    name: "Fatima Abubakar",
    username: "fatima_a",
    state: "KD",
    stateName: "Kaduna",
    totalXp: 14800,
    monthlyXp: 500,
    skills: ["Operations", "Writing"],
    joinedAt: new Date("2022-12-20T00:00:00Z"),
  },
]

export function useUsers() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => {
      setMounted(false)
    }
  }, [])

  useEffect(() => {
    let isMounted = true

    async function fetchUsers() {
      try {
        if (!isMounted) return

        setLoading(true)

        // Check if Supabase is configured
        if (!isSupabaseConfigured()) {
          console.warn("Supabase is not configured. Using mock data instead.")
          if (isMounted) {
            setUsers(mockUsers)
          }
          return
        }

        // Try to fetch from Supabase
        const { data, error: supabaseError } = await supabase
          .from("users_with_state")
          .select("*")
          .order("total_xp", { ascending: false })

        if (!isMounted) return

        if (supabaseError) {
          console.error("Supabase error:", supabaseError)
          // Fall back to mock data if there's an error
          setUsers(mockUsers)
        } else if (data && data.length > 0) {
          // Transform the data to match our User type
          const transformedUsers: User[] = data.map((user) => ({
            id: user.id,
            name: user.name,
            username: user.username,
            state: user.state,
            stateName: user.state_name,
            totalXp: user.total_xp,
            monthlyXp: user.monthly_xp,
            skills: user.skills,
            joinedAt: new Date(user.joined_at),
          }))
          setUsers(transformedUsers)
        } else {
          // If no data, use mock data
          setUsers(mockUsers)
        }
      } catch (err) {
        console.error("Error fetching users:", err)
        if (isMounted) {
          setError(err instanceof Error ? err : new Error("Failed to fetch users"))
          // Fall back to mock data
          setUsers(mockUsers)
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    if (mounted) {
      fetchUsers()
    }

    return () => {
      isMounted = false
    }
  }, [mounted])

  return { users, loading, error }
}

