"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { AdminManagement } from "@/components/admin/admin-management"
import { supabase } from "@/lib/database"
import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  created_at: string
}

export default function SettingsPage() {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const getAdminUser = async () => {
      try {
        // Get admin user from cookie
        const adminCookie = document.cookie.split("; ").find((row) => row.startsWith("adminUser="))

        if (!adminCookie) {
          setError("Not authenticated")
          return
        }

        const adminUserData = JSON.parse(adminCookie.split("=")[1])

        // Fetch the latest admin data from the database
        const { data, error } = await supabase.from("admin_users").select("*").eq("id", adminUserData.id).single()

        if (error) {
          throw error
        }

        setAdminUser(data as AdminUser)
      } catch (err) {
        console.error("Error fetching admin user:", err)
        setError("Failed to load admin data")
      } finally {
        setLoading(false)
      }
    }

    getAdminUser()
  }, [])

  if (loading) {
    return <SettingsSkeleton />
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mt-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  // Only super admins can access this page
  if (adminUser?.role !== "super_admin") {
    return (
      <Alert variant="destructive" className="mt-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>You don't have permission to access this page</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Settings</h2>
        <p className="text-muted-foreground">Manage system settings and administrators</p>
      </div>

      <Tabs defaultValue="admins" className="space-y-4">
        <TabsList>
          <TabsTrigger value="admins">Admin Management</TabsTrigger>
          <TabsTrigger value="system">System Settings</TabsTrigger>
        </TabsList>
        <TabsContent value="admins" className="space-y-4">
          <AdminManagement />
        </TabsContent>
        <TabsContent value="system" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>System Settings</CardTitle>
              <CardDescription>Configure global system settings</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">System settings will be available in a future update.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

function SettingsSkeleton() {
  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <Skeleton className="h-8 w-[150px]" />
        <Skeleton className="h-4 w-[300px]" />
      </div>

      <div className="space-y-4">
        <Skeleton className="h-10 w-[200px]" />

        <Card>
          <CardHeader>
            <Skeleton className="h-5 w-[180px]" />
            <Skeleton className="h-4 w-[250px]" />
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Array(3)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                    <div>
                      <Skeleton className="h-5 w-[150px]" />
                      <Skeleton className="h-4 w-[200px] mt-1" />
                      <Skeleton className="h-4 w-[100px] mt-1" />
                    </div>
                    <div className="flex items-center space-x-2">
                      <Skeleton className="h-9 w-[150px]" />
                      <Skeleton className="h-9 w-9" />
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

