"use client"

import { useState, useEffect } from "react"
import { getAdminUser } from "@/lib/auth"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import type { Project, User } from "@/types"

const formSchema = z.object({
  userId: z.string().min(1, "User is required"),
  points: z.coerce.number().positive("Points must be positive").int("Points must be a whole number"),
  reason: z.string().min(5, "Reason must be at least 5 characters"),
})

type FormValues = z.infer<typeof formSchema>

interface AdminAssignProjectPointsDialogProps {
  project: Project
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function AdminAssignProjectPointsDialog({
  project,
  open,
  onOpenChange,
  onSuccess,
}: AdminAssignProjectPointsDialogProps) {
  const [submitting, setSubmitting] = useState(false)
  const [users, setUsers] = useState<User[]>([])
  const [loadingUsers, setLoadingUsers] = useState(true)
  const { toast } = useToast()
  const admin = getAdminUser()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      userId: "",
      points: 0,
      reason: "",
    },
  })

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoadingUsers(true)

        let query = supabase.from("users_with_state").select("*").order("name")

        // If state admin, filter by state
        if (admin?.role === "STATE_ADMIN" && admin.state) {
          query = query.eq("state", admin.state)
        }

        const { data, error } = await query

        if (error) throw error

        if (data) {
          const transformedUsers: User[] = data.map((user) => ({
            id: user.id,
            name: user.name,
            username: user.username,
            state: user.state,
            stateName: user.state_name,
            totalXp: user.total_xp,
            monthlyXp: user.monthly_xp,
            skills: user.skills,
            joinedAt: new Date(user.joined_at),
          }))
          setUsers(transformedUsers)
        }
      } catch (error) {
        console.error("Error fetching users:", error)
      } finally {
        setLoadingUsers(false)
      }
    }

    if (open) {
      fetchUsers()
    }
  }, [open, admin])

  async function onSubmit(values: FormValues) {
    if (!admin) {
      toast({
        title: "Error",
        description: "You must be logged in to assign points",
        variant: "destructive",
      })
      return
    }

    try {
      setSubmitting(true)

      // Insert project contribution
      const { error: insertError } = await supabase.from("project_contributions").insert({
        project_id: project.id,
        user_id: values.userId,
        admin_id: admin.id,
        points: values.points,
        reason: values.reason,
      })

      if (insertError) throw insertError

      // Also add XP to the user
      const { error: xpError } = await supabase.from("xp_transactions").insert({
        user_id: values.userId,
        admin_id: admin.id,
        amount: values.points,
        reason: `Project contribution: ${project.name} - ${values.reason}`,
        skills: [],
      })

      if (xpError) throw xpError

      toast({
        title: "Points Assigned",
        description: `${values.points} points assigned to project ${project.name}`,
      })

      // Reset form and close dialog
      form.reset()
      onOpenChange(false)

      // Refresh projects list
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error("Error assigning points:", error)
      toast({
        title: "Error",
        description: "Failed to assign points. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Assign Points to {project.name}</DialogTitle>
          <DialogDescription>Award points for user contributions to this project</DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="userId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>User</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a user" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {loadingUsers ? (
                        <div className="flex items-center justify-center p-2">Loading users...</div>
                      ) : (
                        users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.name} (@{user.username})
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="points"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Points</FormLabel>
                  <FormControl>
                    <Input type="number" min="1" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the contribution" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Assigning..." : "Assign Points"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

