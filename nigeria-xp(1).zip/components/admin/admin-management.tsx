"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { supabase } from "@/lib/database"
import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle, Plus, Eye, EyeOff, Trash2 } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { generateSecureKey } from "@/lib/auth"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  secret_key: string
  created_at: string
}

export function AdminManagement() {
  const [admins, setAdmins] = useState<AdminUser[]>([])
  const [states, setStates] = useState<{ code: string; name: string }[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [showSecretKey, setShowSecretKey] = useState<Record<string, boolean>>({})
  const [isAddingAdmin, setIsAddingAdmin] = useState(false)
  const [newAdmin, setNewAdmin] = useState({
    name: "",
    email: "",
    role: "state_admin" as const,
    state_code: "",
  })
  const [addError, setAddError] = useState<string | null>(null)
  const [addSuccess, setAddSuccess] = useState<string | null>(null)

  useEffect(() => {
    const fetchAdmins = async () => {
      try {
        // Get all admins
        const { data: adminsData, error: adminsError } = await supabase
          .from("admin_users")
          .select("*")
          .order("created_at", { ascending: false })

        if (adminsError) {
          throw adminsError
        }

        // Get all states for the dropdown
        const { data: statesData, error: statesError } = await supabase
          .from("states")
          .select("code, name")
          .order("name")

        if (statesError) {
          throw statesError
        }

        setAdmins(adminsData as AdminUser[])
        setStates(statesData as { code: string; name: string }[])
      } catch (error) {
        console.error("Error fetching admins:", error)
        setError("Failed to load admin users")
      } finally {
        setLoading(false)
      }
    }

    fetchAdmins()
  }, [])

  const handleAddAdmin = async () => {
    setAddError(null)
    setAddSuccess(null)

    try {
      // Validate inputs
      if (!newAdmin.name || !newAdmin.email) {
        setAddError("Name and email are required")
        return
      }

      if (newAdmin.role === "state_admin" && !newAdmin.state_code) {
        setAddError("State is required for state admins")
        return
      }

      // Generate a secure key
      const secretKey = generateSecureKey()

      // Add the new admin
      const { data, error } = await supabase
        .from("admin_users")
        .insert({
          name: newAdmin.name,
          email: newAdmin.email,
          role: newAdmin.role,
          state_code: newAdmin.role === "state_admin" ? newAdmin.state_code : null,
          secret_key: secretKey,
        })
        .select()

      if (error) {
        throw error
      }

      // Add to the list
      if (data && data.length > 0) {
        setAdmins([data[0] as AdminUser, ...admins])
        setAddSuccess(`Admin added successfully! Secret key: ${secretKey}`)

        // Reset form
        setNewAdmin({
          name: "",
          email: "",
          role: "state_admin",
          state_code: "",
        })

        // Show the secret key
        setShowSecretKey({ ...showSecretKey, [data[0].id]: true })
      }
    } catch (error) {
      console.error("Error adding admin:", error)
      setAddError("Failed to add admin user")
    }
  }

  const handleDeleteAdmin = async (adminId: string) => {
    try {
      const { error } = await supabase.from("admin_users").delete().eq("id", adminId)

      if (error) {
        throw error
      }

      // Remove from the list
      setAdmins(admins.filter((admin) => admin.id !== adminId))
    } catch (error) {
      console.error("Error deleting admin:", error)
      setError("Failed to delete admin user")
    }
  }

  const toggleShowSecretKey = (adminId: string) => {
    setShowSecretKey({
      ...showSecretKey,
      [adminId]: !showSecretKey[adminId],
    })
  }

  if (loading) {
    return <AdminManagementSkeleton />
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle>Admin Users</CardTitle>
          <CardDescription>Manage administrator accounts</CardDescription>
        </div>
        <Dialog open={isAddingAdmin} onOpenChange={setIsAddingAdmin}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Admin
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add New Admin</DialogTitle>
              <DialogDescription>
                Create a new administrator account. The secret key will be generated automatically.
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  value={newAdmin.name}
                  onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })}
                  placeholder="Full Name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  value={newAdmin.email}
                  onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })}
                  placeholder="email@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select
                  value={newAdmin.role}
                  onValueChange={(value) => setNewAdmin({ ...newAdmin, role: value as "super_admin" | "state_admin" })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="super_admin">Super Admin</SelectItem>
                    <SelectItem value="state_admin">State Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {newAdmin.role === "state_admin" && (
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select
                    value={newAdmin.state_code}
                    onValueChange={(value) => setNewAdmin({ ...newAdmin, state_code: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state) => (
                        <SelectItem key={state.code} value={state.code}>
                          {state.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              {addError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{addError}</AlertDescription>
                </Alert>
              )}

              {addSuccess && (
                <Alert variant="default" className="bg-green-50 text-green-800 border-green-200">
                  <AlertDescription>{addSuccess}</AlertDescription>
                </Alert>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddingAdmin(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddAdmin}>Add Admin</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          {admins.map((admin) => (
            <div key={admin.id} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
              <div>
                <p className="font-medium">{admin.name}</p>
                <p className="text-sm text-muted-foreground">{admin.email}</p>
                <div className="flex items-center mt-1">
                  <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                    {admin.role === "super_admin" ? "Super Admin" : "State Admin"}
                  </span>
                  {admin.role === "state_admin" && admin.state_code && (
                    <span className="text-xs bg-muted ml-2 px-2 py-0.5 rounded-full">
                      {states.find((s) => s.code === admin.state_code)?.name || admin.state_code}
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <div className="relative">
                  <Input
                    type={showSecretKey[admin.id] ? "text" : "password"}
                    value={admin.secret_key}
                    readOnly
                    className="w-40 pr-8 text-xs"
                  />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0 h-full"
                    onClick={() => toggleShowSecretKey(admin.id)}
                  >
                    {showSecretKey[admin.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </Button>
                </div>

                <Button variant="destructive" size="icon" onClick={() => handleDeleteAdmin(admin.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          ))}

          {admins.length === 0 && <p className="text-sm text-muted-foreground">No admin users found</p>}
        </div>
      </CardContent>
    </Card>
  )
}

function AdminManagementSkeleton() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <Skeleton className="h-5 w-[120px]" />
          <Skeleton className="h-4 w-[200px] mt-1" />
        </div>
        <Skeleton className="h-9 w-[100px]" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {Array(5)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="flex items-center justify-between border-b pb-4 last:border-0 last:pb-0">
                <div>
                  <Skeleton className="h-5 w-[150px]" />
                  <Skeleton className="h-4 w-[200px] mt-1" />
                  <Skeleton className="h-4 w-[100px] mt-1" />
                </div>
                <div className="flex items-center space-x-2">
                  <Skeleton className="h-9 w-[150px]" />
                  <Skeleton className="h-9 w-9" />
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  )
}

