import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { AdminUser } from "@/types"

export async function authenticateWithSecretKey(secretKey: string): Promise<{
  user: AdminUser | null
  error: Error | null
}> {
  try {
    // Validate input
    if (!secretKey || secretKey.trim() === "") {
      return { user: null, error: new Error("Secret key is required") }
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      console.warn("Supabase is not configured. Authentication will not work properly.")
      return { user: null, error: new Error("Database not configured. Please set up Supabase environment variables.") }
    }

    // Query the admin_users table for the secret key
    const { data, error } = await supabase.from("admin_users").select("*").eq("secret_key", secretKey).single()

    if (error) {
      console.error("Authentication error:", error)
      return { user: null, error: new Error("Invalid secret key") }
    }

    if (!data) {
      return { user: null, error: new Error("Admin not found") }
    }

    // Transform to AdminUser type
    const adminUser: AdminUser = {
      id: data.id,
      email: data.email,
      name: data.name,
      role: data.role,
      state: data.state,
      secret_key: data.secret_key,
    }

    // Store the admin user in localStorage for persistence
    localStorage.setItem("adminUser", JSON.stringify(adminUser))

    return { user: adminUser, error: null }
  } catch (err) {
    console.error("Authentication error:", err)
    return { user: null, error: err instanceof Error ? err : new Error("Authentication failed") }
  }
}

export function getAdminUser(): AdminUser | null {
  if (typeof window === "undefined") return null

  const adminUserJson = localStorage.getItem("adminUser")
  if (!adminUserJson) return null

  try {
    return JSON.parse(adminUserJson) as AdminUser
  } catch {
    return null
  }
}

export function logout() {
  if (typeof window === "undefined") return
  localStorage.removeItem("adminUser")
}

export function isAuthenticated(): boolean {
  return getAdminUser() !== null
}

export function isStateAdmin(stateCode?: string): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "STATE_ADMIN" && (!stateCode || admin.state === stateCode)
}

export function isSuperAdmin(): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "SUPER_ADMIN"
}

