import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { AdminUser } from "@/types"

// Update the authenticateWithSecretKey function to handle errors better
export async function authenticateWithSecretKey(secretKey: string): Promise<{
  user: AdminUser | null
  error: Error | null
}> {
  try {
    // Validate input
    if (!secretKey || secretKey.trim() === "") {
      return { user: null, error: new Error("Secret key is required") }
    }

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      console.warn("Supabase is not configured. Using mock authentication.")

      // For demo purposes, allow a special key for testing
      if (secretKey === "demo-super-admin") {
        const mockAdmin: AdminUser = {
          id: "mock-super-admin-id",
          email: "admin@superteamng.com",
          name: "Demo Super Admin",
          role: "SUPER_ADMIN",
          state: null,
          secret_key: "demo-super-admin",
        }

        localStorage.setItem("adminUser", JSON.stringify(mockAdmin))
        return { user: mockAdmin, error: null }
      }

      if (secretKey === "demo-lagos-admin") {
        const mockAdmin: AdminUser = {
          id: "mock-state-admin-id",
          email: "lagos@superteamng.com",
          name: "Demo Lagos Admin",
          role: "STATE_ADMIN",
          state: "LA",
          secret_key: "demo-lagos-admin",
        }

        localStorage.setItem("adminUser", JSON.stringify(mockAdmin))
        return { user: mockAdmin, error: null }
      }

      return {
        user: null,
        error: new Error("Invalid secret key. For demo, use 'demo-super-admin' or 'demo-lagos-admin'"),
      }
    }

    // Query the admin_users table for the secret key
    const { data, error } = await supabase.from("admin_users").select("*").eq("secret_key", secretKey).single()

    if (error) {
      console.error("Authentication error:", error)
      return { user: null, error: new Error("Invalid secret key") }
    }

    if (!data) {
      return { user: null, error: new Error("Admin not found") }
    }

    // Transform to AdminUser type
    const adminUser: AdminUser = {
      id: data.id,
      email: data.email,
      name: data.name,
      role: data.role,
      state: data.state,
      secret_key: data.secret_key,
    }

    // Store the admin user in localStorage for persistence
    localStorage.setItem("adminUser", JSON.stringify(adminUser))

    return { user: adminUser, error: null }
  } catch (err) {
    console.error("Authentication error:", err)
    return { user: null, error: err instanceof Error ? err : new Error("Authentication failed") }
  }
}

export function getAdminUser(): AdminUser | null {
  if (typeof window === "undefined") return null

  const adminUserJson = localStorage.getItem("adminUser")
  if (!adminUserJson) return null

  try {
    return JSON.parse(adminUserJson) as AdminUser
  } catch {
    return null
  }
}

export function logout() {
  if (typeof window === "undefined") return

  // Clear localStorage
  localStorage.removeItem("adminUser")

  // Clear cookie
  document.cookie = "adminUser=; path=/; max-age=0; SameSite=Strict"
}

export function isAuthenticated(): boolean {
  return getAdminUser() !== null
}

export function isStateAdmin(stateCode?: string): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "STATE_ADMIN" && (!stateCode || admin.state === stateCode)
}

export function isSuperAdmin(): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "SUPER_ADMIN"
}

