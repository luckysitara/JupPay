"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { authenticateWithSecretKey } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Lock, Info } from "lucide-react"
// Add import for the debug component
import { DebugConnection } from "@/components/admin/debug-connection"

export default function AdminLoginPage() {
  const [secretKey, setSecretKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [showDemoInfo, setShowDemoInfo] = useState(false)
  const router = useRouter()

  // Update the handleSubmit function to provide more detailed error information

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      console.log("Attempting login with secret key")
      const { user, error } = await authenticateWithSecretKey(secretKey)

      if (error || !user) {
        console.error("Authentication failed:", error)
        setError(error?.message || "Authentication failed. Please check your secret key and try again.")
        return
      }

      console.log("Authentication successful for:", user.email)

      // Set cookie for middleware authentication
      document.cookie = `adminUser=${JSON.stringify(user)}; path=/; max-age=${60 * 60 * 24 * 7}; SameSite=Strict`

      // Redirect to admin dashboard
      router.push("/admin")
    } catch (err) {
      console.error("Login error:", err)
      setError(err instanceof Error ? err.message : "Authentication failed. Please try again later.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background to-background/80 p-4">
      <div className="w-full max-w-md">
        <Card className="border-border/50 shadow-lg">
          <CardHeader className="space-y-1">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mb-2">
              <Lock className="h-6 w-6 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold text-center">SuperteamNG Admin</CardTitle>
            <CardDescription className="text-center">
              Enter your secret key to access the admin dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Enter your secret key"
                  value={secretKey}
                  onChange={(e) => setSecretKey(e.target.value)}
                  required
                  className="bg-background/50"
                  autoComplete="off"
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <Button type="submit" className="w-full bg-primary" disabled={isLoading}>
                {isLoading ? "Authenticating..." : "Login"}
              </Button>

              <div className="text-center">
                <Button
                  variant="link"
                  size="sm"
                  className="text-xs text-muted-foreground"
                  onClick={() => setShowDemoInfo(!showDemoInfo)}
                >
                  {showDemoInfo ? "Hide demo info" : "Show demo info"}
                </Button>
              </div>

              {showDemoInfo && (
                <Alert variant="default" className="bg-muted/50 border-muted">
                  <Info className="h-4 w-4" />
                  <AlertDescription>
                    <p className="text-xs">For demo purposes, you can use these keys:</p>
                    <ul className="text-xs list-disc pl-4 mt-1">
                      <li>
                        Super Admin: <code className="bg-muted px-1 rounded">demo-super-admin</code>
                      </li>
                      <li>
                        Lagos Admin: <code className="bg-muted px-1 rounded">demo-lagos-admin</code>
                      </li>
                    </ul>
                  </AlertDescription>
                </Alert>
              )}
            </form>
          </CardContent>
          {/* Add the debug component to the CardFooter */}
          <CardFooter className="flex flex-col items-center">
            <p className="text-sm text-muted-foreground mb-4">Secure access for authorized administrators only</p>
            <DebugConnection />
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}

