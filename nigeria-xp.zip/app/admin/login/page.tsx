"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { authenticateWithSecretKey } from "@/lib/auth"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, Key, Loader2 } from "lucide-react"
import { isSupabaseConfigured } from "@/lib/database"

export default function AdminLoginPage() {
  const [secretKey, setSecretKey] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()
  const { toast } = useToast()
  const dbConfigured = isSupabaseConfigured()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!secretKey.trim()) {
      setError("Secret key is required")
      return
    }

    try {
      setIsLoading(true)
      setError(null)

      const { user, error: authError } = await authenticateWithSecretKey(secretKey)

      if (authError || !user) {
        setError(authError?.message || "Invalid secret key")
        return
      }

      // Set cookie for middleware authentication
      document.cookie = `adminUser=${JSON.stringify({
        id: user.id,
        role: user.role,
        state: user.state,
      })}; path=/; max-age=86400; SameSite=Strict` // 24 hours

      toast({
        title: "Login successful",
        description: `Welcome back, ${user.name}`,
      })

      // Redirect to admin dashboard
      router.push("/admin")
    } catch (err) {
      console.error("Login error:", err)
      setError("An unexpected error occurred. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-background to-background/90 p-4">
      <div className="w-full max-w-md">
        <Card className="border-border/40 bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
          <CardHeader className="space-y-1 text-center">
            <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <Key className="h-6 w-6 text-primary" />
            </div>
            <CardTitle className="text-2xl font-bold">SuperteamNG Admin</CardTitle>
            <CardDescription>Enter your secret key to access the admin dashboard</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Input
                  type="password"
                  placeholder="Enter your secret key"
                  value={secretKey}
                  onChange={(e) => setSecretKey(e.target.value)}
                  className="bg-background/50"
                  disabled={isLoading}
                  autoComplete="off"
                  autoFocus
                />
                {error && (
                  <Alert variant="destructive" className="py-2">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription className="ml-2 text-xs">{error}</AlertDescription>
                  </Alert>
                )}
              </div>

              <Button
                type="submit"
                className="w-full bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700"
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Authenticating...
                  </>
                ) : (
                  "Login"
                )}
              </Button>
            </form>
          </CardContent>

          {!dbConfigured && (
            <CardFooter>
              <Alert variant="warning" className="w-full">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="ml-2 text-xs">
                  <p className="font-medium">Database not configured</p>
                  <p className="mt-1">For demo purposes, use:</p>
                  <ul className="mt-1 list-inside list-disc">
                    <li>demo-super-admin (Super Admin)</li>
                    <li>demo-lagos-admin (Lagos Admin)</li>
                  </ul>
                </AlertDescription>
              </Alert>
            </CardFooter>
          )}
        </Card>
      </div>
    </div>
  )
}

