"use client"

import type React from "react"

import { useState } from "react"

export default function AdminLoginPage() {
  const [secretKey, setSecretKey] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Login attempt with:", secretKey)
    // Authentication logic will be added back once we confirm rendering works
  }

  // Add inline styles to ensure visibility
  const pageStyle = {
    display: "flex",
    minHeight: "100vh",
    alignItems: "center",
    justifyContent: "center",
    padding: "1rem",
    background: "#1a1a1a", // Dark background
    color: "#ffffff", // Light text
    position: "relative",
    zIndex: 10, // Ensure it's above other elements
  }

  const cardStyle = {
    width: "100%",
    maxWidth: "400px",
    padding: "2rem",
    background: "#2a2a2a", // Slightly lighter than the background
    borderRadius: "0.5rem",
    boxShadow: "0 4px 6px rgba(0, 0, 0, 0.1)",
    zIndex: 20, // Ensure it's above the page background
  }

  const inputStyle = {
    width: "100%",
    padding: "0.75rem",
    marginBottom: "1rem",
    background: "#3a3a3a",
    border: "1px solid #4a4a4a",
    borderRadius: "0.25rem",
    color: "#ffffff",
  }

  const buttonStyle = {
    width: "100%",
    padding: "0.75rem",
    background: "#9945FF", // Solana purple
    color: "#ffffff",
    border: "none",
    borderRadius: "0.25rem",
    cursor: "pointer",
  }

  const alertStyle = {
    marginTop: "1rem",
    padding: "1rem",
    background: "rgba(255, 193, 7, 0.1)",
    border: "1px solid rgba(255, 193, 7, 0.3)",
    borderRadius: "0.25rem",
    color: "#FFC107",
  }

  return (
    <div style={pageStyle}>
      <div style={cardStyle}>
        <h1 style={{ fontSize: "1.5rem", fontWeight: "bold", marginBottom: "1rem" }}>SuperteamNG Admin Login</h1>
        <p style={{ marginBottom: "1.5rem", color: "#aaaaaa" }}>Enter your secret key to access the admin dashboard</p>

        <form onSubmit={handleSubmit}>
          <input
            type="password"
            placeholder="Enter your secret key"
            value={secretKey}
            onChange={(e) => setSecretKey(e.target.value)}
            required
            style={inputStyle}
          />

          <button type="submit" style={buttonStyle}>
            Login
          </button>

          <div style={alertStyle}>
            <p>Database not configured. For demo, use:</p>
            <ul style={{ listStyleType: "disc", paddingLeft: "1.25rem", marginTop: "0.5rem" }}>
              <li>demo-super-admin (Super Admin)</li>
              <li>demo-lagos-admin (Lagos Admin)</li>
            </ul>
          </div>
        </form>
      </div>
    </div>
  )
}

