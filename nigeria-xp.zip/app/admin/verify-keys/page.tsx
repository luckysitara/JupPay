"use client"

import { useState } from "react"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AlertCircle, CheckCircle, Key } from "lucide-react"

export default function VerifyKeysPage() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [message, setMessage] = useState<string>("")
  const [adminUsers, setAdminUsers] = useState<any[]>([])
  const [duplicateKeys, setDuplicateKeys] = useState<string[]>([])

  const checkKeys = async () => {
    setStatus("loading")
    setMessage("")
    setAdminUsers([])
    setDuplicateKeys([])

    try {
      // Get all admin users
      const { data, error } = await supabase.from("admin_users").select("id, email, name, role, state, secret_key")

      if (error) {
        throw error
      }

      if (!data || data.length === 0) {
        setStatus("error")
        setMessage("No admin users found in the database")
        return
      }

      setAdminUsers(data)

      // Check for duplicate secret keys
      const keyMap = new Map<string, string[]>()
      data.forEach((user) => {
        if (!user.secret_key) return

        if (!keyMap.has(user.secret_key)) {
          keyMap.set(user.secret_key, [user.id])
        } else {
          keyMap.get(user.secret_key)?.push(user.id)
        }
      })

      const duplicates: string[] = []
      keyMap.forEach((ids, key) => {
        if (ids.length > 1) {
          duplicates.push(key)
        }
      })

      setDuplicateKeys(duplicates)

      if (duplicates.length > 0) {
        setStatus("error")
        setMessage(`Found ${duplicates.length} duplicate secret keys!`)
      } else {
        setStatus("success")
        setMessage(`Verified ${data.length} admin users. No duplicate keys found.`)
      }
    } catch (err) {
      setStatus("error")
      setMessage(err instanceof Error ? err.message : "Unknown error occurred")
    }
  }

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Verify Admin Secret Keys</CardTitle>
          <CardDescription>Check for issues with admin user secret keys in the database</CardDescription>
        </CardHeader>
        <CardContent>
          <Button onClick={checkKeys} disabled={status === "loading"} className="mb-4">
            {status === "loading" ? "Checking..." : "Check Secret Keys"}
          </Button>

          {status === "success" && (
            <Alert
              variant="default"
              className="bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800 mb-4"
            >
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{message}</AlertDescription>
            </Alert>
          )}

          {status === "error" && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{message}</AlertDescription>
            </Alert>
          )}

          {adminUsers.length > 0 && (
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>State</TableHead>
                    <TableHead>Secret Key</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adminUsers.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.name}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{user.role}</TableCell>
                      <TableCell>{user.state || "-"}</TableCell>
                      <TableCell className="font-mono text-xs">
                        {user.secret_key
                          ? `${user.secret_key.substring(0, 3)}...${user.secret_key.substring(user.secret_key.length - 3)}`
                          : "No key"}
                      </TableCell>
                      <TableCell>
                        {!user.secret_key && <span className="text-amber-500 text-xs">Missing key</span>}
                        {user.secret_key && duplicateKeys.includes(user.secret_key) && (
                          <span className="text-red-500 text-xs">Duplicate key</span>
                        )}
                        {user.secret_key && !duplicateKeys.includes(user.secret_key) && (
                          <span className="text-green-500 text-xs">Valid</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <p className="text-sm text-muted-foreground">
            <Key className="h-4 w-4 inline mr-1" />
            Each admin user should have a unique secret key
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}

