"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/database"
import { getAdminUser, isStateAdmin } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Search, Plus } from "lucide-react"
import { AdminAddUserDialog } from "@/components/admin/admin-add-user-dialog"
import type { User } from "@/types"

export default function AdminUsersPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const admin = getAdminUser()

  useEffect(() => {
    async function fetchUsers() {
      try {
        setLoading(true)

        let query = supabase.from("users_with_state").select("*").order("total_xp", { ascending: false })

        // If state admin, filter by state
        if (isStateAdmin() && admin?.state) {
          query = query.eq("state", admin.state)
        }

        const { data, error } = await query

        if (error) throw error

        if (data) {
          const transformedUsers: User[] = data.map((user) => ({
            id: user.id,
            name: user.name,
            username: user.username,
            state: user.state,
            stateName: user.state_name,
            totalXp: user.total_xp,
            monthlyXp: user.monthly_xp,
            skills: user.skills,
            joinedAt: new Date(user.joined_at),
          }))
          setUsers(transformedUsers)
        }
      } catch (error) {
        console.error("Error fetching users:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchUsers()
  }, [admin])

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Users</h1>

        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search users..."
              className="pl-8 w-[250px]"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Button onClick={() => setShowAddDialog(true)}>
            <Plus className="mr-2 h-4 w-4" />
            Add User
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Username</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Total XP</TableHead>
                <TableHead>Monthly XP</TableHead>
                <TableHead>Skills</TableHead>
                <TableHead>Joined</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>@{user.username}</TableCell>
                    <TableCell>{user.stateName}</TableCell>
                    <TableCell>{user.totalXp.toLocaleString()}</TableCell>
                    <TableCell>{user.monthlyXp.toLocaleString()}</TableCell>
                    <TableCell>
                      <div className="flex flex-wrap gap-1">
                        {user.skills.slice(0, 3).map((skill) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {user.skills.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{user.skills.length - 3}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{new Date(user.joinedAt).toLocaleDateString()}</TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      <AdminAddUserDialog open={showAddDialog} onOpenChange={setShowAddDialog} />
    </div>
  )
}

