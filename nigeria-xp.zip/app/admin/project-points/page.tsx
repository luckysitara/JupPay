"use client"

import { useState, useEffect } from "react"
import { supabase, isSupabaseConfigured } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Award, AlertCircle } from "lucide-react"
import { AdminAssignProjectPointsDialog } from "@/components/admin/admin-assign-project-points-dialog"
import { useToast } from "@/components/ui/use-toast"
import type { Project } from "@/types"

export default function AdminProjectPointsPage() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [showAssignDialog, setShowAssignDialog] = useState(false)
  const [dbConfigured, setDbConfigured] = useState(true)
  const { toast } = useToast()

  useEffect(() => {
    // Check if Supabase is configured
    const configured = isSupabaseConfigured()
    setDbConfigured(configured)

    if (!configured) {
      setLoading(false)
      toast({
        title: "Database not configured",
        description: "Please set up Supabase environment variables to enable full functionality.",
        variant: "destructive",
      })
    } else {
      fetchProjects()
    }
  }, [toast])

  async function fetchProjects() {
    try {
      setLoading(true)

      const { data, error } = await supabase.from("projects").select("*").order("name")

      if (error) throw error

      if (data) {
        const transformedProjects: Project[] = data.map((project) => ({
          id: project.id,
          name: project.name,
          description: project.description,
          points: project.points,
          weeklyPoints: project.weekly_points,
          monthlyPoints: project.monthly_points,
          yearlyPoints: project.yearly_points,
          createdAt: new Date(project.created_at),
          updatedAt: new Date(project.updated_at),
        }))
        setProjects(transformedProjects)
      }
    } catch (error) {
      console.error("Error fetching projects:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredProjects = projects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const handleAssignPoints = (project: Project) => {
    setSelectedProject(project)
    setShowAssignDialog(true)
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Assign Project Points</h1>

        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search projects..."
            className="pl-8 w-[250px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {!dbConfigured ? (
        <div className="flex flex-col items-center justify-center p-8 border rounded-md">
          <AlertCircle className="h-8 w-8 text-amber-500 mb-2" />
          <h3 className="text-lg font-semibold">Database Not Configured</h3>
          <p className="text-muted-foreground text-center mt-2">
            Please set up your Supabase environment variables to enable project points functionality.
            <br />
            Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to your environment.
          </p>
        </div>
      ) : loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Total Points</TableHead>
                <TableHead>Weekly Points</TableHead>
                <TableHead>Monthly Points</TableHead>
                <TableHead>Yearly Points</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProjects.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    No projects found
                  </TableCell>
                </TableRow>
              ) : (
                filteredProjects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{project.description}</TableCell>
                    <TableCell>{project.points.toLocaleString()}</TableCell>
                    <TableCell>{project.weeklyPoints.toLocaleString()}</TableCell>
                    <TableCell>{project.monthlyPoints.toLocaleString()}</TableCell>
                    <TableCell>{project.yearlyPoints.toLocaleString()}</TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleAssignPoints(project)}>
                        <Award className="mr-2 h-4 w-4" />
                        Assign Points
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      {selectedProject && (
        <AdminAssignProjectPointsDialog
          project={selectedProject}
          open={showAssignDialog}
          onOpenChange={setShowAssignDialog}
          onSuccess={fetchProjects}
        />
      )}
    </div>
  )
}

