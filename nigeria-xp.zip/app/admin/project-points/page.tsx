"use client"

import { useState, useEffect } from "react"
import { isSupabaseConfigured } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Award, AlertCircle, Database } from "lucide-react"
import { AdminAssignProjectPointsDialog } from "@/components/admin/admin-assign-project-points-dialog"
import { useToast } from "@/components/ui/use-toast"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import type { Project } from "@/types"
import { isSuperAdmin } from "@/lib/auth"
import { useRouter } from "next/navigation"
import { useProjects } from "@/hooks/use-projects"

export default function AdminProjectPointsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)
  const [showAssignDialog, setShowAssignDialog] = useState(false)
  const [dbConfigured, setDbConfigured] = useState(true)
  const { toast } = useToast()
  const router = useRouter()
  const { projects, loading, error, tableExists } = useProjects()

  useEffect(() => {
    // Check if user is super admin, if not redirect to dashboard
    if (!isSuperAdmin()) {
      router.push("/admin")
      return
    }

    // Check if Supabase is configured
    const configured = isSupabaseConfigured()
    setDbConfigured(configured)

    if (!configured) {
      toast({
        title: "Database not configured",
        description: "Please set up Supabase environment variables to enable full functionality.",
        variant: "destructive",
      })
    }
  }, [toast, router])

  const filteredProjects = projects.filter(
    (project) =>
      project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (project.description && project.description.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  const handleAssignPoints = (project: Project) => {
    setSelectedProject(project)
    setShowAssignDialog(true)
  }

  // If not super admin, don't render anything (will redirect)
  if (!isSuperAdmin()) {
    return null
  }

  return (
    <div className="p-6 animate-in fade-in-50 duration-300">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Assign Project Points</h1>

        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search projects..."
            className="pl-8 w-[250px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {!dbConfigured ? (
        <div className="flex flex-col items-center justify-center p-8 border rounded-md">
          <AlertCircle className="h-8 w-8 text-amber-500 mb-2" />
          <h3 className="text-lg font-semibold">Database Not Configured</h3>
          <p className="text-muted-foreground text-center mt-2">
            Please set up your Supabase environment variables to enable project points functionality.
            <br />
            Add NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY to your environment.
          </p>
        </div>
      ) : !tableExists ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Projects Table Not Found
            </CardTitle>
            <CardDescription>
              The projects table doesn't exist in your database. You need to run the migration script to create it.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Alert variant="warning" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Missing Database Table</AlertTitle>
              <AlertDescription>
                The projects functionality requires a database table that hasn't been created yet.
              </AlertDescription>
            </Alert>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm font-medium mb-2">Run the following command to create the projects table:</p>
              <pre className="bg-black text-white p-3 rounded text-sm overflow-x-auto">
                npm run create-projects-tables
              </pre>
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-sm text-muted-foreground">
              After running the command, refresh this page to access project points features.
            </p>
          </CardFooter>
        </Card>
      ) : loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      ) : error ? (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error.message}</AlertDescription>
        </Alert>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Total Points</TableHead>
                <TableHead>Weekly Points</TableHead>
                <TableHead>Monthly Points</TableHead>
                <TableHead>Yearly Points</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProjects.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    No projects found
                  </TableCell>
                </TableRow>
              ) : (
                filteredProjects.map((project) => (
                  <TableRow key={project.id}>
                    <TableCell className="font-medium">{project.name}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{project.description}</TableCell>
                    <TableCell>{project.points.toLocaleString()}</TableCell>
                    <TableCell>{project.weeklyPoints.toLocaleString()}</TableCell>
                    <TableCell>{project.monthlyPoints.toLocaleString()}</TableCell>
                    <TableCell>{project.yearlyPoints.toLocaleString()}</TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleAssignPoints(project)}>
                        <Award className="mr-2 h-4 w-4" />
                        Assign Points
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      {selectedProject && (
        <AdminAssignProjectPointsDialog
          project={selectedProject}
          open={showAssignDialog}
          onOpenChange={setShowAssignDialog}
        />
      )}
    </div>
  )
}

