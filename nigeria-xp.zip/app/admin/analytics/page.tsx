"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { getAdminUser, isSuperAdmin } from "@/lib/auth"
import { supabase } from "@/lib/database"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("month")
  const [loading, setLoading] = useState(true)
  const admin = getAdminUser()
  const [stats, setStats] = useState({
    userGrowth: 0,
    xpGrowth: 0,
    topSkills: [] as { skill: string; count: number }[],
    stateDistribution: [] as { state: string; count: number }[],
  })

  useEffect(() => {
    async function fetchAnalytics() {
      try {
        setLoading(true)

        // In a real app, you would fetch actual analytics data from your database
        // For this example, we'll simulate the data

        // Simulate user growth
        const userGrowth = Math.floor(Math.random() * 30) + 5 // 5-35%

        // Simulate XP growth
        const xpGrowth = Math.floor(Math.random() * 50) + 10 // 10-60%

        // Simulate top skills
        const skills = ["Development", "Design", "Writing", "Strategy", "Operations", "Marketing", "Community"]

        const topSkills = skills
          .map((skill) => ({
            skill,
            count: Math.floor(Math.random() * 100) + 20,
          }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 5)

        // Simulate state distribution
        const { data: states } = await supabase.from("states").select("code, name")

        const stateDistribution = states
          .map((state) => ({
            state: state.name,
            count: Math.floor(Math.random() * 50) + 5,
          }))
          .sort((a, b) => b.count - a.count)
          .slice(0, 10)

        setStats({
          userGrowth,
          xpGrowth,
          topSkills,
          stateDistribution,
        })
      } catch (error) {
        console.error("Error fetching analytics:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchAnalytics()
  }, [timeRange])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex flex-col gap-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Analytics</h1>
            <p className="text-muted-foreground">
              {isSuperAdmin() ? "Platform-wide analytics" : `Analytics for ${admin?.state} state`}
            </p>
          </div>

          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select time range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">Last Week</SelectItem>
              <SelectItem value="month">Last Month</SelectItem>
              <SelectItem value="quarter">Last Quarter</SelectItem>
              <SelectItem value="year">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">User Growth</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">+{stats.userGrowth}%</div>
              <p className="text-xs text-muted-foreground">Compared to previous period</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">XP Growth</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">+{stats.xpGrowth}%</div>
              <p className="text-xs text-muted-foreground">Compared to previous period</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Top Skill</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.topSkills[0]?.skill || "N/A"}</div>
              <p className="text-xs text-muted-foreground">Most common skill</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{Math.floor(Math.random() * 100) + 50}%</div>
              <p className="text-xs text-muted-foreground">User engagement rate</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="skills" className="w-full">
          <TabsList>
            <TabsTrigger value="skills">Skills Distribution</TabsTrigger>
            <TabsTrigger value="states">State Distribution</TabsTrigger>
          </TabsList>

          <TabsContent value="skills" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Top Skills</CardTitle>
                <CardDescription>Most common skills among users</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.topSkills.map((skill) => (
                    <div key={skill.skill} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{skill.skill}</span>
                        <span className="text-sm">{skill.count} users</span>
                      </div>
                      <Progress value={(skill.count / stats.topSkills[0].count) * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="states" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>State Distribution</CardTitle>
                <CardDescription>User distribution by state</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {stats.stateDistribution.map((state) => (
                    <div key={state.state} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{state.state}</span>
                        <span className="text-sm">{state.count} users</span>
                      </div>
                      <Progress value={(state.count / stats.stateDistribution[0].count) * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

