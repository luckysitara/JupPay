"use client"

import { useState, useEffect, useCallback } from "react"
import { supabase } from "@/lib/database"
import { getAdminUser, isStateAdmin } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Award, AlertCircle } from "lucide-react"
import { AdminAssignXpDialog } from "@/components/admin/admin-assign-xp-dialog"
import { useToast } from "@/components/ui/use-toast"
import type { User } from "@/types"
import { Alert, AlertDescription } from "@/components/ui/alert"

export default function AdminXpPage() {
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [showAssignDialog, setShowAssignDialog] = useState(false)
  const admin = getAdminUser()
  const { toast } = useToast()
  const [error, setError] = useState<string | null>(null)

  // Use useCallback to prevent recreation of the function on each render
  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)

      let query = supabase.from("users_with_state").select("*").order("name")

      // If state admin, filter by state
      if (isStateAdmin() && admin?.state) {
        query = query.eq("state", admin.state)
      }

      const { data, error: fetchError } = await query

      if (fetchError) {
        console.error("Error fetching users:", fetchError.message)
        setError(`Failed to load users: ${fetchError.message}`)
        return
      }

      if (data) {
        const transformedUsers: User[] = data.map((user) => ({
          id: user.id,
          name: user.name,
          username: user.username,
          state: user.state,
          stateName: user.state_name,
          totalXp: user.total_xp,
          monthlyXp: user.monthly_xp,
          skills: user.skills,
          joinedAt: new Date(user.joined_at),
          walletAddress: user.wallet_address || null,
        }))
        setUsers(transformedUsers)
      }
    } catch (err) {
      console.error("Error fetching users:", err instanceof Error ? err.message : String(err))
      setError("Failed to load users. Please try again later.")
    } finally {
      setLoading(false)
    }
  }, [admin])

  // Only fetch users once when the component mounts
  useEffect(() => {
    fetchUsers()
  }, [fetchUsers])

  const filteredUsers = users.filter(
    (user) =>
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.username.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const handleAssignXp = (user: User) => {
    setSelectedUser(user)
    setShowAssignDialog(true)
  }

  return (
    <div className="p-6 animate-in fade-in-50 duration-300">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Assign XP</h1>

        <div className="relative">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            className="pl-8 w-[250px]"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-4">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-64">
          <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        </div>
      ) : (
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Username</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Total XP</TableHead>
                <TableHead>Monthly XP</TableHead>
                <TableHead>Wallet Address</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredUsers.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-4">
                    No users found
                  </TableCell>
                </TableRow>
              ) : (
                filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell className="font-medium">{user.name}</TableCell>
                    <TableCell>@{user.username}</TableCell>
                    <TableCell>{user.stateName}</TableCell>
                    <TableCell>{user.totalXp.toLocaleString()}</TableCell>
                    <TableCell>{user.monthlyXp.toLocaleString()}</TableCell>
                    <TableCell>
                      {user.walletAddress ? (
                        <span className="font-mono text-xs truncate max-w-[120px] inline-block">
                          {user.walletAddress}
                        </span>
                      ) : (
                        <span className="text-muted-foreground text-xs">Not set</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <Button variant="outline" size="sm" onClick={() => handleAssignXp(user)}>
                        <Award className="mr-2 h-4 w-4" />
                        Assign XP
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      )}

      {selectedUser && (
        <AdminAssignXpDialog
          user={selectedUser}
          open={showAssignDialog}
          onOpenChange={setShowAssignDialog}
          onSuccess={fetchUsers}
        />
      )}
    </div>
  )
}

