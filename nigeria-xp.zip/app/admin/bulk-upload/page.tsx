"use client"

import type React from "react"

import { useState, useRef } from "react"
import { supabase } from "@/lib/database"
import { getAdminUser } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { useToast } from "@/components/ui/use-toast"
import { AlertCircle, CheckCircle, FileSpreadsheet, Upload, Download } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Progress } from "@/components/ui/progress"

type BulkXpRow = {
  username: string
  amount: number
  reason: string
  skills?: string
  status?: "pending" | "success" | "error"
  message?: string
}

export default function BulkUploadPage() {
  const [file, setFile] = useState<File | null>(null)
  const [parsedData, setParsedData] = useState<BulkXpRow[]>([])
  const [uploading, setUploading] = useState(false)
  const [processing, setProcessing] = useState(false)
  const [progress, setProgress] = useState(0)
  const [results, setResults] = useState<BulkXpRow[]>([])
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()
  const admin = getAdminUser()

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      if (selectedFile.type !== "text/csv" && !selectedFile.name.endsWith(".csv")) {
        setError("Please upload a CSV file")
        setFile(null)
        if (fileInputRef.current) {
          fileInputRef.current.value = ""
        }
        return
      }

      setFile(selectedFile)
      setError(null)
      parseCSV(selectedFile)
    }
  }

  const parseCSV = (file: File) => {
    setUploading(true)
    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const text = e.target?.result as string
        const lines = text.split("\n")
        const headers = lines[0].split(",").map((h) => h.trim().toLowerCase())

        // Validate required columns
        const requiredColumns = ["username", "amount", "reason"]
        const missingColumns = requiredColumns.filter((col) => !headers.includes(col))

        if (missingColumns.length > 0) {
          setError(`CSV is missing required columns: ${missingColumns.join(", ")}`)
          setUploading(false)
          return
        }

        // Parse data rows
        const data: BulkXpRow[] = []
        for (let i = 1; i < lines.length; i++) {
          if (!lines[i].trim()) continue // Skip empty lines

          const values = lines[i].split(",").map((v) => v.trim())
          if (values.length < 3) continue // Skip invalid rows

          const row: BulkXpRow = {
            username: values[headers.indexOf("username")],
            amount: Number.parseFloat(values[headers.indexOf("amount")]),
            reason: values[headers.indexOf("reason")],
            status: "pending",
          }

          // Add skills if present
          if (headers.includes("skills")) {
            row.skills = values[headers.indexOf("skills")]
          }

          // Validate row data
          if (!row.username || isNaN(row.amount) || !row.reason) {
            row.status = "error"
            row.message = "Invalid data in row"
          }

          data.push(row)
        }

        setParsedData(data)
      } catch (err) {
        console.error("Error parsing CSV:", err)
        setError("Failed to parse CSV file. Please check the format.")
      } finally {
        setUploading(false)
      }
    }

    reader.onerror = () => {
      setError("Error reading file")
      setUploading(false)
    }

    reader.readAsText(file)
  }

  const processXpAssignments = async () => {
    if (!admin) {
      toast({
        title: "Error",
        description: "You must be logged in to assign XP",
        variant: "destructive",
      })
      return
    }

    setProcessing(true)
    setProgress(0)

    const results = [...parsedData]
    let successCount = 0
    let errorCount = 0

    for (let i = 0; i < results.length; i++) {
      const row = results[i]

      // Skip already processed rows
      if (row.status !== "pending") {
        continue
      }

      try {
        // Find user by username
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("id")
          .eq("username", row.username)
          .single()

        if (userError) {
          results[i].status = "error"
          results[i].message = `User not found: ${row.username}`
          errorCount++
          continue
        }

        // Parse skills
        const skills = row.skills
          ? row.skills
              .split(";")
              .map((s) => s.trim())
              .filter(Boolean)
          : []

        // Insert XP transaction
        const { error: xpError } = await supabase.from("xp_transactions").insert({
          user_id: userData.id,
          admin_id: admin.id,
          amount: row.amount,
          reason: row.reason,
          skills,
        })

        if (xpError) {
          results[i].status = "error"
          results[i].message = `Failed to assign XP: ${xpError.message}`
          errorCount++
        } else {
          results[i].status = "success"
          results[i].message = "XP assigned successfully"
          successCount++
        }
      } catch (err) {
        results[i].status = "error"
        results[i].message = `Unexpected error: ${err instanceof Error ? err.message : "Unknown error"}`
        errorCount++
      }

      // Update progress
      setProgress(Math.round(((i + 1) / results.length) * 100))
    }

    setResults(results)
    setProcessing(false)

    toast({
      title: "Bulk XP Assignment Complete",
      description: `Successfully assigned XP to ${successCount} users. Failed: ${errorCount}`,
      variant: successCount > 0 ? "default" : "destructive",
    })
  }

  const downloadTemplate = () => {
    const template =
      "username,amount,reason,skills\njohndoe,100,Project contribution,Development;Design\njanedoe,50,Community support,Community;Writing"
    const blob = new Blob([template], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "xp_assignment_template.csv"
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="p-6 animate-in fade-in-50 duration-300">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Bulk XP Assignment</h1>

        <Button variant="outline" onClick={downloadTemplate}>
          <Download className="mr-2 h-4 w-4" />
          Download Template
        </Button>
      </div>

      <div className="grid gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Upload CSV File</CardTitle>
            <CardDescription>
              Upload a CSV file with user XP assignments. The file must include username, amount, and reason columns.
              Optionally, you can include a skills column with semicolon-separated skills.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid w-full max-w-sm items-center gap-1.5">
                <Label htmlFor="csv-file">CSV File</Label>
                <Input
                  id="csv-file"
                  type="file"
                  accept=".csv"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  disabled={uploading || processing}
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {file && (
                <div className="flex items-center gap-2 text-sm">
                  <FileSpreadsheet className="h-4 w-4" />
                  <span>{file.name}</span>
                  <span className="text-muted-foreground">({parsedData.length} rows)</span>
                </div>
              )}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button
              variant="outline"
              onClick={() => {
                setFile(null)
                setParsedData([])
                setResults([])
                setError(null)
                if (fileInputRef.current) {
                  fileInputRef.current.value = ""
                }
              }}
              disabled={!file || uploading || processing}
            >
              Clear
            </Button>
            <Button
              onClick={processXpAssignments}
              disabled={!file || parsedData.length === 0 || uploading || processing}
            >
              {processing ? (
                <>Processing...</>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Process XP Assignments
                </>
              )}
            </Button>
          </CardFooter>
        </Card>

        {processing && (
          <Card>
            <CardHeader>
              <CardTitle>Processing</CardTitle>
              <CardDescription>Assigning XP to users. Please wait...</CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={progress} className="h-2" />
              <p className="text-sm text-muted-foreground mt-2">{progress}% complete</p>
            </CardContent>
          </Card>
        )}

        {results.length > 0 && !processing && (
          <Card>
            <CardHeader>
              <CardTitle>Results</CardTitle>
              <CardDescription>XP assignment results for {results.length} users</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Username</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Reason</TableHead>
                      <TableHead>Skills</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {results.map((row, index) => (
                      <TableRow key={index}>
                        <TableCell>{row.username}</TableCell>
                        <TableCell>{row.amount}</TableCell>
                        <TableCell className="max-w-[200px] truncate">{row.reason}</TableCell>
                        <TableCell>{row.skills || "-"}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            {row.status === "success" ? (
                              <CheckCircle className="h-4 w-4 text-green-500" />
                            ) : row.status === "error" ? (
                              <AlertCircle className="h-4 w-4 text-red-500" />
                            ) : (
                              <span className="h-4 w-4 rounded-full bg-amber-500" />
                            )}
                            <span className={row.status === "error" ? "text-red-500" : ""}>
                              {row.message || row.status}
                            </span>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}

