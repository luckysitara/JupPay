"use client"

import { useState } from "react"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AlertCircle, CheckCircle, Database } from "lucide-react"

export default function DatabaseCheckPage() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [message, setMessage] = useState<string>("")
  const [details, setDetails] = useState<string>("")
  const [tables, setTables] = useState<{ name: string; count: number }[]>([])

  const checkDatabase = async () => {
    setStatus("loading")
    setMessage("Checking database structure...")
    setDetails("")
    setTables([])

    try {
      // Test connection
      const { data: testData, error: testError } = await supabase.from("states").select("code").limit(1)

      if (testError) {
        throw new Error(`Connection test failed: ${testError.message}`)
      }

      // Get list of tables and their row counts
      const tablesToCheck = ["states", "users", "admin_users", "xp_transactions"]
      const tableResults = []

      for (const tableName of tablesToCheck) {
        try {
          const { count, error } = await supabase.from(tableName).select("*", { count: "exact", head: true })

          tableResults.push({
            name: tableName,
            count: error ? -1 : count || 0,
          })
        } catch (err) {
          tableResults.push({
            name: tableName,
            count: -1,
          })
        }
      }

      setTables(tableResults)

      // Check admin_users table specifically
      const { data: adminData, error: adminError } = await supabase
        .from("admin_users")
        .select("email, name, role, secret_key")
        .limit(5)

      if (adminError) {
        throw new Error(`Error accessing admin_users: ${adminError.message}`)
      }

      if (!adminData || adminData.length === 0) {
        setStatus("error")
        setMessage("Admin users table exists but has no data")
        setDetails("Please run the setup script to create admin users")
        return
      }

      // Check if admin users have secret keys
      const missingKeys = adminData.filter((admin) => !admin.secret_key).length

      if (missingKeys > 0) {
        setStatus("error")
        setMessage(`Found ${missingKeys} admin users without secret keys`)
        setDetails("All admin users must have secret keys for login")
        return
      }

      setStatus("success")
      setMessage("Database connection and structure verified successfully!")
      setDetails(`Found ${adminData.length} admin users with valid secret keys`)
    } catch (err) {
      console.error("Database check error:", err)
      setStatus("error")
      if (err instanceof Error) {
        setMessage("Database check failed")
        setDetails(err.message)
      } else {
        setMessage("Unknown error occurred")
        setDetails(JSON.stringify(err))
      }
    }
  }

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Database Diagnostics</CardTitle>
          <CardDescription>Check your Supabase database connection and structure</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Button onClick={checkDatabase} disabled={status === "loading"} className="mb-4">
            <Database className="mr-2 h-4 w-4" />
            {status === "loading" ? "Checking..." : "Check Database"}
          </Button>

          {status === "success" && (
            <Alert
              variant="default"
              className="bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800 mb-4"
            >
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>
                <p>{message}</p>
                {details && <p className="text-xs mt-1">{details}</p>}
              </AlertDescription>
            </Alert>
          )}

          {status === "error" && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <p>{message}</p>
                {details && <p className="text-xs mt-1 font-mono break-all">{details}</p>}
              </AlertDescription>
            </Alert>
          )}

          {tables.length > 0 && (
            <div className="border rounded-md">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Table Name</TableHead>
                    <TableHead>Row Count</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tables.map((table) => (
                    <TableRow key={table.name}>
                      <TableCell className="font-medium">{table.name}</TableCell>
                      <TableCell>{table.count === -1 ? "Error" : table.count}</TableCell>
                      <TableCell>
                        {table.count === -1 ? (
                          <span className="text-red-500 text-xs">Table not accessible</span>
                        ) : table.count === 0 ? (
                          <span className="text-amber-500 text-xs">Empty table</span>
                        ) : (
                          <span className="text-green-500 text-xs">OK</span>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <p className="text-sm text-muted-foreground">
            If you encounter issues, make sure you've run the setup SQL script in your Supabase project.
          </p>
        </CardFooter>
      </Card>
    </div>
  )
}

