"use client"

import { useState } from "react"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AlertCircle, CheckCircle, Database, RefreshCw } from "lucide-react"
import { Input } from "@/components/ui/input"

export default function FixAdminTablePage() {
  const [status, setStatus] = useState<"idle" | "loading" | "checking" | "success" | "error">("idle")
  const [message, setMessage] = useState<string>("")
  const [details, setDetails] = useState<string>("")
  const [tables, setTables] = useState<string[]>([])
  const [adminTableName, setAdminTableName] = useState<string>("admin_users")
  const [adminUsers, setAdminUsers] = useState<any[]>([])
  const [secretKeyColumn, setSecretKeyColumn] = useState<string>("secret_key")
  const [columns, setColumns] = useState<string[]>([])

  const checkDatabase = async () => {
    setStatus("loading")
    setMessage("Checking database structure...")
    setDetails("")
    setTables([])
    setAdminUsers([])
    setColumns([])

    try {
      // Try to get list of tables
      const { data: tablesData, error: tablesError } = await supabase
        .from("pg_catalog.pg_tables")
        .select("tablename")
        .eq("schemaname", "public")

      if (tablesError) {
        throw tablesError
      }

      const tableNames = tablesData.map((t) => t.tablename)
      setTables(tableNames)

      // Check if admin_users exists
      if (!tableNames.includes("admin_users")) {
        setStatus("error")
        setMessage("The admin_users table doesn't exist in your database")
        setDetails(`Available tables: ${tableNames.join(", ")}`)
        return
      }

      // Check admin_users columns
      const { data: columnsData, error: columnsError } = await supabase
        .from("information_schema.columns")
        .select("column_name")
        .eq("table_name", "admin_users")
        .eq("table_schema", "public")

      if (columnsError) {
        throw columnsError
      }

      const columnNames = columnsData.map((c) => c.column_name)
      setColumns(columnNames)

      // Check if secret_key column exists
      if (!columnNames.includes("secret_key")) {
        setStatus("error")
        setMessage("The admin_users table doesn't have a secret_key column")
        setDetails(`Available columns: ${columnNames.join(", ")}`)
        return
      }

      // Try to get admin users
      const { data: adminData, error: adminError } = await supabase.from("admin_users").select("*")

      if (adminError) {
        throw adminError
      }

      setAdminUsers(adminData || [])

      if (adminData.length === 0) {
        setStatus("error")
        setMessage("The admin_users table exists but has no rows")
        setDetails("You need to add admin users to your database")
        return
      }

      // Check if admin users have secret keys
      const usersWithoutSecretKey = adminData.filter((user) => !user.secret_key)

      if (usersWithoutSecretKey.length > 0) {
        setStatus("error")
        setMessage(`Found ${usersWithoutSecretKey.length} admin users without secret keys`)
        setDetails("You need to add secret keys to these users")
        return
      }

      setStatus("success")
      setMessage(`Found ${adminData.length} admin users with secret keys`)
      setDetails("Your database structure looks correct")
    } catch (err) {
      console.error("Database check error:", err)
      setStatus("error")
      if (err instanceof Error) {
        setMessage("Error checking database")
        setDetails(err.message)
      } else {
        setMessage("Unknown error occurred")
        setDetails(JSON.stringify(err))
      }
    }
  }

  const checkCustomTable = async () => {
    setStatus("checking")
    setMessage(`Checking table "${adminTableName}"...`)
    setDetails("")
    setAdminUsers([])
    setColumns([])

    try {
      // Check if the table exists
      const { data, error } = await supabase.from(adminTableName).select("*")

      if (error) {
        throw error
      }

      // Get columns
      const { data: columnsData, error: columnsError } = await supabase
        .from("information_schema.columns")
        .select("column_name")
        .eq("table_name", adminTableName)
        .eq("table_schema", "public")

      if (columnsError) {
        throw columnsError
      }

      const columnNames = columnsData.map((c) => c.column_name)
      setColumns(columnNames)
      setAdminUsers(data || [])

      setStatus("success")
      setMessage(`Found table "${adminTableName}" with ${data.length} rows`)
      setDetails(`Columns: ${columnNames.join(", ")}`)
    } catch (err) {
      console.error("Custom table check error:", err)
      setStatus("error")
      if (err instanceof Error) {
        setMessage(`Error checking table "${adminTableName}"`)
        setDetails(err.message)
      } else {
        setMessage("Unknown error occurred")
        setDetails(JSON.stringify(err))
      }
    }
  }

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Database Diagnostics</CardTitle>
          <CardDescription>Check and fix issues with your admin users table</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Button onClick={checkDatabase} disabled={status === "loading"} className="mb-4">
              <Database className="mr-2 h-4 w-4" />
              {status === "loading" ? "Checking..." : "Check Database Structure"}
            </Button>

            {status === "success" && (
              <Alert
                variant="default"
                className="bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800 mb-4"
              >
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  <p>{message}</p>
                  {details && <p className="text-xs mt-1">{details}</p>}
                </AlertDescription>
              </Alert>
            )}

            {status === "error" && (
              <Alert variant="destructive" className="mb-4">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <p>{message}</p>
                  {details && <p className="text-xs mt-1">{details}</p>}
                </AlertDescription>
              </Alert>
            )}
          </div>

          <div className="border-t pt-4">
            <h3 className="text-lg font-medium mb-2">Check Custom Table</h3>
            <div className="flex gap-2 mb-4">
              <Input
                placeholder="Table name"
                value={adminTableName}
                onChange={(e) => setAdminTableName(e.target.value)}
                className="max-w-xs"
              />
              <Button onClick={checkCustomTable} disabled={!adminTableName || status === "checking"} variant="outline">
                <RefreshCw className="mr-2 h-4 w-4" />
                {status === "checking" ? "Checking..." : "Check Table"}
              </Button>
            </div>
          </div>

          {adminUsers.length > 0 && (
            <div className="border rounded-md overflow-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    {columns.map((column) => (
                      <TableHead key={column}>{column}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {adminUsers.map((user, index) => (
                    <TableRow key={index}>
                      {columns.map((column) => (
                        <TableCell key={column} className="font-mono text-xs truncate max-w-[200px]">
                          {user[column] !== null && user[column] !== undefined
                            ? typeof user[column] === "object"
                              ? JSON.stringify(user[column])
                              : String(user[column])
                            : "null"}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <p className="text-sm text-muted-foreground">Use this tool to diagnose issues with your admin users table</p>
        </CardFooter>
      </Card>
    </div>
  )
}

