"use client"

import { useEffect, useState } from "react"
import { getAdminUser, isSuperAdmin } from "@/lib/auth"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart, LineChart, PieChart } from "lucide-react"
import { AdminDashboardStats } from "@/components/admin/admin-dashboard-stats"
import { StateAdminDashboard } from "@/components/admin/state-admin-dashboard"
import { SuperAdminDashboard } from "@/components/admin/super-admin-dashboard"
import { RecentActivity } from "@/components/admin/recent-activity"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function AdminDashboardPage() {
  const [loading, setLoading] = useState(true)
  const admin = getAdminUser()
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    // Just to trigger loading state for demonstration
    const timer = setTimeout(() => {
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    )
  }

  if (!admin) {
    return (
      <div className="p-6">
        <Alert variant="destructive">
          <AlertTitle>Authentication Error</AlertTitle>
          <AlertDescription>Unable to load admin information. Please try logging in again.</AlertDescription>
        </Alert>
      </div>
    )
  }

  return (
    <div className="p-6">
      <div className="flex flex-col gap-6">
        <div>
          <h1 className="text-2xl font-bold">Welcome, {admin.name}</h1>
          <p className="text-muted-foreground">
            {isSuperAdmin() ? "Super Admin Dashboard" : `${admin.state} State Admin Dashboard`}
          </p>
        </div>

        <AdminDashboardStats />

        <Tabs defaultValue="overview" className="w-full">
          <TabsList>
            <TabsTrigger value="overview">
              <BarChart className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="activity">
              <LineChart className="h-4 w-4 mr-2" />
              Recent Activity
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <PieChart className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4 mt-4">
            {isSuperAdmin() ? <SuperAdminDashboard /> : <StateAdminDashboard stateCode={admin.state || ""} />}
          </TabsContent>

          <TabsContent value="activity" className="mt-4">
            <RecentActivity />
          </TabsContent>

          <TabsContent value="analytics" className="mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Analytics</CardTitle>
                <CardDescription>Detailed analytics and metrics for your region.</CardDescription>
              </CardHeader>
              <CardContent>
                <p>Analytics content will be displayed here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

