import { Navbar } from "@/components/navbar"
import { ProjectLeaderboard } from "@/components/project-leaderboard"
import { Sparkles, Zap, Users } from "lucide-react"

export default function ProjectsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Solana Projects</h1>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="md:col-span-2 lg:col-span-3">
            <ProjectLeaderboard />
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden">
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="h-5 w-5 text-purple-500" />
                <h3 className="text-xl font-semibold">About Solana Projects</h3>
              </div>
              <p className="text-muted-foreground">
                Projects are initiatives that Nigerian Solana contributors can participate in to earn XP. The
                leaderboard shows the most active projects based on contribution points.
              </p>
            </div>
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden">
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap className="h-5 w-5 text-blue-500" />
                <h3 className="text-xl font-semibold">How to Contribute</h3>
              </div>
              <p className="text-muted-foreground">
                Contact your state admin to get involved in a Solana project. Contributions are reviewed and awarded
                points based on impact and effort in building the Nigerian Solana ecosystem.
              </p>
            </div>
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm overflow-hidden">
            <div className="p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Users className="h-5 w-5 text-green-500" />
                <h3 className="text-xl font-semibold">Project Benefits</h3>
              </div>
              <p className="text-muted-foreground">
                Contributing to Solana projects helps you build your on-chain reputation, develop blockchain skills, and
                connect with other talented individuals in the Nigerian Solana ecosystem.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

