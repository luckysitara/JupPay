import { Navbar } from "@/components/navbar"
import { ProjectLeaderboard } from "@/components/project-leaderboard"

export default function ProjectsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-6">Projects</h1>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <div className="md:col-span-2 lg:col-span-3">
            <ProjectLeaderboard />
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
            <div className="p-6 space-y-4">
              <h3 className="text-xl font-semibold">About Projects</h3>
              <p className="text-muted-foreground">
                Projects are initiatives that Nigerian contributors can participate in to earn XP. The leaderboard shows
                the most active projects based on contribution points.
              </p>
            </div>
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
            <div className="p-6 space-y-4">
              <h3 className="text-xl font-semibold">How to Contribute</h3>
              <p className="text-muted-foreground">
                Contact your state admin to get involved in a project. Contributions are reviewed and awarded points
                based on impact and effort.
              </p>
            </div>
          </div>

          <div className="rounded-lg border bg-card text-card-foreground shadow-sm">
            <div className="p-6 space-y-4">
              <h3 className="text-xl font-semibold">Project Benefits</h3>
              <p className="text-muted-foreground">
                Contributing to projects helps you build your reputation, develop new skills, and connect with other
                talented individuals in the Nigerian tech ecosystem.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}

