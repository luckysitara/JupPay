"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/database"
import type { User } from "@/types"

export function useUsers(limit?: number) {
  const [users, setUsers] = useState<User[]>([])
  const [totalCount, setTotalCount] = useState<number>(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    let isMounted = true

    async function fetchUsers() {
      try {
        setLoading(true)
        setError(null)

        // Get total count first
        const { count: totalUsers, error: countError } = await supabase
          .from("users_with_state")
          .select("*", { count: "exact", head: true })

        if (countError) throw countError
        if (isMounted) setTotalCount(totalUsers || 0)

        // Then fetch users with limit if provided
        let query = supabase.from("users_with_state").select("*").order("total_xp", { ascending: false })

        if (limit) {
          query = query.limit(limit)
        }

        const { data, error: fetchError } = await query

        if (!isMounted) return
        if (fetchError) throw fetchError

        if (data && data.length > 0) {
          const transformedUsers: User[] = data.map((user) => ({
            id: user.id,
            name: user.name,
            username: user.username,
            state: user.state,
            stateName: user.state_name,
            totalXp: user.total_xp,
            monthlyXp: user.monthly_xp,
            skills: user.skills,
            joinedAt: new Date(user.joined_at),
            walletAddress: user.wallet_address || null,
          }))
          setUsers(transformedUsers)
        } else {
          setUsers([])
        }
      } catch (err) {
        console.error("Error fetching users:", err)
        if (isMounted) {
          setError(err instanceof Error ? err : new Error("Failed to fetch users"))
        }
      } finally {
        if (isMounted) {
          setLoading(false)
        }
      }
    }

    fetchUsers()

    return () => {
      isMounted = false
    }
  }, [limit]) // Only re-fetch when limit changes

  return { users, totalCount, loading, error }
}

