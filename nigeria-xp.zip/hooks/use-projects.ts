"use client"

import { useState, useEffect } from "react"
import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { Project, TimeFilter } from "@/types"

// Mock data as fallback
const mockProjects: Project[] = [
  {
    id: "1",
    name: "Nigerian XP System",
    description: "A reputation system for Nigerian contributors",
    points: 5200,
    weeklyPoints: 450,
    monthlyPoints: 1200,
    yearlyPoints: 5200,
    createdAt: new Date("2023-01-15T00:00:00Z"),
    updatedAt: new Date("2023-06-20T00:00:00Z"),
  },
  {
    id: "2",
    name: "Lagos Hackathon",
    description: "Annual coding competition in Lagos",
    points: 4800,
    weeklyPoints: 350,
    monthlyPoints: 1100,
    yearlyPoints: 4800,
    createdAt: new Date("2023-02-10T00:00:00Z"),
    updatedAt: new Date("2023-06-15T00:00:00Z"),
  },
  {
    id: "3",
    name: "Abuja Tech Summit",
    description: "Technology conference in Abuja",
    points: 4200,
    weeklyPoints: 300,
    monthlyPoints: 950,
    yearlyPoints: 4200,
    createdAt: new Date("2023-03-05T00:00:00Z"),
    updatedAt: new Date("2023-06-10T00:00:00Z"),
  },
  {
    id: "4",
    name: "Nigerian Dev Community",
    description: "Online community for Nigerian developers",
    points: 3800,
    weeklyPoints: 250,
    monthlyPoints: 850,
    yearlyPoints: 3800,
    createdAt: new Date("2023-04-20T00:00:00Z"),
    updatedAt: new Date("2023-06-05T00:00:00Z"),
  },
  {
    id: "5",
    name: "Code for Nigeria",
    description: "Open source projects for Nigeria",
    points: 3500,
    weeklyPoints: 200,
    monthlyPoints: 800,
    yearlyPoints: 3500,
    createdAt: new Date("2023-05-15T00:00:00Z"),
    updatedAt: new Date("2023-06-01T00:00:00Z"),
  },
]

export function useProjects(timeFilter: TimeFilter = "all", limit?: number) {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    async function fetchProjects() {
      try {
        setLoading(true)

        // Check if Supabase is configured
        if (!isSupabaseConfigured()) {
          console.warn("Supabase is not configured. Using mock data instead.")
          // Use mock data sorted by the appropriate time filter
          const sortedMockProjects = mockProjects
            .sort((a, b) => {
              switch (timeFilter) {
                case "weekly":
                  return b.weeklyPoints - a.weeklyPoints
                case "monthly":
                  return b.monthlyPoints - a.monthlyPoints
                case "yearly":
                  return b.yearlyPoints - a.yearlyPoints
                default:
                  return b.points - a.points
              }
            })
            .slice(0, limit || mockProjects.length)

          setProjects(sortedMockProjects)
          return
        }

        // Determine which points column to order by based on the time filter
        let orderColumn = "points"
        switch (timeFilter) {
          case "weekly":
            orderColumn = "weekly_points"
            break
          case "monthly":
            orderColumn = "monthly_points"
            break
          case "yearly":
            orderColumn = "yearly_points"
            break
        }

        // Try to fetch from Supabase
        let query = supabase.from("projects").select("*").order(orderColumn, { ascending: false })

        // Apply limit if provided
        if (limit) {
          query = query.limit(limit)
        }

        const { data, error: supabaseError } = await query

        if (supabaseError) {
          console.error("Supabase error:", supabaseError)
          // Fall back to mock data
          setProjects(
            mockProjects
              .sort((a, b) => {
                switch (timeFilter) {
                  case "weekly":
                    return b.weeklyPoints - a.weeklyPoints
                  case "monthly":
                    return b.monthlyPoints - a.monthlyPoints
                  case "yearly":
                    return b.yearlyPoints - a.yearlyPoints
                  default:
                    return b.points - a.points
                }
              })
              .slice(0, limit || mockProjects.length),
          )
        } else if (data && data.length > 0) {
          // Transform the data to match our Project type
          const transformedProjects: Project[] = data.map((project) => ({
            id: project.id,
            name: project.name,
            description: project.description,
            points: project.points,
            weeklyPoints: project.weekly_points,
            monthlyPoints: project.monthly_points,
            yearlyPoints: project.yearly_points,
            createdAt: new Date(project.created_at),
            updatedAt: new Date(project.updated_at),
          }))
          setProjects(transformedProjects)
        } else {
          // If no data, use mock data
          setProjects(
            mockProjects
              .sort((a, b) => {
                switch (timeFilter) {
                  case "weekly":
                    return b.weeklyPoints - a.weeklyPoints
                  case "monthly":
                    return b.monthlyPoints - a.monthlyPoints
                  case "yearly":
                    return b.yearlyPoints - a.yearlyPoints
                  default:
                    return b.points - a.points
                }
              })
              .slice(0, limit || mockProjects.length),
          )
        }
      } catch (err) {
        console.error("Error fetching projects:", err)
        setError(err instanceof Error ? err : new Error("Failed to fetch projects"))
        // Fall back to mock data
        setProjects(
          mockProjects
            .sort((a, b) => {
              switch (timeFilter) {
                case "weekly":
                  return b.weeklyPoints - a.weeklyPoints
                case "monthly":
                  return b.monthlyPoints - a.monthlyPoints
                case "yearly":
                  return b.yearlyPoints - a.yearlyPoints
                default:
                  return b.points - a.points
              }
            })
            .slice(0, limit || mockProjects.length),
        )
      } finally {
        setLoading(false)
      }
    }

    fetchProjects()
  }, [timeFilter, limit])

  return { projects, loading, error }
}

