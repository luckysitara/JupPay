"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/database"
import type { Project, TimeFilter } from "@/types"

export function useProjects(timeFilter: TimeFilter = "all", limit?: number) {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    async function fetchProjects() {
      try {
        setLoading(true)
        setError(null)

        // Determine which points column to order by based on the time filter
        let orderColumn = "points"
        switch (timeFilter) {
          case "weekly":
            orderColumn = "weekly_points"
            break
          case "monthly":
            orderColumn = "monthly_points"
            break
          case "yearly":
            orderColumn = "yearly_points"
            break
        }

        // Try to fetch from Supabase
        let query = supabase.from("projects").select("*").order(orderColumn, { ascending: false })

        // Apply limit if provided
        if (limit) {
          query = query.limit(limit)
        }

        const { data, error: supabaseError } = await query

        if (supabaseError) {
          throw supabaseError
        }

        if (data && data.length > 0) {
          // Transform the data to match our Project type
          const transformedProjects: Project[] = data.map((project) => ({
            id: project.id,
            name: project.name,
            description: project.description,
            points: project.points,
            weeklyPoints: project.weekly_points,
            monthlyPoints: project.monthly_points,
            yearlyPoints: project.yearly_points,
            createdAt: new Date(project.created_at),
            updatedAt: new Date(project.updated_at),
          }))
          setProjects(transformedProjects)
        } else {
          setProjects([])
        }
      } catch (err) {
        console.error("Error fetching projects:", err instanceof Error ? err.message : String(err))
        setError(err instanceof Error ? err : new Error("Failed to fetch projects"))
      } finally {
        setLoading(false)
      }
    }

    fetchProjects()
  }, [timeFilter, limit])

  return { projects, loading, error }
}

