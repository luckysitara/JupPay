"use client"

import { useState, useEffect } from "react"
import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { State } from "@/types"

// Mock data as fallback
const mockStates: State[] = [
  { code: "AB", name: "Abuja" },
  { code: "AD", name: "Adamawa" },
  { code: "AK", name: "Akwa Ibom" },
  { code: "AN", name: "Anambra" },
  { code: "BA", name: "Bauchi" },
  { code: "BY", name: "Bayelsa" },
  { code: "BE", name: "Benue" },
  { code: "BO", name: "Borno" },
  { code: "CR", name: "Cross River" },
  { code: "DE", name: "Delta" },
  { code: "EB", name: "Ebonyi" },
  { code: "ED", name: "Edo" },
  { code: "EK", name: "Ekiti" },
  { code: "EN", name: "Enugu" },
  { code: "GO", name: "Gombe" },
  { code: "IM", name: "Imo" },
  { code: "JI", name: "Jigawa" },
  { code: "KD", name: "Kaduna" },
  { code: "KN", name: "Kano" },
  { code: "KT", name: "Katsina" },
  { code: "KE", name: "Kebbi" },
  { code: "KO", name: "Kogi" },
  { code: "KW", name: "Kwara" },
  { code: "LA", name: "Lagos" },
  { code: "NA", name: "Nasarawa" },
  { code: "NI", name: "Niger" },
  { code: "OG", name: "Ogun" },
  { code: "ON", name: "Ondo" },
  { code: "OS", name: "Osun" },
  { code: "OY", name: "Oyo" },
  { code: "PL", name: "Plateau" },
  { code: "RI", name: "Rivers" },
  { code: "SO", name: "Sokoto" },
  { code: "TA", name: "Taraba" },
  { code: "YO", name: "Yobe" },
  { code: "ZA", name: "Zamfara" },
]

export function useStates() {
  const [states, setStates] = useState<State[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  useEffect(() => {
    async function fetchStates() {
      try {
        setLoading(true)

        // Check if Supabase is configured
        if (!isSupabaseConfigured()) {
          console.warn("Supabase is not configured. Using mock data instead.")
          setStates(mockStates)
          setLoading(false)
          return
        }

        // Try to fetch from Supabase
        const { data, error: supabaseError } = await supabase.from("states").select("code, name").order("name")

        if (supabaseError) {
          console.error("Supabase error:", supabaseError)
          // Fall back to mock data
          setStates(mockStates)
        } else if (data && data.length > 0) {
          setStates(data as State[])
        } else {
          // If no data, use mock data
          setStates(mockStates)
        }
      } catch (err) {
        console.error("Error fetching states:", err)
        setError(err instanceof Error ? err : new Error("Failed to fetch states"))
        // Fall back to mock data
        setStates(mockStates)
      } finally {
        setLoading(false)
      }
    }

    fetchStates()
  }, [])

  return { states, loading, error }
}

