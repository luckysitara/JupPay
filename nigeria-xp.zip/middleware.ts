import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Define protected routes
  const isAdminRoute = path.startsWith("/admin") && !path.startsWith("/admin/login")

  // Check if the user is authenticated by looking for the adminUser in cookies
  const adminUserCookie = request.cookies.get("adminUser")?.value
  const isAuthenticated = !!adminUserCookie

  // If the route is protected and the user is not authenticated, redirect to login
  if (isAdminRoute && !isAuthenticated) {
    return NextResponse.redirect(new URL("/admin/login", request.url))
  }

  // If the user is authenticated and trying to access login, redirect to admin dashboard
  if (path === "/admin/login" && isAuthenticated) {
    return NextResponse.redirect(new URL("/admin", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*"],
}

