import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Define protected routes
  const isAdminRoute = path.startsWith("/admin") && !path.startsWith("/admin/login")

  // Define super admin only routes
  const isSuperAdminOnlyRoute =
    path.startsWith("/admin/projects") || path.startsWith("/admin/project-points") || path.startsWith("/admin/settings")

  // Check if the user is authenticated by looking for the adminUser in cookies
  const adminUserCookie = request.cookies.get("adminUser")?.value
  const isAuthenticated = !!adminUserCookie

  // Check if the user is a super admin
  let isSuperAdmin = false
  if (adminUserCookie) {
    try {
      const adminUser = JSON.parse(adminUserCookie)
      isSuperAdmin = adminUser.role === "SUPER_ADMIN"
    } catch (e) {
      // Invalid cookie format, not a super admin
    }
  }

  // If the route is protected and the user is not authenticated, redirect to login
  if (isAdminRoute && !isAuthenticated) {
    return NextResponse.redirect(new URL("/admin/login", request.url))
  }

  // If the route is super admin only and the user is not a super admin, redirect to admin dashboard
  if (isSuperAdminOnlyRoute && !isSuperAdmin) {
    return NextResponse.redirect(new URL("/admin", request.url))
  }

  // If the user is authenticated and trying to access login, redirect to admin dashboard
  if (path === "/admin/login" && isAuthenticated) {
    return NextResponse.redirect(new URL("/admin", request.url))
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*"],
}

