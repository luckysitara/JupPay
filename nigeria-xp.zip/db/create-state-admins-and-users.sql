-- Create state admins for all Nigerian states with strong secret keys
-- First, let's create a function to generate strong random keys
CREATE OR REPLACE FUNCTION generate_strong_key() RETURNS TEXT AS $$
DECLARE
  chars TEXT := 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()';
  result TEXT := '';
  i INTEGER := 0;
  key_length INTEGER := 24; -- Length of the key
BEGIN
  FOR i IN 1..key_length LOOP
    result := result || substr(chars, floor(random() * length(chars) + 1)::integer, 1);
  END LOOP;
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Create state admins for all Nigerian states
INSERT INTO admin_users (email, name, role, state, secret_key)
VALUES
  ('abuja@nigerianxp.com', 'Abuja Admin', 'STATE_ADMIN', 'AB', generate_strong_key()),
  ('adamawa@nigerianxp.com', 'Adamawa Admin', 'STATE_ADMIN', 'AD', generate_strong_key()),
  ('akwaibom@nigerianxp.com', 'Akwa Ibom Admin', 'STATE_ADMIN', 'AK', generate_strong_key()),
  ('anambra@nigerianxp.com', 'Anambra Admin', 'STATE_ADMIN', 'AN', generate_strong_key()),
  ('bauchi@nigerianxp.com', 'Bauchi Admin', 'STATE_ADMIN', 'BA', generate_strong_key()),
  ('bayelsa@nigerianxp.com', 'Bayelsa Admin', 'STATE_ADMIN', 'BY', generate_strong_key()),
  ('benue@nigerianxp.com', 'Benue Admin', 'STATE_ADMIN', 'BE', generate_strong_key()),
  ('borno@nigerianxp.com', 'Borno Admin', 'STATE_ADMIN', 'BO', generate_strong_key()),
  ('crossriver@nigerianxp.com', 'Cross River Admin', 'STATE_ADMIN', 'CR', generate_strong_key()),
  ('delta@nigerianxp.com', 'Delta Admin', 'STATE_ADMIN', 'DE', generate_strong_key()),
  ('ebonyi@nigerianxp.com', 'Ebonyi Admin', 'STATE_ADMIN', 'EB', generate_strong_key()),
  ('edo@nigerianxp.com', 'Edo Admin', 'STATE_ADMIN', 'ED', generate_strong_key()),
  ('ekiti@nigerianxp.com', 'Ekiti Admin', 'STATE_ADMIN', 'EK', generate_strong_key()),
  ('enugu@nigerianxp.com', 'Enugu Admin', 'STATE_ADMIN', 'EN', generate_strong_key()),
  ('gombe@nigerianxp.com', 'Gombe Admin', 'STATE_ADMIN', 'GO', generate_strong_key()),
  ('imo@nigerianxp.com', 'Imo Admin', 'STATE_ADMIN', 'IM', generate_strong_key()),
  ('jigawa@nigerianxp.com', 'Jigawa Admin', 'STATE_ADMIN', 'JI', generate_strong_key()),
  ('kaduna@nigerianxp.com', 'Kaduna Admin', 'STATE_ADMIN', 'KD', generate_strong_key()),
  ('kano@nigerianxp.com', 'Kano Admin', 'STATE_ADMIN', 'KN', generate_strong_key()),
  ('katsina@nigerianxp.com', 'Katsina Admin', 'STATE_ADMIN', 'KT', generate_strong_key()),
  ('kebbi@nigerianxp.com', 'Kebbi Admin', 'STATE_ADMIN', 'KE', generate_strong_key()),
  ('kogi@nigerianxp.com', 'Kogi Admin', 'STATE_ADMIN', 'KO', generate_strong_key()),
  ('kwara@nigerianxp.com', 'Kwara Admin', 'STATE_ADMIN', 'KW', generate_strong_key()),
  ('lagos@nigerianxp.com', 'Lagos Admin', 'STATE_ADMIN', 'LA', generate_strong_key()),
  ('nasarawa@nigerianxp.com', 'Nasarawa Admin', 'STATE_ADMIN', 'NA', generate_strong_key()),
  ('niger@nigerianxp.com', 'Niger Admin', 'STATE_ADMIN', 'NI', generate_strong_key()),
  ('ogun@nigerianxp.com', 'Ogun Admin', 'STATE_ADMIN', 'OG', generate_strong_key()),
  ('ondo@nigerianxp.com', 'Ondo Admin', 'STATE_ADMIN', 'ON', generate_strong_key()),
  ('osun@nigerianxp.com', 'Osun Admin', 'STATE_ADMIN', 'OS', generate_strong_key()),
  ('oyo@nigerianxp.com', 'Oyo Admin', 'STATE_ADMIN', 'OY', generate_strong_key()),
  ('plateau@nigerianxp.com', 'Plateau Admin', 'STATE_ADMIN', 'PL', generate_strong_key()),
  ('rivers@nigerianxp.com', 'Rivers Admin', 'STATE_ADMIN', 'RI', generate_strong_key()),
  ('sokoto@nigerianxp.com', 'Sokoto Admin', 'STATE_ADMIN', 'SO', generate_strong_key()),
  ('taraba@nigerianxp.com', 'Taraba Admin', 'STATE_ADMIN', 'TA', generate_strong_key()),
  ('yobe@nigerianxp.com', 'Yobe Admin', 'STATE_ADMIN', 'YO', generate_strong_key()),
  ('zamfara@nigerianxp.com', 'Zamfara Admin', 'STATE_ADMIN', 'ZA', generate_strong_key())
ON CONFLICT (email) DO UPDATE
SET name = EXCLUDED.name, role = EXCLUDED.role, state = EXCLUDED.state;

-- Create at least 2 sample users for each state
-- Abuja (AB)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Ibrahim Musa', 'ibrahim_musa_ab', 'AB', 1500, 300, ARRAY['Development', 'Strategy'], NOW() - INTERVAL '3 months'),
  ('Fatima Aliyu', 'fatima_aliyu', 'AB', 1200, 250, ARRAY['Writing', 'Operations'], NOW() - INTERVAL '2 months');

-- Adamawa (AD)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Mohammed Bello', 'mohammed_bello', 'AD', 1800, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Aisha Yusuf', 'aisha_yusuf', 'AD', 1600, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Akwa Ibom (AK)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Effiong Okon', 'effiong_okon', 'AK', 2100, 450, ARRAY['Development', 'Writing'], NOW() - INTERVAL '5 months'),
  ('Iniobong Essien', 'iniobong_essien', 'AK', 1900, 400, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '4 months');

-- Anambra (AN)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Chukwuma Okafor', 'chukwuma_okafor', 'AN', 2400, 500, ARRAY['Development', 'Operations'], NOW() - INTERVAL '6 months'),
  ('Chioma Nwosu', 'chioma_nwosu', 'AN', 2200, 450, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '5 months');

-- Bauchi (BA)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Yakubu Hassan', 'yakubu_hassan', 'BA', 1700, 350, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Hauwa Ibrahim', 'hauwa_ibrahim', 'BA', 1500, 300, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Bayelsa (BY)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Preye Diri', 'preye_diri', 'BY', 2000, 400, ARRAY['Development', 'Writing'], NOW() - INTERVAL '5 months'),
  ('Ebiere Alamieyeseigha', 'ebiere_alamieyeseigha', 'BY', 1800, 350, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '4 months');

-- Benue (BE)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Tersoo Ortom', 'tersoo_ortom', 'BE', 1900, 400, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Ngunan Adasu', 'ngunan_adasu', 'BE', 1700, 350, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Borno (BO)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Umar Goni', 'umar_goni', 'BO', 1600, 350, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Falmata Zanna', 'falmata_zanna', 'BO', 1400, 300, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Cross River (CR)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Effiom Ekpo', 'effiom_ekpo', 'CR', 2200, 450, ARRAY['Development', 'Writing'], NOW() - INTERVAL '5 months'),
  ('Arit Duke', 'arit_duke', 'CR', 2000, 400, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '4 months');

-- Delta (DE)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Ovie Omo', 'ovie_omo', 'DE', 2300, 500, ARRAY['Development', 'Operations'], NOW() - INTERVAL '6 months'),
  ('Ese Okagbare', 'ese_okagbare', 'DE', 2100, 450, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '5 months');

-- Ebonyi (EB)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Chukwuma Eze', 'chukwuma_eze', 'EB', 1800, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Nnenna Egwu', 'nnenna_egwu', 'EB', 1600, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Edo (ED)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Osaze Osagie', 'osaze_osagie', 'ED', 2100, 450, ARRAY['Development', 'Writing'], NOW() - INTERVAL '5 months'),
  ('Itohan Igbinedion', 'itohan_igbinedion', 'ED', 1900, 400, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '4 months');

-- Ekiti (EK)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Femi Adebayo', 'femi_adebayo', 'EK', 2000, 400, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Yemisi Fayemi', 'yemisi_fayemi', 'EK', 1800, 350, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Enugu (EN)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Chinedu Eze', 'chinedu_eze_en', 'EN', 2200, 450, ARRAY['Development', 'Design'], NOW() - INTERVAL '5 months'),
  ('Nneka Nnamani', 'nneka_nnamani', 'EN', 2000, 400, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '4 months');

-- Gombe (GO)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Usman Dankwambo', 'usman_dankwambo', 'GO', 1700, 350, ARRAY['Development', 'Writing'], NOW() - INTERVAL '4 months'),
  ('Amina Goje', 'amina_goje', 'GO', 1500, 300, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '3 months');

-- Imo (IM)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Chima Okorocha', 'chima_okorocha', 'IM', 2100, 450, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Adaeze Ihedioha', 'adaeze_ihedioha', 'IM', 1900, 400, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Jigawa (JI)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Sule Lamido', 'sule_lamido', 'JI', 1600, 350, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Hadiza Badaru', 'hadiza_badaru', 'JI', 1400, 300, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Kaduna (KD)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Ahmed El-Rufai', 'ahmed_elrufai', 'KD', 2300, 500, ARRAY['Development', 'Writing'], NOW() - INTERVAL '6 months'),
  ('Zainab Yero', 'zainab_yero', 'KD', 2100, 450, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '5 months');

-- Kano (KN)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Ibrahim Ganduje', 'ibrahim_ganduje', 'KN', 2400, 500, ARRAY['Development', 'Operations'], NOW() - INTERVAL '6 months'),
  ('Fatima Kwankwaso', 'fatima_kwankwaso', 'KN', 2200, 450, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '5 months');

-- Katsina (KT)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Aminu Masari', 'aminu_masari', 'KT', 1800, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Binta Yara Adua', 'binta_yaradua', 'KT', 1600, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Kebbi (KE)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Abubakar Bagudu', 'abubakar_bagudu', 'KE', 1700, 350, ARRAY['Development', 'Writing'], NOW() - INTERVAL '4 months'),
  ('Zainab Dakingari', 'zainab_dakingari', 'KE', 1500, 300, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '3 months');

-- Kogi (KO)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Yahaya Bello', 'yahaya_bello', 'KO', 1900, 400, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Rashidat Wada', 'rashidat_wada', 'KO', 1700, 350, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Kwara (KW)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Abdulrahman Abdulrazaq', 'abdulrahman_abdulrazaq', 'KW', 2000, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '5 months'),
  ('Aisha Saraki', 'aisha_saraki', 'KW', 1800, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '4 months');

-- Lagos (LA)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Babajide Sanwo-Olu', 'babajide_sanwoolu', 'LA', 2500, 550, ARRAY['Development', 'Writing'], NOW() - INTERVAL '6 months'),
  ('Bolanle Ambode', 'bolanle_ambode', 'LA', 2300, 500, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '5 months');

-- Nasarawa (NA)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Tanko Al-Makura', 'tanko_almakura', 'NA', 1800, 400, ARRAY['Development', 'Operations'], NOW() - INTERVAL '4 months'),
  ('Salamatu Sule', 'salamatu_sule', 'NA', 1600, 350, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '3 months');

-- Niger (NI)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Abubakar Bello', 'abubakar_bello', 'NI', 1900, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '5 months'),
  ('Amina Aliyu', 'amina_aliyu', 'NI', 1700, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '4 months');

-- Ogun (OG)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Dapo Abiodun', 'dapo_abiodun', 'OG', 2200, 450, ARRAY['Development', 'Writing'], NOW() - INTERVAL '5 months'),
  ('Funmi Amosun', 'funmi_amosun', 'OG', 2000, 400, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '4 months');

-- Ondo (ON)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Rotimi Akeredolu', 'rotimi_akeredolu', 'ON', 2100, 450, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Olufunke Mimiko', 'olufunke_mimiko', 'ON', 1900, 400, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Osun (OS)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Gboyega Oyetola', 'gboyega_oyetola', 'OS', 2000, 400, ARRAY['Development', 'Design'], NOW() - INTERVAL '5 months'),
  ('Sherifat Aregbesola', 'sherifat_aregbesola', 'OS', 1800, 350, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '4 months');

-- Oyo (OY)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Seyi Makinde', 'seyi_makinde', 'OY', 2300, 500, ARRAY['Development', 'Writing'], NOW() - INTERVAL '6 months'),
  ('Folake Ajimobi', 'folake_ajimobi', 'OY', 2100, 450, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '5 months');

-- Plateau (PL)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Simon Lalong', 'simon_lalong', 'PL', 1900, 400, ARRAY['Development', 'Operations'], NOW() - INTERVAL '5 months'),
  ('Pauline Jang', 'pauline_jang', 'PL', 1700, 350, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '4 months');

-- Rivers (RI)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Nyesom Wike', 'nyesom_wike', 'RI', 2400, 500, ARRAY['Development', 'Design'], NOW() - INTERVAL '6 months'),
  ('Judith Amaechi', 'judith_amaechi', 'RI', 2200, 450, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '5 months');

-- Sokoto (SO)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Aminu Tambuwal', 'aminu_tambuwal', 'SO', 1800, 400, ARRAY['Development', 'Writing'], NOW() - INTERVAL '4 months'),
  ('Asma u Wamakko', 'asmau_wamakko', 'SO', 1600, 350, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '3 months');

-- Taraba (TA)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Darius Ishaku', 'darius_ishaku', 'TA', 1700, 350, ARRAY['Development', 'Operations'], NOW() - INTERVAL '4 months'),
  ('Jumai Alhassan', 'jumai_alhassan', 'TA', 1500, 300, ARRAY['Writing', 'Strategy'], NOW() - INTERVAL '3 months');

-- Yobe (YO)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Mai Mala Buni', 'mai_mala_buni', 'YO', 1600, 350, ARRAY['Development', 'Design'], NOW() - INTERVAL '4 months'),
  ('Khadija Gaidam', 'khadija_gaidam', 'YO', 1400, 300, ARRAY['Strategy', 'Operations'], NOW() - INTERVAL '3 months');

-- Zamfara (ZA)
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at)
VALUES
  ('Bello Matawalle', 'bello_matawalle', 'ZA', 1700, 350, ARRAY['Development', 'Writing'], NOW() - INTERVAL '4 months'),
  ('Aisha Yari', 'aisha_yari', 'ZA', 1500, 300, ARRAY['Design', 'Strategy'], NOW() - INTERVAL '3 months');

-- Create a view to display admin users with their secret keys
CREATE OR REPLACE VIEW admin_users_with_keys AS
SELECT id, email, name, role, state, secret_key
FROM admin_users
ORDER BY role, state;

-- Output the secret keys for reference
SELECT email, name, role, state, secret_key FROM admin_users_with_keys;

