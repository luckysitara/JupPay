-- Create projects table if it doesn't exist
CREATE TABLE IF NOT EXISTS projects (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  description TEXT,
  points INTEGER NOT NULL DEFAULT 0,
  weekly_points INTEGER NOT NULL DEFAULT 0,
  monthly_points INTEGER NOT NULL DEFAULT 0,
  yearly_points INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create project_contributions table to track user contributions to projects
CREATE TABLE IF NOT EXISTS project_contributions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id UUID NOT NULL REFERENCES admin_users(id),
  points INTEGER NOT NULL CHECK (points > 0),
  reason TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(project_id, user_id, created_at)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_points ON projects(points DESC);
CREATE INDEX IF NOT EXISTS idx_projects_weekly_points ON projects(weekly_points DESC);
CREATE INDEX IF NOT EXISTS idx_projects_monthly_points ON projects(monthly_points DESC);
CREATE INDEX IF NOT EXISTS idx_projects_yearly_points ON projects(yearly_points DESC);
CREATE INDEX IF NOT EXISTS idx_project_contributions_project_id ON project_contributions(project_id);
CREATE INDEX IF NOT EXISTS idx_project_contributions_user_id ON project_contributions(user_id);
CREATE INDEX IF NOT EXISTS idx_project_contributions_created_at ON project_contributions(created_at DESC);

-- Create function to update project points
CREATE OR REPLACE FUNCTION update_project_points()
RETURNS TRIGGER AS $$
DECLARE
  contribution_date TIMESTAMP WITH TIME ZONE;
BEGIN
  contribution_date := NEW.created_at;

  -- Update total points
  UPDATE projects
  SET points = points + NEW.points
  WHERE id = NEW.project_id;

  -- Update weekly points if contribution is from current week
  IF DATE_TRUNC('week', contribution_date) = DATE_TRUNC('week', NOW()) THEN
    UPDATE projects
    SET weekly_points = weekly_points + NEW.points
    WHERE id = NEW.project_id;
  END IF;

  -- Update monthly points if contribution is from current month
  IF DATE_TRUNC('month', contribution_date) = DATE_TRUNC('month', NOW()) THEN
    UPDATE projects
    SET monthly_points = monthly_points + NEW.points
    WHERE id = NEW.project_id;
  END IF;

  -- Update yearly points if contribution is from current year
  IF DATE_TRUNC('year', contribution_date) = DATE_TRUNC('year', NOW()) THEN
    UPDATE projects
    SET yearly_points = yearly_points + NEW.points
    WHERE id = NEW.project_id;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update project points on contribution insert
DROP TRIGGER IF EXISTS update_project_points_on_contribution ON project_contributions;
CREATE TRIGGER update_project_points_on_contribution
AFTER INSERT ON project_contributions
FOR EACH ROW
EXECUTE FUNCTION update_project_points();

-- Create trigger for updated_at on projects
DROP TRIGGER IF EXISTS update_projects_timestamp ON projects;
CREATE TRIGGER update_projects_timestamp
BEFORE UPDATE ON projects
FOR EACH ROW
EXECUTE FUNCTION update_timestamp();

