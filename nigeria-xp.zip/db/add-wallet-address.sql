-- Add wallet_address column to users table if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT FROM information_schema.columns 
    WHERE table_name = 'users' AND column_name = 'wallet_address'
  ) THEN
    ALTER TABLE users ADD COLUMN wallet_address TEXT;
  END IF;
END $$;

-- Update users_with_state view to include wallet_address
CREATE OR REPLACE VIEW users_with_state AS
SELECT 
  u.id,
  u.name,
  u.username,
  u.state,
  s.name AS state_name,
  u.total_xp,
  u.monthly_xp,
  u.skills,
  u.wallet_address,
  u.joined_at,
  u.created_at,
  u.updated_at
FROM users u
JOIN states s ON u.state = s.code;

