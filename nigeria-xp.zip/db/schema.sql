-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS xp_transactions;
DROP TABLE IF EXISTS admin_users;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS states;

-- Create Nigerian states lookup table
CREATE TABLE states (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL REFERENCES states(code),
  total_xp INTEGER NOT NULL DEFAULT 0,
  monthly_xp INTEGER NOT NULL DEFAULT 0,
  skills TEXT[] NOT NULL DEFAULT '{}',
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create admin users table
CREATE TABLE admin_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('STATE_ADMIN', 'SUPER_ADMIN')),
  state TEXT REFERENCES states(code),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  CONSTRAINT state_admin_must_have_state CHECK (
    (role = 'STATE_ADMIN' AND state IS NOT NULL) OR
    (role = 'SUPER_ADMIN')
  )
);

-- Create XP transactions table
CREATE TABLE xp_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id UUID NOT NULL REFERENCES admin_users(id),
  amount INTEGER NOT NULL CHECK (amount > 0),
  reason TEXT NOT NULL,
  skills TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_users_state ON users(state);
CREATE INDEX idx_users_total_xp ON users(total_xp DESC);
CREATE INDEX idx_users_monthly_xp ON users(monthly_xp DESC);
CREATE INDEX idx_xp_transactions_user_id ON xp_transactions(user_id);
CREATE INDEX idx_xp_transactions_created_at ON xp_transactions(created_at DESC);

-- Create a view to get users with their state names
CREATE OR REPLACE VIEW users_with_state AS
SELECT 
  u.id,
  u.name,
  u.username,
  u.state,
  s.name AS state_name,
  u.total_xp,
  u.monthly_xp,
  u.skills,
  u.joined_at,
  u.created_at,
  u.updated_at
FROM users u
JOIN states s ON u.state = s.code;

-- Enable Row Level Security (RLS)
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE xp_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE states ENABLE ROW LEVEL SECURITY;

-- Create policies for users table
-- Everyone can read users
CREATE POLICY "Anyone can read users" 
ON users FOR SELECT 
TO authenticated, anon
USING (true);

-- Only super admins can create users
CREATE POLICY "Super admins can create users" 
ON users FOR INSERT 
TO authenticated
USING ((auth.jwt() ->> 'role') = 'SUPER_ADMIN');

-- State admins can only update users in their state
CREATE POLICY "State admins can update users in their state" 
ON users FOR UPDATE 
TO authenticated
USING (
  (auth.jwt() ->> 'role') = 'SUPER_ADMIN' OR 
  ((auth.jwt() ->> 'role') = 'STATE_ADMIN' AND (auth.jwt() ->> 'state') = state)
);

-- Only super admins can delete users
CREATE POLICY "Only super admins can delete users" 
ON users FOR DELETE 
TO authenticated
USING ((auth.jwt() ->> 'role') = 'SUPER_ADMIN');

-- Create policies for admin_users table
-- Only super admins can manage admin users
CREATE POLICY "Only super admins can manage admin users" 
ON admin_users FOR ALL 
TO authenticated
USING ((auth.jwt() ->> 'role') = 'SUPER_ADMIN');

-- Admins can read their own profile
CREATE POLICY "Admins can read their own profile" 
ON admin_users FOR SELECT 
TO authenticated
USING (email = auth.email());

-- Create policies for xp_transactions table
-- Everyone can read transactions
CREATE POLICY "Anyone can read transactions" 
ON xp_transactions FOR SELECT 
TO authenticated, anon
USING (true);

-- State admins can only create transactions for users in their state
CREATE POLICY "State admins can create transactions for their state users" 
ON xp_transactions FOR INSERT 
TO authenticated
WITH CHECK (
  (auth.jwt() ->> 'role') = 'SUPER_ADMIN' OR 
  EXISTS (
    SELECT 1 FROM users 
    WHERE users.id = xp_transactions.user_id 
    AND users.state = (auth.jwt() ->> 'state')
  )
);

-- Only super admins can delete transactions
CREATE POLICY "Only super admins can delete transactions" 
ON xp_transactions FOR DELETE 
TO authenticated
USING ((auth.jwt() ->> 'role') = 'SUPER_ADMIN');

-- Create policies for states table
-- Everyone can read states
CREATE POLICY "Anyone can read states" 
ON states FOR SELECT 
TO authenticated, anon
USING (true);

-- Only super admins can manage states
CREATE POLICY "Only super admins can manage states" 
ON states FOR INSERT, UPDATE, DELETE 
TO authenticated
USING ((auth.jwt() ->> 'role') = 'SUPER_ADMIN');

-- Create function to update user XP
CREATE OR REPLACE FUNCTION update_user_xp()
RETURNS TRIGGER AS $$
BEGIN
  -- Update total XP
  UPDATE users
  SET total_xp = total_xp + NEW.amount
  WHERE id = NEW.user_id;
  
  -- Update monthly XP if transaction is from current month
  IF DATE_TRUNC('month', NEW.created_at) = DATE_TRUNC('month', NOW()) THEN
    UPDATE users
    SET monthly_xp = monthly_xp + NEW.amount
    WHERE id = NEW.user_id;
  END IF;
  
  -- Update skills if provided
  IF array_length(NEW.skills, 1) > 0 THEN
    UPDATE users
    SET skills = array_cat(skills, NEW.skills)
    WHERE id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update user XP on transaction insert
DROP TRIGGER IF EXISTS update_user_xp_on_transaction ON xp_transactions;
CREATE TRIGGER update_user_xp_on_transaction
AFTER INSERT ON xp_transactions
FOR EACH ROW
EXECUTE FUNCTION update_user_xp();

-- Create function to reset monthly XP at the beginning of each month
CREATE OR REPLACE FUNCTION reset_monthly_xp()
RETURNS VOID AS $$
BEGIN
  UPDATE users SET monthly_xp = 0;
END;
$$ LANGUAGE plpgsql;

-- Create a function to update the updated_at timestamp
CREATE OR REPLACE FUNCTION update_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
DROP TRIGGER IF EXISTS update_users_timestamp ON users;
CREATE TRIGGER update_users_timestamp
BEFORE UPDATE ON users
FOR EACH ROW
EXECUTE FUNCTION update_timestamp();

DROP TRIGGER IF EXISTS update_admin_users_timestamp ON admin_users;
CREATE TRIGGER update_admin_users_timestamp
BEFORE UPDATE ON admin_users
FOR EACH ROW
EXECUTE FUNCTION update_timestamp();

