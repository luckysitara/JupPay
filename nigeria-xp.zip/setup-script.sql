-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create Nigerian states lookup table
CREATE TABLE states (
  code TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  username TEXT NOT NULL UNIQUE,
  state TEXT NOT NULL REFERENCES states(code),
  total_xp INTEGER NOT NULL DEFAULT 0,
  monthly_xp INTEGER NOT NULL DEFAULT 0,
  skills TEXT[] NOT NULL DEFAULT '{}',
  joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create admin users table
CREATE TABLE admin_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('STATE_ADMIN', 'SUPER_ADMIN')),
  state TEXT REFERENCES states(code),
  secret_key TEXT NOT NULL UNIQUE DEFAULT md5(random()::text),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  CONSTRAINT state_admin_must_have_state CHECK (
    (role = 'STATE_ADMIN' AND state IS NOT NULL) OR
    (role = 'SUPER_ADMIN')
  )
);

-- Create XP transactions table
CREATE TABLE xp_transactions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  admin_id UUID NOT NULL REFERENCES admin_users(id),
  amount INTEGER NOT NULL CHECK (amount > 0),
  reason TEXT NOT NULL,
  skills TEXT[] DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX idx_users_state ON users(state);
CREATE INDEX idx_users_total_xp ON users(total_xp DESC);
CREATE INDEX idx_users_monthly_xp ON users(monthly_xp DESC);
CREATE INDEX idx_xp_transactions_user_id ON xp_transactions(user_id);
CREATE INDEX idx_xp_transactions_created_at ON xp_transactions(created_at DESC);
CREATE INDEX idx_admin_users_secret_key ON admin_users(secret_key);

-- Create a view to get users with their state names
CREATE OR REPLACE VIEW users_with_state AS
SELECT 
  u.id,
  u.name,
  u.username,
  u.state,
  s.name AS state_name,
  u.total_xp,
  u.monthly_xp,
  u.skills,
  u.joined_at,
  u.created_at,
  u.updated_at
FROM users u
JOIN states s ON u.state = s.code;

-- Seed Nigerian states
INSERT INTO states (code, name) VALUES
('AB', 'Abuja'),
('AD', 'Adamawa'),
('AK', 'Akwa Ibom'),
('AN', 'Anambra'),
('BA', 'Bauchi'),
('BY', 'Bayelsa'),
('BE', 'Benue'),
('BO', 'Borno'),
('CR', 'Cross River'),
('DE', 'Delta'),
('EB', 'Ebonyi'),
('ED', 'Edo'),
('EK', 'Ekiti'),
('EN', 'Enugu'),
('GO', 'Gombe'),
('IM', 'Imo'),
('JI', 'Jigawa'),
('KD', 'Kaduna'),
('KN', 'Kano'),
('KT', 'Katsina'),
('KE', 'Kebbi'),
('KO', 'Kogi'),
('KW', 'Kwara'),
('LA', 'Lagos'),
('NA', 'Nasarawa'),
('NI', 'Niger'),
('OG', 'Ogun'),
('ON', 'Ondo'),
('OS', 'Osun'),
('OY', 'Oyo'),
('PL', 'Plateau'),
('RI', 'Rivers'),
('SO', 'Sokoto'),
('TA', 'Taraba'),
('YO', 'Yobe'),
('ZA', 'Zamfara');

-- Create a super admin user
INSERT INTO admin_users (email, name, role, secret_key) VALUES
('admin@nigerianxp.com', 'Super Admin', 'SUPER_ADMIN', 'super-admin-key');

-- Create state admin users
INSERT INTO admin_users (email, name, role, state, secret_key) VALUES
('lagos@nigerianxp.com', 'Lagos Admin', 'STATE_ADMIN', 'LA', 'lagos-admin-key'),
('abuja@nigerianxp.com', 'Abuja Admin', 'STATE_ADMIN', 'AB', 'abuja-admin-key'),
('rivers@nigerianxp.com', 'Rivers Admin', 'STATE_ADMIN', 'RI', 'rivers-admin-key');

