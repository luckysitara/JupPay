import { createClient } from "@supabase/supabase-js"
import dotenv from "dotenv"

// Load environment variables
dotenv.config()

async function seedProjects() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Seeding projects...")

    // Sample projects
    const projects = [
      {
        name: "Solana Pay Integration",
        description: "Implementation of Solana Pay for Nigerian merchants",
        points: 4800,
        weekly_points: 350,
        monthly_points: 1200,
        yearly_points: 4800,
      },
      {
        name: "Solana NFT Marketplace",
        description: "A Nigerian-focused NFT marketplace built on Solana",
        points: 5600,
        weekly_points: 420,
        monthly_points: 1500,
        yearly_points: 5600,
      },
      {
        name: "Solana DeFi Dashboard",
        description: "Analytics dashboard for Solana DeFi protocols",
        points: 4200,
        weekly_points: 280,
        monthly_points: 950,
        yearly_points: 4200,
      },
      {
        name: "Solana Wallet Adapter",
        description: "Custom wallet adapter for Nigerian Solana users",
        points: 3800,
        weekly_points: 240,
        monthly_points: 850,
        yearly_points: 3800,
      },
      {
        name: "Solana Hackathon Projects",
        description: "Collection of projects from Nigerian Solana Hackathons",
        points: 6200,
        weekly_points: 480,
        monthly_points: 1800,
        yearly_points: 6200,
      },
      {
        name: "Solana Education Portal",
        description: "Educational resources for Solana development in Nigeria",
        points: 3500,
        weekly_points: 220,
        monthly_points: 780,
        yearly_points: 3500,
      },
      {
        name: "Solana Mobile dApp",
        description: "Mobile application for Solana ecosystem access",
        points: 4100,
        weekly_points: 260,
        monthly_points: 920,
        yearly_points: 4100,
      },
      {
        name: "Solana Governance Tool",
        description: "DAO governance tool for Nigerian Solana projects",
        points: 3900,
        weekly_points: 250,
        monthly_points: 880,
        yearly_points: 3900,
      },
      {
        name: "Solana Game Development",
        description: "Blockchain gaming projects built on Solana",
        points: 5100,
        weekly_points: 400,
        monthly_points: 1400,
        yearly_points: 5100,
      },
      {
        name: "Solana Cross-Chain Bridge",
        description: "Bridge connecting Solana to other blockchains for Nigerian users",
        points: 4700,
        weekly_points: 340,
        monthly_points: 1150,
        yearly_points: 4700,
      },
    ]

    // Insert projects
    for (const project of projects) {
      const { error } = await supabase.from("projects").insert(project)
      if (error) {
        console.error(`Error inserting project ${project.name}:`, error.message)
      } else {
        console.log(`Added project: ${project.name}`)
      }
    }

    console.log("Successfully seeded projects!")
  } catch (error) {
    console.error("Error:", error)
    process.exit(1)
  }
}

seedProjects()

