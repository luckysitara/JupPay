import { createClient } from "@supabase/supabase-js"
import { randomUUID } from "crypto"

async function addSecretKeys() {
  // Load environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Checking admin users...")

    // Get all admin users
    const { data: adminUsers, error: fetchError } = await supabase.from("admin_users").select("*")

    if (fetchError) {
      throw new Error(`Error fetching admin users: ${fetchError.message}`)
    }

    if (!adminUsers || adminUsers.length === 0) {
      console.log("No admin users found in the database.")
      return
    }

    console.log(`Found ${adminUsers.length} admin users.`)

    // Check if secret_key column exists
    const { data: columns, error: columnsError } = await supabase
      .from("information_schema.columns")
      .select("column_name")
      .eq("table_name", "admin_users")
      .eq("table_schema", "public")

    if (columnsError) {
      throw new Error(`Error checking columns: ${columnsError.message}`)
    }

    const columnNames = columns.map((c) => c.column_name)
    const hasSecretKeyColumn = columnNames.includes("secret_key")

    if (!hasSecretKeyColumn) {
      console.log("The secret_key column doesn't exist. Adding it now...")

      // Add secret_key column
      const { error: alterError } = await supabase.rpc("exec_sql", {
        sql: "ALTER TABLE admin_users ADD COLUMN IF NOT EXISTS secret_key TEXT",
      })

      if (alterError) {
        throw new Error(`Error adding secret_key column: ${alterError.message}`)
      }

      console.log("Added secret_key column successfully.")
    }

    // Count users without secret keys
    const usersWithoutKeys = adminUsers.filter((user) => !user.secret_key)
    console.log(`Found ${usersWithoutKeys.length} users without secret keys.`)

    // Update users without secret keys
    for (const user of usersWithoutKeys) {
      const secretKey = randomUUID()

      const { error: updateError } = await supabase
        .from("admin_users")
        .update({ secret_key: secretKey })
        .eq("id", user.id)

      if (updateError) {
        console.error(`Error updating user ${user.id}: ${updateError.message}`)
        continue
      }

      console.log(`Updated user ${user.name || user.email || user.id} with secret key: ${secretKey}`)
    }

    // Get updated admin users
    const { data: updatedUsers, error: updatedError } = await supabase.from("admin_users").select("*")

    if (updatedError) {
      throw new Error(`Error fetching updated admin users: ${updatedError.message}`)
    }

    console.log("\nAdmin Users with Secret Keys:")
    console.log("=============================")

    updatedUsers?.forEach((user) => {
      console.log(`${user.name || "Unnamed"} (${user.email || "No email"}):`)
      console.log(`Secret Key: ${user.secret_key || "No key"}`)
      console.log("---")
    })

    console.log("\nScript completed successfully!")
  } catch (error) {
    console.error("Error:", error)
    process.exit(1)
  }
}

addSecretKeys()

