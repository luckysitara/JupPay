import { createClient } from "@supabase/supabase-js"
import dotenv from "dotenv"

// Load environment variables
dotenv.config()

async function getAdminKeys() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Fetching admin users and their secret keys...")

    // Get all admin users
    const { data: adminUsers, error: fetchError } = await supabase
      .from("admin_users")
      .select("email, name, role, state, secret_key")
      .order("role", { ascending: false })
      .order("state")

    if (fetchError) {
      throw new Error(`Error fetching admin users: ${fetchError.message}`)
    }

    if (!adminUsers || adminUsers.length === 0) {
      console.log("No admin users found in the database.")
      return
    }

    console.log(`Found ${adminUsers.length} admin users.`)
    console.log("\nAdmin Users with Secret Keys:")
    console.log("=============================")

    adminUsers.forEach((admin) => {
      console.log(`${admin.name} (${admin.email}) - ${admin.role}${admin.state ? ` (${admin.state})` : ""}:`)
      console.log(`Secret Key: ${admin.secret_key || "No key"}`)
      console.log("---")
    })

    console.log("\nScript completed successfully!")
  } catch (error) {
    console.error("Error:", error)
    process.exit(1)
  }
}

getAdminKeys()

