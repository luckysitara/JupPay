import { createClient } from "@supabase/supabase-js"
import fs from "fs"
import path from "path"
import dotenv from "dotenv"

// Load environment variables
dotenv.config()

async function createProjectsTables() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Creating projects tables...")

    // Read SQL file
    const sqlPath = path.join(process.cwd(), "db", "create-projects-tables.sql")
    const sql = fs.readFileSync(sqlPath, "utf8")

    // Execute SQL
    const { error } = await supabase.rpc("exec_sql", { sql })

    if (error) {
      throw new Error(`Error executing SQL: ${error.message}`)
    }

    console.log("Successfully created projects tables!")
  } catch (error) {
    console.error("Error:", error)
    process.exit(1)
  }
}

createProjectsTables()

