// JavaScript version of the update-admin-keys script
const { createClient } = require("@supabase/supabase-js")
const fs = require("fs")
const path = require("path")

async function updateAdminKeys() {
  // Load environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Updating admin secret keys...")

    // Read update schema SQL file
    const schemaPath = path.join(process.cwd(), "db", "update-schema.sql")
    const schemaSql = fs.readFileSync(schemaPath, "utf8")

    // Execute schema SQL
    console.log("Updating database schema...")
    const { error: schemaError } = await supabase.rpc("exec_sql", { sql: schemaSql })

    if (schemaError) {
      throw new Error(`Error updating schema: ${schemaError.message}`)
    }

    // Fetch all admin users to display their secret keys
    const { data: admins, error: fetchError } = await supabase
      .from("admin_users")
      .select("email, name, role, state, secret_key")

    if (fetchError) {
      throw new Error(`Error fetching admin users: ${fetchError.message}`)
    }

    console.log("\nAdmin Secret Keys:")
    console.log("=================")

    admins?.forEach((admin) => {
      console.log(`${admin.name} (${admin.email}) - ${admin.role}${admin.state ? ` (${admin.state})` : ""}:`)
      console.log(`Secret Key: ${admin.secret_key}`)
      console.log("---")
    })

    console.log("\nDatabase update completed successfully!")
    console.log("Please save these secret keys securely as they will be needed for admin login.")
  } catch (error) {
    console.error("Error updating database:", error)
    process.exit(1)
  }
}

updateAdminKeys()

