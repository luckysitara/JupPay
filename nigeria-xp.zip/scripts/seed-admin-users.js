// JavaScript version of the seed-admin-users script
const { createClient } = require("@supabase/supabase-js")
const crypto = require("crypto")

async function seedAdminUsers() {
  // Load environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Seeding admin users...")

    // First, ensure the states table exists and has data
    const { data: states, error: statesError } = await supabase.from("states").select("code").limit(1)

    if (statesError) {
      console.error("Error checking states table:", statesError.message)
      console.log("You may need to run the database setup script first.")
      process.exit(1)
    }

    if (!states || states.length === 0) {
      console.error("States table is empty. Please run the database setup script first.")
      process.exit(1)
    }

    // Check if admin_users table already has data
    const { count, error: countError } = await supabase.from("admin_users").select("*", { count: "exact", head: true })

    if (countError) {
      console.error("Error checking admin_users table:", countError.message)
      process.exit(1)
    }

    if (count && count > 0) {
      console.log("Admin users already exist. Skipping seed.")
      console.log("To view admin secret keys, run the update-admin-keys script.")
      process.exit(0)
    }

    // Generate secret keys
    const superAdminKey = crypto.randomBytes(16).toString("hex")
    const lagosAdminKey = crypto.randomBytes(16).toString("hex")
    const abujaAdminKey = crypto.randomBytes(16).toString("hex")

    // Insert admin users
    const { error: insertError } = await supabase.from("admin_users").insert([
      {
        email: "admin@nigerianxp.com",
        name: "Super Admin",
        role: "SUPER_ADMIN",
        state: null,
        secret_key: superAdminKey,
      },
      {
        email: "lagos@nigerianxp.com",
        name: "Lagos Admin",
        role: "STATE_ADMIN",
        state: "LA",
        secret_key: lagosAdminKey,
      },
      {
        email: "abuja@nigerianxp.com",
        name: "Abuja Admin",
        role: "STATE_ADMIN",
        state: "AB",
        secret_key: abujaAdminKey,
      },
    ])

    if (insertError) {
      throw new Error(`Error inserting admin users: ${insertError.message}`)
    }

    console.log("\nAdmin users created successfully!")
    console.log("\nAdmin Secret Keys:")
    console.log("=================")
    console.log(`Super Admin (admin@nigerianxp.com):`)
    console.log(`Secret Key: ${superAdminKey}`)
    console.log("---")
    console.log(`Lagos Admin (lagos@nigerianxp.com):`)
    console.log(`Secret Key: ${lagosAdminKey}`)
    console.log("---")
    console.log(`Abuja Admin (abuja@nigerianxp.com):`)
    console.log(`Secret Key: ${abujaAdminKey}`)
    console.log("\nPlease save these secret keys securely as they will be needed for admin login.")
  } catch (error) {
    console.error("Error seeding admin users:", error)
    process.exit(1)
  }
}

seedAdminUsers()

