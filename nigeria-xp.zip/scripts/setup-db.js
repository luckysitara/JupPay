// JavaScript version of the setup-db script
const { createClient } = require("@supabase/supabase-js")
const fs = require("fs")
const path = require("path")

async function setupDatabase() {
  // Load environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Setting up database...")

    // Read schema SQL file
    const schemaPath = path.join(process.cwd(), "db", "schema.sql")
    const schemaSql = fs.readFileSync(schemaPath, "utf8")

    // Execute schema SQL
    console.log("Creating tables and functions...")
    const { error: schemaError } = await supabase.rpc("exec_sql", { sql: schemaSql })

    if (schemaError) {
      throw new Error(`Error creating schema: ${schemaError.message}`)
    }

    // Read seed SQL file
    const seedPath = path.join(process.cwd(), "db", "seed.sql")
    const seedSql = fs.readFileSync(seedPath, "utf8")

    // Execute seed SQL
    console.log("Seeding database...")
    const { error: seedError } = await supabase.rpc("exec_sql", { sql: seedSql })

    if (seedError) {
      throw new Error(`Error seeding database: ${seedError.message}`)
    }

    // Read project schema SQL file
    const projectSchemaPath = path.join(process.cwd(), "db", "project-schema.sql")
    const projectSchemaSql = fs.readFileSync(projectSchemaPath, "utf8")

    // Execute project schema SQL
    console.log("Creating project tables...")
    const { error: projectSchemaError } = await supabase.rpc("exec_sql", { sql: projectSchemaSql })

    if (projectSchemaError) {
      throw new Error(`Error creating project schema: ${projectSchemaError.message}`)
    }

    // Read Solana projects seed SQL file
    const solanaProjectsSeedPath = path.join(process.cwd(), "db", "solana-projects-seed.sql")
    const solanaProjectsSeedSql = fs.readFileSync(solanaProjectsSeedPath, "utf8")

    // Execute Solana projects seed SQL
    console.log("Seeding Solana projects...")
    const { error: solanaProjectsSeedError } = await supabase.rpc("exec_sql", { sql: solanaProjectsSeedSql })

    if (solanaProjectsSeedError) {
      throw new Error(`Error seeding Solana projects: ${solanaProjectsSeedError.message}`)
    }

    console.log("Database setup completed successfully!")
  } catch (error) {
    console.error("Error setting up database:", error)
    process.exit(1)
  }
}

setupDatabase()

