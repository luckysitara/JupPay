"use client"

import { useEffect, useState } from "react"
import { getAdminUser, isSuperAdmin } from "@/lib/auth"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { Users, Award, TrendingUp, Calendar } from "lucide-react"

export function AdminDashboardStats() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalXp: 0,
    stateUsers: 0,
    stateXp: 0,
    monthlyXp: 0,
    stateMonthlyXp: 0,
    activeProjects: 0,
  })
  const [loading, setLoading] = useState(true)
  const admin = getAdminUser()

  useEffect(() => {
    async function fetchStats() {
      try {
        setLoading(true)

        // Fetch total users count
        const { count: totalUsers, error: usersError } = await supabase
          .from("users")
          .select("*", { count: "exact", head: true })

        if (usersError) throw usersError

        // Fetch total XP
        const { data: xpData, error: xpError } = await supabase.from("users").select("total_xp, monthly_xp")

        if (xpError) throw xpError

        const totalXp = xpData.reduce((sum, user) => sum + user.total_xp, 0)
        const monthlyXp = xpData.reduce((sum, user) => sum + user.monthly_xp, 0)

        // Fetch active projects count
        const { count: activeProjects, error: projectsError } = await supabase
          .from("projects")
          .select("*", { count: "exact", head: true })

        // If state admin, fetch state-specific stats
        let stateUsers = 0
        let stateXp = 0
        let stateMonthlyXp = 0

        if (admin?.role === "STATE_ADMIN" && admin.state) {
          const { count, error: stateUsersError } = await supabase
            .from("users")
            .select("*", { count: "exact", head: true })
            .eq("state", admin.state)

          if (stateUsersError) throw stateUsersError

          stateUsers = count || 0

          const { data: stateXpData, error: stateXpError } = await supabase
            .from("users")
            .select("total_xp, monthly_xp")
            .eq("state", admin.state)

          if (stateXpError) throw stateXpError

          stateXp = stateXpData.reduce((sum, user) => sum + user.total_xp, 0)
          stateMonthlyXp = stateXpData.reduce((sum, user) => sum + user.monthly_xp, 0)
        }

        setStats({
          totalUsers: totalUsers || 0,
          totalXp,
          stateUsers,
          stateXp,
          monthlyXp,
          stateMonthlyXp,
          activeProjects: activeProjects || 0,
        })
      } catch (error) {
        console.error("Error fetching stats:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [admin])

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground h-4 bg-muted animate-pulse rounded"></CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-6 bg-muted animate-pulse rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {isSuperAdmin() ? (
        // Super Admin Stats
        <>
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
              <p className="text-xs text-muted-foreground">Across all states</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total XP Awarded</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalXp.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Monthly XP</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.monthlyXp.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">Active Projects</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeProjects}</div>
              <p className="text-xs text-muted-foreground">Ongoing projects</p>
            </CardContent>
          </Card>
        </>
      ) : (
        // State Admin Stats
        <>
          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">{admin?.state} Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.stateUsers}</div>
              <p className="text-xs text-muted-foreground">In your state</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">{admin?.state} Total XP</CardTitle>
              <Award className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.stateXp.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">{admin?.state} Monthly XP</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.stateMonthlyXp.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">This month</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2 flex flex-row items-center justify-between space-y-0">
              <CardTitle className="text-sm font-medium text-muted-foreground">National Ranking</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">#{Math.floor(Math.random() * 36) + 1}</div>
              <p className="text-xs text-muted-foreground">Out of 36 states</p>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}

