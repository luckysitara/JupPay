"use client"

import { useState } from "react"
import { supabase } from "@/lib/database"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import { useToast } from "@/components/ui/use-toast"
import type { Project } from "@/types"

interface AdminDeleteProjectDialogProps {
  project: Project
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess?: () => void
}

export function AdminDeleteProjectDialog({ project, open, onOpenChange, onSuccess }: AdminDeleteProjectDialogProps) {
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()

  async function handleDelete() {
    try {
      setSubmitting(true)

      // Delete project
      const { error } = await supabase.from("projects").delete().eq("id", project.id)

      if (error) throw error

      toast({
        title: "Project deleted",
        description: `${project.name} has been deleted successfully`,
      })

      // Close dialog
      onOpenChange(false)

      // Refresh projects list
      if (onSuccess) {
        onSuccess()
      }
    } catch (error) {
      console.error("Error deleting project:", error)
      toast({
        title: "Error",
        description: "Failed to delete project. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>
            This will permanently delete the project &quot;{project.name}&quot; and all associated data. This action
            cannot be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={submitting}
            className="bg-destructive text-destructive-foreground"
          >
            {submitting ? "Deleting..." : "Delete"}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  )
}

