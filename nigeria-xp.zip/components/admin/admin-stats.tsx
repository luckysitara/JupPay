"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { Users, Award, Briefcase, TrendingUp } from "lucide-react"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  created_at: string
}

type StatsProps = {
  adminUser: AdminUser
}

export function AdminStats({ adminUser }: StatsProps) {
  const [stats, setStats] = useState({
    totalUsers: 0,
    totalXP: 0,
    totalProjects: 0,
    activeUsers: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchStats = async () => {
      try {
        let usersQuery = supabase.from("users").select("*", { count: "exact", head: true })
        let xpQuery = supabase.from("xp_transactions").select("amount")
        const projectsQuery = supabase.from("projects").select("*", { count: "exact", head: true })

        // For state admins, filter by state
        if (adminUser.role === "state_admin" && adminUser.state_code) {
          usersQuery = usersQuery.eq("state_code", adminUser.state_code)
          xpQuery = xpQuery.eq("state_code", adminUser.state_code)
        }

        // Execute queries in parallel
        const [usersResult, xpResult, projectsResult] = await Promise.all([usersQuery, xpQuery, projectsQuery])

        // Calculate active users (users with XP transactions in the last 30 days)
        const thirtyDaysAgo = new Date()
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30)

        let activeUsersQuery = supabase
          .from("xp_transactions")
          .select("user_id", { count: "exact", head: true })
          .gt("created_at", thirtyDaysAgo.toISOString())
          .limit(1)

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          activeUsersQuery = activeUsersQuery.eq("state_code", adminUser.state_code)
        }

        const activeUsersResult = await activeUsersQuery

        // Calculate total XP
        const totalXP = xpResult.data?.reduce((sum, tx) => sum + (tx.amount || 0), 0) || 0

        setStats({
          totalUsers: usersResult.count || 0,
          totalXP,
          totalProjects: projectsResult.count || 0,
          activeUsers: activeUsersResult.count || 0,
        })
      } catch (error) {
        console.error("Error fetching stats:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchStats()
  }, [adminUser])

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Users</CardTitle>
          <Users className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{loading ? "..." : stats.totalUsers.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">
            {adminUser.role === "state_admin" ? `Users in ${adminUser.state_code}` : "Users across all states"}
          </p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total XP</CardTitle>
          <Award className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{loading ? "..." : stats.totalXP.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">XP points awarded to date</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Projects</CardTitle>
          <Briefcase className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{loading ? "..." : stats.totalProjects.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">Available projects</p>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Active Users</CardTitle>
          <TrendingUp className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{loading ? "..." : stats.activeUsers.toLocaleString()}</div>
          <p className="text-xs text-muted-foreground">Users active in the last 30 days</p>
        </CardContent>
      </Card>
    </div>
  )
}

