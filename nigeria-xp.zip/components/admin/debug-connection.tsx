"use client"

import { useState } from "react"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, CheckCircle } from "lucide-react"

export function DebugConnection() {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const [message, setMessage] = useState<string>("")
  const [details, setDetails] = useState<string>("")
  const [tableInfo, setTableInfo] = useState<{ name: string; count: number }[]>([])

  // Update the testConnection function to provide more detailed information

  const testConnection = async () => {
    setStatus("loading")
    setMessage("")
    setDetails("")
    setTableInfo([])

    try {
      console.log("Testing database connection...")

      // First, test basic connection
      const { data: connectionTest, error: connectionError } = await supabase.from('states').select('code').limit(1)
      
      if (connectionError) {
        throw new Error(`Connection failed: ${connectionError.message}`)
      }
      
      console.log("Basic connection successful, checking admin table...")

      // Check admin_users table
      const { data: adminData, error: adminError } = await supabase
        .from('admin_users')
        .select('email, name, role, secret_key')
        .limit(5)
      
      if (adminError) {
        throw new Error(`Error accessing admin_users table: ${adminError.message}`)
      }
      
      if (!adminData || adminData.length === 0) {
        setStatus("error")
        setMessage("Admin users table exists but has no data")
        setDetails("Please run the setup script to create admin users")
        return
      }
      
      // Check if admin users have secret keys
      const missingKeys = adminData.filter(admin => !admin.secret_key).length
      
      if (missingKeys > 0) {
        setStatus("error")
        setMessage(`Found ${missingKeys} admin users without secret keys`)
        setDetails("All admin users must have secret keys for login")
        return
      }
      
      // Get counts for main tables
      const tables = ['states', 'users', 'admin_users', 'xp_transactions']
      const tableInfoResults = []
      
      for (const tableName of tables) {
        try {
          const { count, error } = await supabase
            .from(tableName)
            .select('*', { count: 'exact', head: true })
          
        tableInfoResults.push({
          name: tableName,
          count: error ? -1 : (count || 0)
        })
      } catch (err) {
        tableInfoResults.push({
          name: tableName,
          count: -1
        })
      }
    }
    
    setTableInfo(tableInfoResults)
    
    setStatus("success")
    setMessage("Database connection successful!")
    setDetails(`Found ${adminData.length} admin users with valid secret keys. You can log in with one of the secret keys.`)
    
  } catch (err) {
    console.error("Connection test error:", err)
    setStatus("error")
    if (err instanceof Error) {
      setMessage("Database connection failed")
      setDetails(err.message)
    } else {
      setMessage("Unknown error occurred")
      setDetails(JSON.stringify(err))
    }
  }

  const testDirectTableAccess = async () => {
    try {
      // Try to directly access the admin_users table with a simpler query
      console.log("Attempting direct table access")

      const { data, error } = await supabase.from("admin_users").select("id").limit(1)

      if (error) {
        // Check if the error is about the table not existing
        if (error.message.includes("relation") && error.message.includes("does not exist")) {
          setStatus("error")
          setMessage("The admin_users table doesn't exist")
          setDetails("Please check your database schema or table name")
        } else {
          throw error
        }
        return
      }

      // If we get here, the table exists, so count the rows
      const { count, error: countError } = await supabase
        .from("admin_users")
        .select("*", { count: "exact", head: true })

      if (countError) {
        throw countError
      }

      setTableInfo([{ name: "admin_users", count: count || 0 }])

      if (count === 0) {
        setStatus("success")
        setMessage("Connected to Supabase successfully!")
        setDetails("Found 0 admin users. You need to add admin users to your database.")
      } else {
        setStatus("success")
        setMessage(`Successfully connected to Supabase!`)
        setDetails(`Found ${count} admin users.`)
      }
    } catch (err) {
      console.error("Direct table access error:", err)
      setStatus("error")
      if (err instanceof Error) {
        setMessage("Failed to access admin_users table")
        setDetails(err.message)
      } else {
        setMessage("Unknown error occurred")
        setDetails(JSON.stringify(err))
      }
    }
  }

  return (
    <div className="mt-4 space-y-2 w-full">
      <Button variant="outline" size="sm" onClick={testConnection} disabled={status === "loading"} className="w-full">
        {status === "loading" ? "Testing..." : "Test Database Connection"}
      </Button>

      {status === "success" && (
        <Alert
          variant="default"
          className="bg-green-50 text-green-800 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
        >
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>
            <p>{message}</p>
            {details && <p className="text-xs mt-1">{details}</p>}

            {tableInfo.length > 0 && (
              <div className="mt-2 text-xs">
                <p className="font-semibold">Table Information:</p>
                <ul className="list-disc pl-4 mt-1">
                  {tableInfo.map((table) => (
                    <li key={table.name}>
                      {table.name}:{" "}
                      {table.count === -2
                        ? "Table doesn't exist"
                        : table.count === -1
                          ? "Error accessing table"
                          : `${table.count} rows`}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </AlertDescription>
        </Alert>
      )}

      {status === "error" && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            <p>{message}</p>
            {details && <p className="text-xs mt-1 font-mono break-all">{details}</p>}
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}

