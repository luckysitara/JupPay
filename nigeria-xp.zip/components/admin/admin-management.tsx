"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { AdminUser, State } from "@/types"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { AlertCircle, CheckCircle2, Trash2 } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export function AdminManagement() {
  const [admins, setAdmins] = useState<AdminUser[]>([])
  const [states, setStates] = useState<State[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    role: "STATE_ADMIN" as "SUPER_ADMIN" | "STATE_ADMIN",
    state: "",
  })

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Fetch all admins
        const { data: adminData, error: adminError } = await supabase
          .from("admin_users")
          .select("*")
          .order("role", { ascending: false })
          .order("name")

        if (adminError) throw adminError

        // Transform to AdminUser type
        const adminUsers: AdminUser[] = adminData.map((admin) => ({
          id: admin.id,
          email: admin.email,
          name: admin.name,
          role: admin.role,
          state: admin.state,
          secret_key: admin.secret_key,
        }))

        setAdmins(adminUsers)

        // Fetch all states
        const { data: stateData, error: stateError } = await supabase.from("states").select("*").order("name")

        if (stateError) throw stateError

        // Transform to State type
        const stateList: State[] = stateData.map((state) => ({
          code: state.code,
          name: state.name,
        }))

        setStates(stateList)
      } catch (error) {
        console.error("Error fetching admin data:", error)
        setError("Failed to load admin data. Please try again.")
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSuccess(null)

    try {
      // Validate form
      if (!formData.name || !formData.email) {
        setError("Name and email are required")
        return
      }

      if (formData.role === "STATE_ADMIN" && !formData.state) {
        setError("State is required for State Admins")
        return
      }

      // Generate a random secret key
      const secretKey = generateSecretKey(24)

      // Create new admin
      const { data, error } = await supabase
        .from("admin_users")
        .insert({
          name: formData.name,
          email: formData.email,
          role: formData.role,
          state: formData.role === "STATE_ADMIN" ? formData.state : null,
          secret_key: secretKey,
        })
        .select()

      if (error) throw error

      // Add the new admin to the list
      if (data && data.length > 0) {
        const newAdmin: AdminUser = {
          id: data[0].id,
          email: data[0].email,
          name: data[0].name,
          role: data[0].role,
          state: data[0].state,
          secret_key: data[0].secret_key,
        }

        setAdmins((prev) => [...prev, newAdmin])
        setSuccess(`Admin ${newAdmin.name} created successfully with secret key: ${secretKey}`)

        // Reset form
        setFormData({
          name: "",
          email: "",
          role: "STATE_ADMIN",
          state: "",
        })
      }
    } catch (error) {
      console.error("Error creating admin:", error)
      setError("Failed to create admin. Please try again.")
    }
  }

  const handleDeleteAdmin = async (adminId: string) => {
    try {
      const { error } = await supabase.from("admin_users").delete().eq("id", adminId)

      if (error) throw error

      // Remove the admin from the list
      setAdmins((prev) => prev.filter((admin) => admin.id !== adminId))
      setSuccess("Admin deleted successfully")
    } catch (error) {
      console.error("Error deleting admin:", error)
      setError("Failed to delete admin. Please try again.")
    }
  }

  // Function to generate a random secret key
  const generateSecretKey = (length: number) => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_-+=<>?"
    let result = ""
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length))
    }
    return result
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {success && (
        <Alert variant="default" className="bg-green-50 border-green-200 text-green-800">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>{success}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Create New Admin</CardTitle>
          <CardDescription>Add a new admin user to the system</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Admin Name"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  name="email"
                  type="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="admin@example.com"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="role">Role</Label>
                <Select value={formData.role} onValueChange={(value) => handleSelectChange("role", value)}>
                  <SelectTrigger id="role">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="SUPER_ADMIN">Super Admin</SelectItem>
                    <SelectItem value="STATE_ADMIN">State Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {formData.role === "STATE_ADMIN" && (
                <div className="space-y-2">
                  <Label htmlFor="state">State</Label>
                  <Select value={formData.state} onValueChange={(value) => handleSelectChange("state", value)}>
                    <SelectTrigger id="state">
                      <SelectValue placeholder="Select state" />
                    </SelectTrigger>
                    <SelectContent>
                      {states.map((state) => (
                        <SelectItem key={state.code} value={state.code}>
                          {state.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>

            <Button type="submit" className="w-full">
              Create Admin
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Existing Admins</CardTitle>
          <CardDescription>Manage existing admin users</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Role</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Secret Key</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {admins.map((admin) => (
                <TableRow key={admin.id}>
                  <TableCell className="font-medium">{admin.name}</TableCell>
                  <TableCell>{admin.email}</TableCell>
                  <TableCell>{admin.role === "SUPER_ADMIN" ? "Super Admin" : "State Admin"}</TableCell>
                  <TableCell>{admin.state || "-"}</TableCell>
                  <TableCell>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          View Key
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Secret Key for {admin.name}</DialogTitle>
                          <DialogDescription>This key is used for authentication. Keep it secure.</DialogDescription>
                        </DialogHeader>
                        <div className="bg-muted p-3 rounded-md font-mono text-sm overflow-x-auto">
                          {admin.secret_key}
                        </div>
                        <DialogFooter>
                          <Button
                            onClick={() => {
                              navigator.clipboard.writeText(admin.secret_key)
                              setSuccess("Secret key copied to clipboard")
                            }}
                          >
                            Copy to Clipboard
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" onClick={() => handleDeleteAdmin(admin.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

