"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import type { State } from "@/types"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"

interface StatePerformance extends State {
  userCount: number
  totalXp: number
  rank: number
}

export function SuperAdminDashboard() {
  const [topStates, setTopStates] = useState<StatePerformance[]>([])
  const [loading, setLoading] = useState(true)
  const [adminCount, setAdminCount] = useState({ super: 0, state: 0 })

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Fetch states with user counts and XP
        const { data: states, error: statesError } = await supabase.from("states").select("code, name")

        if (statesError) throw statesError

        // For each state, get user count and total XP
        const statePerformance: StatePerformance[] = []

        for (const state of states) {
          // Get user count
          const { count: userCount, error: userCountError } = await supabase
            .from("users")
            .select("*", { count: "exact", head: true })
            .eq("state", state.code)

          if (userCountError) throw userCountError

          // Get total XP
          const { data: xpData, error: xpError } = await supabase
            .from("users")
            .select("total_xp")
            .eq("state", state.code)

          if (xpError) throw xpError

          const totalXp = xpData.reduce((sum, user) => sum + user.total_xp, 0)

          statePerformance.push({
            code: state.code,
            name: state.name,
            userCount: userCount || 0,
            totalXp,
            rank: 0, // Will be calculated after sorting
          })
        }

        // Sort by total XP and assign ranks
        statePerformance.sort((a, b) => b.totalXp - a.totalXp)
        statePerformance.forEach((state, index) => {
          state.rank = index + 1
        })

        // Get top 5 states
        setTopStates(statePerformance.slice(0, 5))

        // Get admin counts
        const { data: adminData, error: adminError } = await supabase.from("admin_users").select("role")

        if (adminError) throw adminError

        const superAdminCount = adminData.filter((admin) => admin.role === "SUPER_ADMIN").length
        const stateAdminCount = adminData.filter((admin) => admin.role === "STATE_ADMIN").length

        setAdminCount({
          super: superAdminCount,
          state: stateAdminCount,
        })
      } catch (error) {
        console.error("Error fetching super admin data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>Top Performing States</CardTitle>
          <CardDescription>States with the highest XP accumulation</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topStates.map((state) => (
              <div key={state.code} className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="w-6 h-6 flex items-center justify-center p-0">
                      {state.rank}
                    </Badge>
                    <span className="font-medium">{state.name}</span>
                  </div>
                  <span className="text-sm">{state.totalXp.toLocaleString()} XP</span>
                </div>
                <Progress value={(state.totalXp / (topStates[0]?.totalXp || 1)) * 100} className="h-2" />
                <div className="text-xs text-muted-foreground">{state.userCount} users</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>System Overview</CardTitle>
          <CardDescription>Platform statistics and admin information</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Super Admins</p>
                <p className="text-2xl font-bold">{adminCount.super}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">State Admins</p>
                <p className="text-2xl font-bold">{adminCount.state}</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">States Covered</p>
                <p className="text-2xl font-bold">{adminCount.state}/36</p>
              </div>
              <div className="space-y-2">
                <p className="text-sm font-medium text-muted-foreground">Admin Coverage</p>
                <p className="text-2xl font-bold">{Math.round((adminCount.state / 36) * 100)}%</p>
              </div>
            </div>

            <div className="pt-4">
              <h4 className="text-sm font-medium mb-2">Admin Distribution</h4>
              <Progress value={(adminCount.state / 36) * 100} className="h-2" />
              <p className="text-xs text-muted-foreground mt-2">{36 - adminCount.state} states still need admins</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

