"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import type { User } from "@/types"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface StateAdminDashboardProps {
  stateCode: string
}

export function StateAdminDashboard({ stateCode }: StateAdminDashboardProps) {
  const [topUsers, setTopUsers] = useState<User[]>([])
  const [stateName, setStateName] = useState("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchData() {
      try {
        setLoading(true)

        // Fetch state name
        const { data: stateData, error: stateError } = await supabase
          .from("states")
          .select("name")
          .eq("code", stateCode)
          .single()

        if (stateError) throw stateError
        if (stateData) setStateName(stateData.name)

        // Fetch top users for this state
        const { data: userData, error: userError } = await supabase
          .from("users")
          .select("id, name, username, total_xp, monthly_xp, skills")
          .eq("state", stateCode)
          .order("total_xp", { ascending: false })
          .limit(5)

        if (userError) throw userError

        // Transform to User type
        const users: User[] = userData.map((user) => ({
          id: user.id,
          name: user.name,
          username: user.username,
          state: stateCode,
          stateName: stateName,
          totalXp: user.total_xp,
          monthlyXp: user.monthly_xp,
          skills: user.skills,
          joinedAt: new Date(),
        }))

        setTopUsers(users)
      } catch (error) {
        console.error("Error fetching state data:", error)
      } finally {
        setLoading(false)
      }
    }

    if (stateCode) {
      fetchData()
    }
  }, [stateCode])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>{stateName} State Overview</CardTitle>
          <CardDescription>Performance metrics for {stateName} state</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">Monthly Goal Progress</div>
                <div className="text-sm text-muted-foreground">75%</div>
              </div>
              <Progress value={75} className="h-2 mt-2" />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">User Engagement</div>
                <div className="text-sm text-muted-foreground">62%</div>
              </div>
              <Progress value={62} className="h-2 mt-2" />
            </div>

            <div>
              <div className="flex items-center justify-between">
                <div className="text-sm font-medium">Skill Diversity</div>
                <div className="text-sm text-muted-foreground">83%</div>
              </div>
              <Progress value={83} className="h-2 mt-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="md:col-span-1">
        <CardHeader>
          <CardTitle>Top Performers</CardTitle>
          <CardDescription>Highest XP earners in {stateName} state</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topUsers.map((user, index) => (
              <div key={user.id} className="flex items-center gap-4">
                <div className="font-medium text-muted-foreground w-4">{index + 1}</div>
                <Avatar className="h-8 w-8">
                  <AvatarImage src={`/placeholder.svg?height=32&width=32`} alt={user.name} />
                  <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium leading-none">{user.name}</p>
                    <p className="text-sm font-medium">{user.totalXp.toLocaleString()} XP</p>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {user.skills.slice(0, 2).map((skill) => (
                      <Badge key={skill} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                    {user.skills.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{user.skills.length - 2}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

