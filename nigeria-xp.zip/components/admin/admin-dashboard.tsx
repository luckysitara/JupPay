"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StateAdminDashboard } from "@/components/admin/state-admin-dashboard"
import { SuperAdminDashboard } from "@/components/admin/super-admin-dashboard"
import { RecentActivity } from "@/components/admin/recent-activity"
import { AdminStats } from "@/components/admin/admin-stats"
import { supabase } from "@/lib/database"
import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  created_at: string
}

export function AdminDashboard() {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    const getAdminUser = async () => {
      try {
        // Get admin user from cookie
        const adminCookie = document.cookie.split("; ").find((row) => row.startsWith("adminUser="))

        if (!adminCookie) {
          router.push("/admin/login")
          return
        }

        const adminUserData = JSON.parse(adminCookie.split("=")[1])

        // Fetch the latest admin data from the database
        const { data, error } = await supabase.from("admin_users").select("*").eq("id", adminUserData.id).single()

        if (error) {
          throw error
        }

        if (!data) {
          router.push("/admin/login")
          return
        }

        setAdminUser(data as AdminUser)
      } catch (err) {
        console.error("Error fetching admin user:", err)
        setError("Failed to load admin data. Please try logging in again.")
      } finally {
        setLoading(false)
      }
    }

    getAdminUser()
  }, [router])

  if (loading) {
    return <AdminDashboardSkeleton />
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mt-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  if (!adminUser) {
    return null
  }

  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Welcome back, {adminUser.name}</h2>
        <p className="text-muted-foreground">
          {adminUser.role === "super_admin"
            ? "Here's what's happening across the platform"
            : `Here's what's happening in your state`}
        </p>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
        </TabsList>
        <TabsContent value="overview" className="space-y-4">
          <AdminStats adminUser={adminUser} />

          {adminUser.role === "super_admin" ? (
            <SuperAdminDashboard />
          ) : (
            <StateAdminDashboard stateCode={adminUser.state_code || ""} />
          )}
        </TabsContent>
        <TabsContent value="activity" className="space-y-4">
          <RecentActivity adminUser={adminUser} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

function AdminDashboardSkeleton() {
  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <Skeleton className="h-8 w-[250px]" />
        <Skeleton className="h-4 w-[350px]" />
      </div>

      <div className="space-y-4">
        <Skeleton className="h-10 w-[200px]" />

        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {Array(4)
            .fill(0)
            .map((_, i) => (
              <Card key={i}>
                <CardHeader className="pb-2">
                  <Skeleton className="h-4 w-[120px]" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-8 w-[100px]" />
                  <Skeleton className="h-4 w-full mt-2" />
                </CardContent>
              </Card>
            ))}
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          <Card>
            <CardHeader>
              <Skeleton className="h-5 w-[150px]" />
              <Skeleton className="h-4 w-[250px]" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-[200px] w-full" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <Skeleton className="h-5 w-[150px]" />
              <Skeleton className="h-4 w-[250px]" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-[200px] w-full" />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

