"use client"

import { useRouter } from "next/navigation"
import Link from "next/link"
import { getAdminUser, isSuperAdmin, logout } from "@/lib/auth"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Home, Users, Award, Settings, LogOut, Briefcase, BarChart2, Target, FileSpreadsheet } from "lucide-react"
import { cn } from "@/lib/utils"
import { usePathname } from "next/navigation"

export function AdminSidebar() {
  const router = useRouter()
  const admin = getAdminUser()
  const pathname = usePathname()
  const isAdmin = isSuperAdmin()

  const handleLogout = () => {
    logout()
    document.cookie = "adminUser=; path=/; max-age=0; SameSite=Strict"
    router.push("/admin/login")
  }

  // Define sidebar links with conditional rendering for super admin only items
  const sidebarLinks = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: <Home className="mr-2 h-4 w-4" />,
    },
    {
      title: "Users",
      href: "/admin/users",
      icon: <Users className="mr-2 h-4 w-4" />,
    },
    {
      title: "Assign XP",
      href: "/admin/xp",
      icon: <Award className="mr-2 h-4 w-4" />,
    },
    {
      title: "Bulk XP Upload",
      href: "/admin/bulk-upload",
      icon: <FileSpreadsheet className="mr-2 h-4 w-4" />,
    },
    {
      title: "Projects",
      href: "/admin/projects",
      icon: <Briefcase className="mr-2 h-4 w-4" />,
      superAdminOnly: true,
    },
    {
      title: "Project Points",
      href: "/admin/project-points",
      icon: <Target className="mr-2 h-4 w-4" />,
      superAdminOnly: true,
    },
    {
      title: "Analytics",
      href: "/admin/analytics",
      icon: <BarChart2 className="mr-2 h-4 w-4" />,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: <Settings className="mr-2 h-4 w-4" />,
      superAdminOnly: true,
    },
  ]

  return (
    <Sidebar>
      <SidebarHeader className="border-b p-4">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold">SuperteamNG Admin</h2>
          <p className="text-xs text-muted-foreground">
            {admin?.name} ({admin?.role === "SUPER_ADMIN" ? "Super Admin" : `${admin?.state} Admin`})
          </p>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {sidebarLinks
            .filter((link) => !link.superAdminOnly || isAdmin)
            .map((link) => (
              <SidebarMenuItem key={link.href}>
                <SidebarMenuButton asChild>
                  <Link
                    href={link.href}
                    className={cn(
                      "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-all",
                      pathname === link.href
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground",
                    )}
                  >
                    {link.icon}
                    <span>{link.title}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Logout</span>
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}

