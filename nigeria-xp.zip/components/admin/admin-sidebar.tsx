"use client"

import { useRouter } from "next/navigation"
import Link from "next/link"
import { getAdminUser, isSuperAdmin, logout } from "@/lib/auth"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Home, Users, Award, Upload, Settings, LogOut, Database, Briefcase, BarChart } from "lucide-react"

export function AdminSidebar() {
  const router = useRouter()
  const admin = getAdminUser()

  const handleLogout = () => {
    logout()
    document.cookie = "adminUser=; path=/; max-age=0; SameSite=Strict"
    router.push("/admin/login")
  }

  return (
    <Sidebar>
      <SidebarHeader className="border-b p-4">
        <div className="flex flex-col">
          <h2 className="text-lg font-bold">SuperteamNG Admin</h2>
          <p className="text-xs text-muted-foreground">
            {admin?.name} ({admin?.role === "SUPER_ADMIN" ? "Super Admin" : `${admin?.state} Admin`})
          </p>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin">
                <Home className="mr-2 h-4 w-4" />
                <span>Dashboard</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>

          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/users">
                <Users className="mr-2 h-4 w-4" />
                <span>Users</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>

          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/xp">
                <Award className="mr-2 h-4 w-4" />
                <span>Assign XP</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>

          {isSuperAdmin() && (
            <>
              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <Link href="/admin/projects">
                    <Briefcase className="mr-2 h-4 w-4" />
                    <span>Projects</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>

              <SidebarMenuItem>
                <SidebarMenuButton asChild>
                  <Link href="/admin/project-points">
                    <BarChart className="mr-2 h-4 w-4" />
                    <span>Project Points</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            </>
          )}

          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <Link href="/admin/upload">
                <Upload className="mr-2 h-4 w-4" />
                <span>Bulk Upload</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>

          {isSuperAdmin() && (
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link href="/admin/settings">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Settings</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          )}

          {isSuperAdmin() && (
            <SidebarMenuItem>
              <SidebarMenuButton asChild>
                <Link href="/admin/database">
                  <Database className="mr-2 h-4 w-4" />
                  <span>Database</span>
                </Link>
              </SidebarMenuButton>
            </SidebarMenuItem>
          )}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="border-t p-4">
        <Button variant="outline" className="w-full justify-start" onClick={handleLogout}>
          <LogOut className="mr-2 h-4 w-4" />
          <span>Logout</span>
        </Button>
      </SidebarFooter>
    </Sidebar>
  )
}

