"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { getAdminUser } from "@/lib/auth"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { formatDistanceToNow } from "date-fns"

interface ActivityItem {
  id: string
  type: "xp_transaction" | "project_contribution" | "user_added"
  userId: string
  adminId: string
  adminName: string
  userName: string
  amount?: number
  reason?: string
  createdAt: Date
}

export function RecentActivity() {
  const [activities, setActivities] = useState<ActivityItem[]>([])
  const [loading, setLoading] = useState(true)
  const admin = getAdminUser()

  useEffect(() => {
    async function fetchActivity() {
      try {
        setLoading(true)

        // Fetch XP transactions
        let xpQuery = supabase
          .from("xp_transactions")
          .select(`
            id,
            user_id,
            admin_id,
            amount,
            reason,
            created_at,
            users:user_id (name),
            admin_users:admin_id (name)
          `)
          .order("created_at", { ascending: false })
          .limit(10)

        // If state admin, filter by state
        if (admin?.role === "STATE_ADMIN" && admin.state) {
          // Join with users table to filter by state
          xpQuery = xpQuery.eq("users.state", admin.state)
        }

        const { data: xpData, error: xpError } = await xpQuery

        if (xpError) throw xpError

        // Transform to ActivityItem
        const xpActivities: ActivityItem[] = xpData.map((item) => ({
          id: item.id,
          type: "xp_transaction",
          userId: item.user_id,
          adminId: item.admin_id,
          adminName: item.admin_users?.name || "Unknown Admin",
          userName: item.users?.name || "Unknown User",
          amount: item.amount,
          reason: item.reason,
          createdAt: new Date(item.created_at),
        }))

        // For simplicity, we'll just use XP transactions for now
        // In a real app, you'd also fetch project contributions and user additions

        setActivities(xpActivities)
      } catch (error) {
        console.error("Error fetching activity:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchActivity()
  }, [admin])

  if (loading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest actions in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-full bg-muted animate-pulse"></div>
                <div className="space-y-2 flex-1">
                  <div className="h-4 bg-muted animate-pulse rounded w-3/4"></div>
                  <div className="h-3 bg-muted animate-pulse rounded w-1/2"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }

  if (activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest actions in the system</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-center text-muted-foreground py-8">No recent activity found</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>Latest actions in the system</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start gap-4">
              <Avatar className="h-10 w-10">
                <AvatarImage src={`/placeholder.svg?height=40&width=40`} alt={activity.adminName} />
                <AvatarFallback>{activity.adminName.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="space-y-1 flex-1">
                <p className="text-sm">
                  <span className="font-medium">{activity.adminName}</span>{" "}
                  {activity.type === "xp_transaction" && (
                    <>
                      awarded <span className="font-medium">{activity.amount} XP</span> to{" "}
                    </>
                  )}
                  <span className="font-medium">{activity.userName}</span>
                </p>
                {activity.reason && <p className="text-sm text-muted-foreground">{activity.reason}</p>}
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(activity.createdAt, { addSuffix: true })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

