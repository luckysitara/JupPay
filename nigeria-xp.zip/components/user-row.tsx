"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import type { User } from "@/types"

interface UserRowProps {
  user: User
  rank: number
}

export function UserRow({ user, rank }: UserRowProps) {
  const [isExpanded, setIsExpanded] = useState(false)

  // Update the badgeVariants with Solana-themed colors
  const badgeVariants: Record<string, string> = {
    Development: "bg-purple-500/20 text-purple-500 hover:bg-purple-500/20",
    Operations: "bg-blue-500/20 text-blue-500 hover:bg-blue-500/20",
    Strategy: "bg-green-500/20 text-green-500 hover:bg-green-500/20",
    Writing: "bg-cyan-500/20 text-cyan-500 hover:bg-cyan-500/20",
    Design: "bg-indigo-500/20 text-indigo-500 hover:bg-indigo-500/20",
  }

  return (
    <div className="border-b last:border-0 transition-colors hover:bg-muted/50">
      <div
        className="grid grid-cols-12 gap-4 p-4 items-center cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="col-span-1 flex items-center gap-2">
          {rank <= 3 ? (
            <div className="flex items-center justify-center w-6 h-6">
              {rank === 1 && "🥇"}
              {rank === 2 && "🥈"}
              {rank === 3 && "🥉"}
            </div>
          ) : (
            <div className="text-muted-foreground">{rank}</div>
          )}
        </div>
        <div className="col-span-3 flex items-center gap-2">
          <div className="flex items-center justify-center w-6 h-6 rounded-md bg-muted text-xs font-medium">
            {user.state}
          </div>
          <div className="font-medium">{user.name}</div>
        </div>
        <div className="col-span-2 text-right font-mono">
          {user.totalXp.toLocaleString()} <span className="text-xs text-muted-foreground">XP</span>
        </div>
        <div className="col-span-2 text-right font-mono text-green-500">{user.monthlyXp.toLocaleString()}</div>
        <div className="col-span-3 flex flex-wrap gap-1">
          {user.skills.slice(0, 3).map((skill) => (
            <Badge key={skill} variant="outline" className={cn("text-xs", badgeVariants[skill])}>
              {skill}
            </Badge>
          ))}
          {user.skills.length > 3 && (
            <Badge variant="outline" className="text-xs">
              +{user.skills.length - 3}
            </Badge>
          )}
        </div>
        <div className="col-span-1 flex justify-end">
          {isExpanded ? (
            <ChevronUp className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronDown className="h-4 w-4 text-muted-foreground" />
          )}
        </div>
      </div>

      {isExpanded && (
        <div className="p-4 pt-0 pl-16 pb-6 grid grid-cols-1 md:grid-cols-2 gap-4 text-sm animate-in fade-in-50 slide-in-from-top-5 duration-300">
          <div>
            <h4 className="font-medium mb-2">User Details</h4>
            <div className="space-y-1 text-muted-foreground">
              <p>Username: @{user.username}</p>
              <p>State: {user.stateName}</p>
              <p>Joined: {new Date(user.joinedAt).toLocaleDateString()}</p>
              {user.walletAddress && (
                <p>
                  Wallet: <span className="font-mono text-xs">{user.walletAddress}</span>
                </p>
              )}
            </div>
          </div>
          <div>
            <h4 className="font-medium mb-2">All Skills</h4>
            <div className="flex flex-wrap gap-1">
              {user.skills.map((skill) => (
                <Badge key={skill} variant="outline" className={cn("text-xs", badgeVariants[skill])}>
                  {skill}
                </Badge>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

