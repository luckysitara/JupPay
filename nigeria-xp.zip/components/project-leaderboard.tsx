"use client"

import { useState, useEffect } from "react"
import { useProjects } from "@/hooks/use-projects"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { AlertCircle, Trophy, Info } from "lucide-react"
import { isSupabaseConfigured } from "@/lib/database"
import type { TimeFilter } from "@/types"

export function ProjectLeaderboard() {
  const [timeFilter, setTimeFilter] = useState<TimeFilter>("all")
  const { projects, loading, error } = useProjects(timeFilter, 10)
  const [dbConfigured, setDbConfigured] = useState(true)

  useEffect(() => {
    setDbConfigured(isSupabaseConfigured())
  }, [])

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center p-8">
        <div className="h-8 w-8 animate-spin rounded-full border-b-2 border-primary"></div>
        <p className="mt-4 text-sm text-muted-foreground">Loading project leaderboard...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8">
        <AlertCircle className="h-8 w-8 text-destructive" />
        <p className="mt-4 text-sm text-destructive">Failed to load project leaderboard</p>
        <p className="text-xs text-muted-foreground">{error.message}</p>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl font-bold">Project Leaderboard</CardTitle>
          <Tabs defaultValue="all" onValueChange={(value) => setTimeFilter(value as TimeFilter)}>
            <TabsList>
              <TabsTrigger value="all">All Time</TabsTrigger>
              <TabsTrigger value="yearly">Yearly</TabsTrigger>
              <TabsTrigger value="monthly">Monthly</TabsTrigger>
              <TabsTrigger value="weekly">Weekly</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        {!dbConfigured && (
          <div className="mb-4 p-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800 rounded-md flex items-center gap-2 text-amber-800 dark:text-amber-400">
            <Info className="h-4 w-4 flex-shrink-0" />
            <p className="text-sm">Using demo data. Set up Supabase environment variables for live data.</p>
          </div>
        )}

        {projects.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8">
            <p className="text-sm text-muted-foreground">No projects found</p>
          </div>
        ) : (
          <div className="space-y-4">
            {projects.map((project, index) => (
              <div
                key={project.id}
                className="flex items-center justify-between rounded-lg border p-4 transition-colors hover:bg-muted/50"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10">
                    {index < 3 ? (
                      <Trophy
                        className={`h-4 w-4 ${index === 0 ? "text-yellow-500" : index === 1 ? "text-gray-400" : "text-amber-700"}`}
                      />
                    ) : (
                      <span className="text-sm font-medium">{index + 1}</span>
                    )}
                  </div>
                  <div>
                    <h3 className="font-medium">{project.name}</h3>
                    {project.description && (
                      <p className="text-sm text-muted-foreground line-clamp-1">{project.description}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-mono font-bold">
                    {timeFilter === "weekly"
                      ? project.weeklyPoints.toLocaleString()
                      : timeFilter === "monthly"
                        ? project.monthlyPoints.toLocaleString()
                        : timeFilter === "yearly"
                          ? project.yearlyPoints.toLocaleString()
                          : project.points.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

