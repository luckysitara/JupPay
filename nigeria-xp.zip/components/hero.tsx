"use client"

import { Button } from "@/components/ui/button"
import { Sparkles } from "lucide-react"
import { BlockchainAnimation } from "@/components/blockchain-animation"

export function Hero() {
  return (
    <div className="py-12 md:py-24 lg:py-32 space-y-8 text-center relative">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <BlockchainAnimation />
      </div>
      <div className="inline-block mb-4 relative z-10">
        <div className="flex items-center justify-center p-2 bg-primary/10 rounded-full">
          <Sparkles className="h-5 w-5 mr-2 text-primary" />
          <span className="text-sm font-medium">Powered by Solana</span>
        </div>
      </div>
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold relative z-10">
        Welcome to SuperteamNG Reputation System
      </h1>
      <p className="text-muted-foreground max-w-[700px] mx-auto relative z-10">
        Our reputation system empowers the Nigerian Solana ecosystem by recognizing and rewarding valuable
        contributions. By tracking member achievements through XP, we create transparency and help project leads
        identify proven talent with verifiable on-chain credentials.
      </p>
      <Button
        size="lg"
        className="bg-gradient-to-r from-purple-500 to-blue-600 hover:from-purple-600 hover:to-blue-700 relative z-10"
        onClick={() =>
          window.open("https://docs.superteam.fun/the-superteam-handbook/community/the-reputation-system", "_blank")
        }
      >
        Learn More
      </Button>
    </div>
  )
}

