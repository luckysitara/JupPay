"use client"

import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <div className="py-12 md:py-24 lg:py-32 space-y-8 text-center">
      <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold">Welcome to the Nigerian XP Reputation System</h1>
      <p className="text-muted-foreground max-w-[700px] mx-auto">
        In our community, being able to know who to trust and who has proven shipping abilities is essential. Our
        reputation system captures member contributions and gives them XP so that project leads know which members are
        reliable.
      </p>
      <Button
        size="lg"
        className="animate-pulse"
        onClick={() =>
          window.open("https://docs.superteam.fun/the-superteam-handbook/community/the-reputation-system", "_blank")
        }
      >
        Learn More
      </Button>
    </div>
  )
}

