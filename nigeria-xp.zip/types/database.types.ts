export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[]

export interface Database {
  public: {
    Tables: {
      admin_users: {
        Row: {
          id: string
          email: string
          name: string
          role: "SUPER_ADMIN" | "STATE_ADMIN"
          state: string | null
          secret_key: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          email: string
          name: string
          role: "SUPER_ADMIN" | "STATE_ADMIN"
          state?: string | null
          secret_key?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          role?: "SUPER_ADMIN" | "STATE_ADMIN"
          state?: string | null
          secret_key?: string
          created_at?: string
          updated_at?: string
        }
      }
      projects: {
        Row: {
          id: string
          name: string
          description: string | null
          points: number
          weekly_points: number
          monthly_points: number
          yearly_points: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          description?: string | null
          points?: number
          weekly_points?: number
          monthly_points?: number
          yearly_points?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          description?: string | null
          points?: number
          weekly_points?: number
          monthly_points?: number
          yearly_points?: number
          created_at?: string
          updated_at?: string
        }
      }
      project_contributions: {
        Row: {
          id: string
          project_id: string
          user_id: string
          admin_id: string
          points: number
          reason: string
          created_at: string
        }
        Insert: {
          id?: string
          project_id: string
          user_id: string
          admin_id: string
          points: number
          reason: string
          created_at?: string
        }
        Update: {
          id?: string
          project_id?: string
          user_id?: string
          admin_id?: string
          points?: number
          reason?: string
          created_at?: string
        }
      }
      states: {
        Row: {
          code: string
          name: string
          created_at: string
        }
        Insert: {
          code: string
          name: string
          created_at?: string
        }
        Update: {
          code?: string
          name?: string
          created_at?: string
        }
      }
      users: {
        Row: {
          id: string
          name: string
          username: string
          state: string
          total_xp: number
          monthly_xp: number
          skills: string[]
          joined_at: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          name: string
          username: string
          state: string
          total_xp?: number
          monthly_xp?: number
          skills?: string[]
          joined_at?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          name?: string
          username?: string
          state?: string
          total_xp?: number
          monthly_xp?: number
          skills?: string[]
          joined_at?: string
          created_at?: string
          updated_at?: string
        }
      }
      xp_transactions: {
        Row: {
          id: string
          user_id: string
          admin_id: string
          amount: number
          reason: string
          skills: string[]
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          admin_id: string
          amount: number
          reason: string
          skills?: string[]
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          admin_id?: string
          amount?: number
          reason?: string
          skills?: string[]
          created_at?: string
        }
      }
    }
    Views: {
      users_with_state: {
        Row: {
          id: string
          name: string
          username: string
          state: string
          state_name: string
          total_xp: number
          monthly_xp: number
          skills: string[]
          joined_at: string
          created_at: string
          updated_at: string
        }
      }
    }
    Functions: {
      update_user_xp: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      reset_monthly_xp: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      update_timestamp: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      update_project_points: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
      reset_project_time_points: {
        Args: Record<PropertyKey, never>
        Returns: unknown
      }
    }
  }
}

