import express from "express"
import { BridgeController } from "../controllers/bridge.controller"
import { authenticate } from "../middleware/auth.middleware"

export class BridgeRoute {
  router: express.Router
  private bridgeController: BridgeController

  constructor() {
    this.router = express.Router()
    this.bridgeController = new BridgeController()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    // Add a debug endpoint to test Bridge API directly
    this.router.get("/test-connection", this.bridgeController.testConnection.bind(this.bridgeController))

    // TOS and customer creation
    this.router.post("/tos", this.bridgeController.generateTosLink.bind(this.bridgeController))

    // KYC Links API
    this.router.post("/kyc-links", this.bridgeController.createKycLink.bind(this.bridgeController))
    this.router.get("/kyc-links/:kycLinkId", this.bridgeController.getKycLinkStatus.bind(this.bridgeController))
    this.router.get(
      "/customers/:customerId/kyc-link",
      authenticate,
      this.bridgeController.getKycLinkForExistingCustomer.bind(this.bridgeController),
    )
    this.router.get(
      "/customers/:customerId/tos-acceptance-link",
      authenticate,
      this.bridgeController.getTosAcceptanceLinkForExistingCustomer.bind(this.bridgeController),
    )

    // Customer API
    this.router.post(
      "/customers/individual",
      authenticate,
      this.bridgeController.createIndividualCustomer.bind(this.bridgeController),
    )
    this.router.post(
      "/customers/business",
      authenticate,
      this.bridgeController.createBusinessCustomer.bind(this.bridgeController),
    )
    this.router.get(
      "/customers/:customerId",
      authenticate,
      this.bridgeController.getCustomer.bind(this.bridgeController),
    )
    this.router.put(
      "/customers/:customerId",
      authenticate,
      this.bridgeController.updateCustomer.bind(this.bridgeController),
    )

    // External accounts
    this.router.post(
      "/customers/:customerId/external-accounts",
      authenticate,
      this.bridgeController.addExternalAccount.bind(this.bridgeController),
    )
    this.router.get(
      "/customers/:customerId/external-accounts",
      authenticate,
      this.bridgeController.getExternalAccounts.bind(this.bridgeController),
    )

    // Plaid integration
    this.router.post(
      "/customers/:customerId/plaid-link",
      authenticate,
      this.bridgeController.createPlaidLinkRequest.bind(this.bridgeController),
    )
    this.router.post(
      "/plaid-exchange/:linkToken",
      authenticate,
      this.bridgeController.exchangePlaidPublicToken.bind(this.bridgeController),
    )

    // Virtual accounts
    this.router.post(
      "/customers/:customerId/virtual-accounts",
      authenticate,
      this.bridgeController.createVirtualAccount.bind(this.bridgeController),
    )
    this.router.get(
      "/customers/:customerId/virtual-accounts",
      authenticate,
      this.bridgeController.getVirtualAccounts.bind(this.bridgeController),
    )

    // Transfers
    this.router.post("/transfers", authenticate, this.bridgeController.createTransfer.bind(this.bridgeController))
    this.router.post(
      "/customers/:customerId/transfers",
      authenticate,
      this.bridgeController.createCustomerTransfer.bind(this.bridgeController),
    )
  }
}

