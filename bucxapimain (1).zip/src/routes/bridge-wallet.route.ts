import express from "express"
import { BridgeWalletController } from "../controllers/bridge-wallet.controller"
import { authenticate } from "../middleware/auth.middleware"

export class BridgeWalletRoute {
  router: express.Router
  private bridgeWalletController: BridgeWalletController

  constructor() {
    this.router = express.Router()
    this.bridgeWalletController = new BridgeWalletController()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    // Create wallet
    this.router.post("/", authenticate, this.bridgeWalletController.createWallet.bind(this.bridgeWalletController))

    // Get wallet balance
    this.router.get(
      "/balance",
      authenticate,
      this.bridgeWalletController.getWalletBalance.bind(this.bridgeWalletController),
    )

    // Create virtual account to wallet
    this.router.post(
      "/virtual-account",
      authenticate,
      this.bridgeWalletController.createVirtualAccountToWallet.bind(this.bridgeWalletController),
    )

    // Create transfer from wallet
    this.router.post(
      "/transfer-from",
      authenticate,
      this.bridgeWalletController.createTransferFromWallet.bind(this.bridgeWalletController),
    )

    // Create transfer to wallet
    this.router.post(
      "/transfer-to",
      authenticate,
      this.bridgeWalletController.createTransferToWallet.bind(this.bridgeWalletController),
    )

    // Create wallet to wallet transfer
    this.router.post(
      "/transfer-wallet-to-wallet",
      authenticate,
      this.bridgeWalletController.createWalletToWalletTransfer.bind(this.bridgeWalletController),
    )

    // Get user wallets
    this.router.get(
      "/user-wallets",
      authenticate,
      this.bridgeWalletController.getUserWallets.bind(this.bridgeWalletController),
    )

    // Admin routes
    this.router.get("/all", authenticate, this.bridgeWalletController.getAllWallets.bind(this.bridgeWalletController))

    this.router.get(
      "/total-balance",
      authenticate,
      this.bridgeWalletController.getTotalWalletsBalance.bind(this.bridgeWalletController),
    )
  }
}

