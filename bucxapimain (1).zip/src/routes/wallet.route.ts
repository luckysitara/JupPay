import express from "express"
import { WalletController } from "../controllers/wallet.controller"
import { authenticate } from "../middleware/auth.middleware"

export class WalletRoute {
  router: express.Router
  private walletController: WalletController

  constructor() {
    this.router = express.Router()
    this.walletController = new WalletController()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    // Get wallet information
    this.router.get("/", authenticate, this.walletController.getWallet.bind(this.walletController))

    // Create wallet
    this.router.post("/", authenticate, this.walletController.createWallet.bind(this.walletController))

    // Create USD wallet
    this.router.post("/usd", authenticate, this.walletController.createUsdWallet.bind(this.walletController))

    // Get deposit instructions
    this.router.get(
      "/deposit-instructions",
      authenticate,
      this.walletController.getDepositInstructions.bind(this.walletController),
    )

    // Initiate transfer
    this.router.post("/transfer", authenticate, this.walletController.initiateTransfer.bind(this.walletController))

    // Update wallet with virtual account
    this.router.put(
      "/update-virtual-account",
      authenticate,
      this.walletController.updateVirtualAccount.bind(this.walletController),
    )
  }
}

