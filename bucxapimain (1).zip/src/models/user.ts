import mongoose, { type Document, Schema } from "mongoose"

export interface IUser extends Document {
  email: string
  firstname: string
  lastname: string
  password: string
  country?: string
  accountType?: string
  phone?: string
  googleId?: string
  resetPasswordToken?: string
  resetPasswordExpires?: Date
  emailIsVerified: boolean
  bridgeCustomerId?: string
  bridgeKycStatus?: string
  bridgeTosStatus?: string
  bridgeKycLinkId?: string
  bridgeEndorsements?: string[]
  bridgeSignedAgreementId?: string
  bridgeVirtualAccountId?: string
  bridgeWalletId?: string // Added for Bridge wallet
}

const userSchema = new Schema<IUser>(
  {
    email: { type: String, required: true, unique: true },
    firstname: { type: String, default: "" },
    lastname: { type: String, default: "" },
    password: { type: String },
    country: { type: String },
    accountType: { type: String },
    phone: { type: String },
    googleId: { type: String },
    emailIsVerified: { type: Boolean, default: false },
    resetPasswordToken: { type: String },
    resetPasswordExpires: { type: Date },
    bridgeCustomerId: { type: String },
    bridgeKycStatus: { type: String, enum: ["not_started", "incomplete", "under_review", "approved", "rejected"] },
    bridgeTosStatus: { type: String, enum: ["pending", "approved"] },
    bridgeKycLinkId: { type: String },
    bridgeEndorsements: [{ type: String }],
    bridgeSignedAgreementId: { type: String },
    bridgeVirtualAccountId: { type: String },
    bridgeWalletId: { type: String }, // Added for Bridge wallet
  },
  { timestamps: true },
)

export const User = mongoose.model<IUser>("User", userSchema)

