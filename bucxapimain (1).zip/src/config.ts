/**
 * Application Configuration
 *
 * This file centralizes all configuration variables used throughout the application.
 */

// Log the environment variables related to Bridge API at module load time
console.log("Loading config.ts...")
console.log(
  `BRIDGE_API_KEY from env: ${process.env.BRIDGE_API_KEY ? `${process.env.BRIDGE_API_KEY.substring(0, 8)}...` : "Not set"}`,
)
console.log(`BRIDGE_BASE_URL from env: ${process.env.BRIDGE_BASE_URL || "Not set"}`)

export const config = {
  // Server configuration
  port: process.env.PORT ? Number(process.env.PORT) : 5002,
  host: process.env.HOST || "localhost",
  nodeEnv: process.env.NODE_ENV || "development",

  // MongoDB configuration
  mongodbUri: process.env.MONGODB_URI || process.env.MONGODB_URL || "mongodb://localhost:27017/bux",

  // JWT configuration
  jwtSecret: process.env.JWT_SECRET || "your-jwt-secret-key-should-be-long-and-random",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "24h",

  // Email configuration
  emailFrom: process.env.EMAIL_FROM || process.env.EMAIL_USER || "",
  emailUser: process.env.EMAIL_USER || "",
  emailPass: process.env.EMAIL_PASS || "",
  emailService: process.env.EMAIL_SERVICE || "gmail",
  emailHost: process.env.EMAIL_HOST || "",
  emailPort: process.env.EMAIL_PORT ? Number(process.env.EMAIL_PORT) : 587,
  emailSecure: process.env.EMAIL_SECURE === "true",

  // Google OAuth configuration
  googleClientId: process.env.GOOGLE_CLIENT_ID || "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
  googleCallbackUrl: process.env.GOOGLE_CALLBACK_URL || "",

  // Bridge API configuration
  bridgeApiKey: process.env.BRIDGE_API_KEY || "",
  // Automatically detect if using sandbox based on API key prefix
  // FIXED: Changed "sk-test_" to "sk-test-" (hyphen instead of underscore)
  bridgeBaseUrl: process.env.BRIDGE_API_KEY?.startsWith("sk-test-")
    ? process.env.BRIDGE_BASE_URL || "https://api.sandbox.bridge.xyz/v0"
    : process.env.BRIDGE_BASE_URL || "https://api.bridge.xyz/v0",
  bridgeEnvironment: process.env.BRIDGE_API_KEY?.startsWith("sk-test-") ? "sandbox" : "production",

  // CORS configuration
  corsOrigins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(",") : ["http://localhost:3000"],

  // Logging configuration
  logLevel: process.env.LOG_LEVEL || "info",

  // OTP configuration
  otpExpiryMinutes: 10,

  // Validation
  passwordMinLength: 8,

  // Debug mode
  debug: process.env.DEBUG === "true",
}

// Log the final configuration for Bridge API
console.log("Bridge API Configuration:")
console.log(`Bridge API Key: ${config.bridgeApiKey ? config.bridgeApiKey.substring(0, 8) + "..." : "Not set"}`)
console.log(`Bridge Base URL: ${config.bridgeBaseUrl}`)
console.log(`Bridge Environment: ${config.bridgeEnvironment}`)

