import type { Request, Response } from "express"
import { BridgeWalletService } from "../wallet/bridge.wallet.service"
import { User } from "../models/user"
import logger from "../utils/logger"

export class BridgeWalletController {
  /**
   * Create a wallet for the authenticated user
   */
  async createWallet(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Check if user already has a wallet
      if (user.bridgeWalletId) {
        return res.status(400).json({ message: "User already has a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID. Please onboard the user first.",
        })
      }

      const wallet = await BridgeWalletService.createWallet(user.bridgeCustomerId)

      // Update user with wallet ID
      await User.findByIdAndUpdate(user._id, { bridgeWalletId: wallet.id })

      return res.status(201).json({
        message: "Wallet created successfully",
        walletId: wallet.id,
        address: wallet.address,
        chain: wallet.chain,
      })
    } catch (error: any) {
      logger.error(`Create wallet error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create wallet" })
    }
  }

  /**
   * Get wallet balance for the authenticated user
   */
  async getWalletBalance(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Check if user has a wallet
      if (!user.bridgeWalletId) {
        return res.status(404).json({ message: "User does not have a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const wallet = await BridgeWalletService.getWalletBalance(user.bridgeCustomerId, user.bridgeWalletId)

      return res.status(200).json(wallet)
    } catch (error: any) {
      logger.error(`Get wallet balance error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get wallet balance" })
    }
  }

  /**
   * Create a virtual account to wallet transfer
   */
  async createVirtualAccountToWallet(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { sourceCurrency, destinationCurrency } = req.body

      // Check if user has a wallet
      if (!user.bridgeWalletId) {
        return res.status(404).json({ message: "User does not have a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const virtualAccount = await BridgeWalletService.createVirtualAccountToWallet(
        user.bridgeCustomerId,
        user.bridgeWalletId,
        sourceCurrency || "usd",
        destinationCurrency || "usdb",
      )

      // Update user with virtual account ID
      await User.findByIdAndUpdate(user._id, { bridgeVirtualAccountId: virtualAccount.id })

      return res.status(201).json({
        message: "Virtual account created successfully",
        virtualAccount,
      })
    } catch (error: any) {
      logger.error(`Create virtual account error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create virtual account" })
    }
  }

  /**
   * Create a transfer from wallet
   */
  async createTransferFromWallet(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { amount, destinationAddress, sourceCurrency, destinationCurrency, destinationPaymentRail, developerFee } =
        req.body

      if (!amount || !destinationAddress) {
        return res.status(400).json({ message: "Amount and destination address are required" })
      }

      // Check if user has a wallet
      if (!user.bridgeWalletId) {
        return res.status(404).json({ message: "User does not have a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const transfer = await BridgeWalletService.createTransferFromWallet(
        user.bridgeCustomerId,
        user.bridgeWalletId,
        amount,
        destinationAddress,
        sourceCurrency || "usdb",
        destinationCurrency || "usdc",
        destinationPaymentRail || "ethereum",
        developerFee || "0.0",
      )

      return res.status(201).json({
        message: "Transfer created successfully",
        transfer,
      })
    } catch (error: any) {
      logger.error(`Create transfer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create transfer" })
    }
  }

  /**
   * Create a transfer to wallet
   */
  async createTransferToWallet(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { amount, sourceCurrency, sourcePaymentRail, destinationCurrency, developerFee } = req.body

      if (!amount) {
        return res.status(400).json({ message: "Amount is required" })
      }

      // Check if user has a wallet
      if (!user.bridgeWalletId) {
        return res.status(404).json({ message: "User does not have a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const transfer = await BridgeWalletService.createTransferToWallet(
        user.bridgeCustomerId,
        user.bridgeWalletId,
        amount,
        sourceCurrency || "usd",
        sourcePaymentRail || "wire",
        destinationCurrency || "usdb",
        developerFee || "0.0",
      )

      return res.status(201).json({
        message: "Transfer created successfully",
        transfer,
      })
    } catch (error: any) {
      logger.error(`Create transfer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create transfer" })
    }
  }

  /**
   * Create a wallet to wallet transfer
   */
  async createWalletToWalletTransfer(req: Request, res: Response) {
    try {
      const user = req.user as any
      const { destinationWalletId, amount, currency, developerFee } = req.body

      if (!amount || !destinationWalletId) {
        return res.status(400).json({ message: "Amount and destination wallet ID are required" })
      }

      // Check if user has a wallet
      if (!user.bridgeWalletId) {
        return res.status(404).json({ message: "User does not have a wallet" })
      }

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const transfer = await BridgeWalletService.createWalletToWalletTransfer(
        user.bridgeCustomerId,
        user.bridgeWalletId,
        destinationWalletId,
        amount,
        currency || "usdb",
        developerFee || "0.0",
      )

      return res.status(201).json({
        message: "Transfer created successfully",
        transfer,
      })
    } catch (error: any) {
      logger.error(`Create wallet to wallet transfer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create wallet to wallet transfer" })
    }
  }

  /**
   * Get all wallets for the authenticated user
   */
  async getUserWallets(req: Request, res: Response) {
    try {
      const user = req.user as any

      // Check if user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        return res.status(400).json({
          message: "User does not have a Bridge customer ID",
        })
      }

      const wallets = await BridgeWalletService.getCustomerWallets(user.bridgeCustomerId)

      return res.status(200).json(wallets)
    } catch (error: any) {
      logger.error(`Get user wallets error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get user wallets" })
    }
  }

  /**
   * Get all wallets (admin only)
   */
  async getAllWallets(req: Request, res: Response) {
    try {
      const wallets = await BridgeWalletService.getAllWallets()

      return res.status(200).json(wallets)
    } catch (error: any) {
      logger.error(`Get all wallets error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get all wallets" })
    }
  }

  /**
   * Get total balance of all wallets (admin only)
   */
  async getTotalWalletsBalance(req: Request, res: Response) {
    try {
      const balances = await BridgeWalletService.getTotalWalletsBalance()

      return res.status(200).json(balances)
    } catch (error: any) {
      logger.error(`Get total wallets balance error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get total wallets balance" })
    }
  }
}

