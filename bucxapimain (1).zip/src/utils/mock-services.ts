import { v4 as uuidv4 } from "uuid"
import logger from "./logger"

export const useMocks = process.env.USE_MOCKS === "true"

export const mockBridgeRequest = async (url: string, method: string, data?: any) => {
  logger.info(`MOCK Bridge API Request: ${method} ${url}`)
  logger.debug(`MOCK Request data: ${JSON.stringify(data || {})}`)

  // Add a small delay to simulate network latency
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Simulate a response based on the URL
  if (url.includes("/customers/tos_links")) {
    const response = {
      url: `https://dashboard.bridge.xyz/accept-terms-of-service?session_token=${uuidv4()}`,
      signed_agreement_id: `signed_agreement_${uuidv4()}`,
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (
    url.includes("/customers") &&
    !url.includes("/external_accounts") &&
    !url.includes("/virtual_accounts") &&
    method === "POST"
  ) {
    // Enhanced mock for business customer creation
    if (data && data.type === "business") {
      // Log the received data for debugging
      logger.info(`MOCK: Received business customer data: ${JSON.stringify(data)}`)

      // Check for required fields
      const requiredFields = [
        "business_legal_name",
        "registered_address",
        "business_type",
        "business_industry",
        "email",
        "signed_agreement_id",
      ]

      const missingFields = requiredFields.filter((field) => !data[field])
      if (missingFields.length > 0) {
        logger.error(`MOCK: Missing required fields: ${missingFields.join(", ")}`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: missingFields.map((field) => ({ field, message: "This field is required" })),
        }
      }

      // Check for required address fields
      const requiredAddressFields = ["street_line_1", "city", "subdivision", "postal_code", "country"]
      const missingAddressFields = requiredAddressFields.filter((field) => !data.registered_address[field])
      if (missingAddressFields.length > 0) {
        logger.error(`MOCK: Missing required address fields: ${missingAddressFields.join(", ")}`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: missingAddressFields.map((field) => ({
            field: `registered_address.${field}`,
            message: "This field is required",
          })),
        }
      }

      // Check for required business fields based on Bridge API documentation
      const additionalRequiredFields = [
        "has_material_intermediary_ownership",
        "account_purpose",
        "source_of_funds",
        "operates_in_prohibited_countries",
        "conducts_money_services",
        "conducts_money_services_using_bridge",
      ]

      const missingAdditionalFields = additionalRequiredFields.filter((field) => data[field] === undefined)
      if (missingAdditionalFields.length > 0) {
        logger.warn(`MOCK: Missing additional fields that might be required: ${missingAdditionalFields.join(", ")}`)
        // We'll continue anyway since we've added defaults in the controller
      }

      // Check for identifying_information
      if (
        !data.identifying_information ||
        !Array.isArray(data.identifying_information) ||
        data.identifying_information.length === 0
      ) {
        logger.error(`MOCK: Missing identifying_information array`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: [{ field: "identifying_information", message: "This field is required" }],
        }
      }

      // Check for ultimate_beneficial_owners
      if (
        !data.ultimate_beneficial_owners ||
        !Array.isArray(data.ultimate_beneficial_owners) ||
        data.ultimate_beneficial_owners.length === 0
      ) {
        logger.error(`MOCK: Missing ultimate_beneficial_owners array`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: [{ field: "ultimate_beneficial_owners", message: "This field is required" }],
        }
      }

      const response = {
        id: `customer_${uuidv4()}`,
        type: "business",
        status: "not_started",
        business_legal_name: data.business_legal_name || "Mock Business",
        email: data.email || "business@example.com",
        business_type: data.business_type || "corporation",
        business_industry: data.business_industry || "1153",
        registered_address: data.registered_address || {
          street_line_1: "123 Mock St",
          city: "Mock City",
          subdivision: "Mock State",
          postal_code: "12345",
          country: "US",
        },
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }
      logger.debug(`MOCK Business Customer Response: ${JSON.stringify(response)}`)
      return response
    }

    // Individual customer validation
    if (data && data.type === "individual") {
      // Log the received data for debugging
      logger.info(`MOCK: Received individual customer data: ${JSON.stringify(data)}`)

      // Check for required fields
      const requiredFields = [
        "first_name",
        "last_name",
        "email",
        "phone",
        "address",
        "signed_agreement_id",
        "birth_date",
      ]

      const missingFields = requiredFields.filter((field) => !data[field])
      if (missingFields.length > 0) {
        logger.error(`MOCK: Missing required fields: ${missingFields.join(", ")}`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: missingFields.map((field) => ({ field, message: "This field is required" })),
        }
      }

      // Check for required address fields
      const requiredAddressFields = ["street_line_1", "city", "state", "postal_code", "country"]
      const missingAddressFields = requiredAddressFields.filter((field) => !data.address[field])
      if (missingAddressFields.length > 0) {
        logger.error(`MOCK: Missing required address fields: ${missingAddressFields.join(", ")}`)
        return {
          error: true,
          message: "Please resubmit the following parameters that are either missing or invalid",
          errors: missingAddressFields.map((field) => ({
            field: `address.${field}`,
            message: "This field is required",
          })),
        }
      }
    }

    // Default individual customer response
    const response = {
      id: `customer_${uuidv4()}`,
      type: data?.type || "individual",
      status: "not_started",
      first_name: data?.first_name || "John",
      last_name: data?.last_name || "Doe",
      email: data?.email || "john.doe@example.com",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/external_accounts") && method === "POST") {
    const response = {
      id: `external_account_${uuidv4()}`,
      customer_id: url.split("/customers/")[1].split("/")[0],
      bank_name: data?.bank_name || "Mock Bank",
      account_owner_name: data?.account_owner_name || "John Doe",
      account_name: data?.account_name || "Checking",
      last_4: data?.account_number ? data.account_number.slice(-4) : "1234",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/external_accounts") && method === "GET") {
    const response = {
      data: [
        {
          id: `external_account_${uuidv4()}`,
          customer_id: url.split("/customers/")[1].split("/")[0],
          bank_name: "Mock Bank",
          account_owner_name: "John Doe",
          account_name: "Checking",
          last_4: "1234",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ],
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/plaid_link_requests")) {
    const response = {
      link_token: `link_token_${uuidv4()}`,
      link_token_expires_at: new Date(Date.now() + 3600000).toISOString(),
      callback_url: `https://api.bridge.xyz/v0/plaid_exchange_public_token/${uuidv4()}`,
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/plaid_exchange_public_token")) {
    const response = {
      message: "Successfully Exchanged the Public Token.",
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/virtual_accounts") && method === "POST") {
    const response = {
      id: `virtual_account_${uuidv4()}`,
      status: "active",
      customer_id: url.split("/customers/")[1].split("/")[0],
      source_deposit_instructions: {
        currency: data?.source?.currency || "usd",
        bank_beneficiary_name: "Bridge Financial Technologies Inc.",
        bank_name: "Mock Bank",
        bank_address: "123 Mock St, San Francisco, CA 94105",
        bank_routing_number: "123456789",
        bank_account_number: "987654321",
        payment_rails: ["ach", "wire"],
        payment_rail: "ach",
      },
      destination: {
        currency: data?.destination?.currency || "usdc",
        payment_rail: data?.destination?.payment_rail || "solana",
        address: data?.destination?.address || "solana_address_mock",
      },
      developer_fee_percent: data?.developer_fee_percent || "1.0",
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/virtual_accounts") && method === "GET") {
    const response = {
      data: [
        {
          id: `virtual_account_${uuidv4()}`,
          status: "active",
          customer_id: url.split("/customers/")[1].split("/")[0],
          source_deposit_instructions: {
            currency: "usd",
            bank_beneficiary_name: "Bridge Financial Technologies Inc.",
            bank_name: "Mock Bank",
            bank_address: "123 Mock St, San Francisco, CA 94105",
            bank_routing_number: "123456789",
            bank_account_number: "987654321",
            payment_rails: ["ach", "wire"],
            payment_rail: "ach",
          },
          destination: {
            currency: "usdc",
            payment_rail: "solana",
            address: "solana_address_mock",
          },
          developer_fee_percent: "1.0",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ],
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else if (url.includes("/transfers")) {
    const response = {
      id: `transfer_${uuidv4()}`,
      status: "pending",
      amount: data?.amount || "100.00",
      on_behalf_of: data?.on_behalf_of || "customer_mock",
      source: data?.source || {
        payment_rail: "ach",
        currency: "usd",
      },
      destination: data?.destination || {
        payment_rail: "solana",
        currency: "usdc",
        to_address: "solana_address_mock",
      },
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  } else {
    const response = {
      message: "Mock response",
      path: url,
      method: method,
    }
    logger.debug(`MOCK Response: ${JSON.stringify(response)}`)
    return response
  }
}

export const mockEncrypt = async (value: string) => {
  logger.info(`MOCK Encrypting value`)
  return `encrypted_${value}`
}

export const mockDecrypt = async (value: string) => {
  logger.info(`MOCK Decrypting value`)
  return value.replace("encrypted_", "")
}

