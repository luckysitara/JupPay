import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { User } from "../models/user"
import { config } from "../config"
import { EmailService } from "./email.service"
import { OTPTYPE } from "../constant"
import { OtpService } from "../otp/service"

export class AuthService {
  static generateToken = (userId: string) => {
    return jwt.sign({ userId }, config.jwtSecret, { expiresIn: config.jwtExpiresIn })
  }

  static signupUser = async (data: { email: string; password: string; firstname: string; lastname: string }) => {
    const { email, password, firstname, lastname } = data

    try {
      const existingUser = await User.findOne({ email })

      if (existingUser) {
        throw new Error("User already exists")
      }

      const hashedPassword = await bcrypt.hash(password, 12)
      const newUser = new User({
        email,
        password: hashedPassword,
        lastname,
        firstname,
        emailIsVerified: false,
      })

      await newUser.save()

      // Send verification email
      await EmailService.sendVerificationEmail(email)

      const token = this.generateToken(newUser._id)

      return { message: "User created successfully. Please verify your email.", token }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  static authenticateUser = async (data: { email: string; password: string }) => {
    const { email, password } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        throw new Error("Invalid credentials")
      }

      const isMatch = await bcrypt.compare(password, user.password)
      if (!isMatch) {
        throw new Error("Invalid credentials")
      }

      // Check if email is verified
      if (!user.emailIsVerified) {
        throw new Error("Email not verified. Please verify your email before logging in.")
      }

      const token = this.generateToken(user._id.toString())
      return { message: "Login successful", token, user: { id: user._id, email: user.email } }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  static forgotPassword = async (data: { email: string }) => {
    const { email } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        // For security reasons, still return success message even if user doesn't exist
        return { message: "If your email is registered, you will receive a password reset OTP." }
      }

      await EmailService.sendForgotPasswordEmail(email)
      return { message: "Password reset OTP sent to your email" }
    } catch (err: any) {
      console.error(err)
      throw new Error("Server error")
    }
  }

  static resetPassword = async (data: { otp: number; email: string; newPassword: string }) => {
    const { email, otp, newPassword } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        throw new Error("Invalid email.")
      }

      const isValid = await OtpService.verifyOtp({ otp, email, type: OTPTYPE.forgotPassword })
      if (!isValid) {
        throw new Error("Invalid or expired OTP.")
      }

      const hashedPassword = await bcrypt.hash(newPassword, 12)
      user.password = hashedPassword
      await user.save()

      return { message: "Password successfully reset" }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  static async verifyEmail(data: { otp: number; user: any }) {
    const { otp, user } = data

    try {
      const isValid = await OtpService.verifyOtp({
        otp,
        email: user.email,
        type: OTPTYPE.emailVerification,
      })

      if (!isValid) {
        throw new Error("Invalid or expired OTP.")
      }

      user.emailIsVerified = true
      await user.save()

      return { message: "Email verified successfully" }
    } catch (error: any) {
      console.error("Email verification error:", error)
      throw new Error(error.message || "Failed to verify email")
    }
  }

  static async resendOtp(data: { email: string; type: OTPTYPE }) {
    const { email, type } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        // For security reasons, still return success message even if user doesn't exist
        return { message: "If your email is registered, you will receive an OTP." }
      }

      if (type === OTPTYPE.emailVerification) {
        await EmailService.sendVerificationEmail(email)
      } else if (type === OTPTYPE.forgotPassword) {
        await EmailService.sendForgotPasswordEmail(email)
      }

      return { message: "OTP sent successfully" }
    } catch (error: any) {
      console.error("Resend OTP error:", error)
      throw new Error(error.message || "Failed to resend OTP")
    }
  }
}

