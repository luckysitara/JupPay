export interface VaultEncryptInput {
  value: string
}

