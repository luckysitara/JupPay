// Add a check for email configuration at startup
// Add more detailed logging at startup
// Load environment variables first
import dotenv from "dotenv"
dotenv.config()

// Log important configuration values at startup
console.log("=== BUX API Configuration ===")
console.log(`Environment: ${process.env.NODE_ENV}`)
console.log(`MongoDB URI: ${process.env.MONGODB_URI || process.env.MONGODB_URL}`)
console.log(
  `Bridge API Key: ${process.env.BRIDGE_API_KEY ? `${process.env.BRIDGE_API_KEY.substring(0, 8)}...${process.env.BRIDGE_API_KEY.substring(process.env.BRIDGE_API_KEY.length - 4)}` : "Not set"}`,
)
console.log(`Bridge Base URL: ${process.env.BRIDGE_BASE_URL || "Not set"}`)
console.log(`Email Configuration: ${process.env.EMAIL_USER ? "Configured" : "Not configured"}`)
if (!process.env.EMAIL_USER || !process.env.EMAIL_PASS) {
  console.warn("⚠️ WARNING: Email credentials are not configured. Email sending will fail!")
  console.warn("Please set EMAIL_USER and EMAIL_PASS environment variables.")
}
console.log("============================")

// Then import other dependencies
import express, { type Application, type Request, type Response, type NextFunction } from "express"
import { Authroute } from "./auth/route"
import cors from "cors"
import helmet from "helmet"
import rateLimit from "express-rate-limit"
import mongoose from "mongoose"
import { config } from "./config"

// Import the BridgeRoute
import { BridgeRoute } from "./routes/bridge.route"
// Import the BridgeWalletRoute
import { BridgeWalletRoute } from "./routes/bridge-wallet.route"
// Import the DebugRoute
import { DebugRoute } from "./routes/debug.route"

/**
 * Initialize Express application
 */
const app: Application = express()
const PORT = config.port

/**
 * Connect to MongoDB
 */
mongoose
  .connect(process.env.MONGODB_URI || "mongodb://localhost:27017/bux")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => {
    console.error("MongoDB Connection Error:", err)
    process.exit(1)
  })

/**
 * Apply security middleware
 */
app.use(helmet())
app.use(
  cors({
    origin: config.corsOrigins,
    methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  }),
)

/**
 * Apply rate limiting to prevent abuse
 */
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    status: "error",
    message: "Too many requests, please try again later.",
  },
})
app.use(limiter)

/**
 * Request parsing middleware
 */
app.use(express.json())
app.use(express.urlencoded({ extended: true }))

/**
 * API Routes
 */
app.use("/api/auth", new Authroute().router)
app.use("/api/bridge", new BridgeRoute().router)
app.use("/api/wallet", new BridgeWalletRoute().router)

// Add debug routes in development mode
if (config.nodeEnv === "development" || config.debug) {
  app.use("/api/debug", new DebugRoute().router)
  console.log("✅ Debug routes enabled")
}

/**
 * Default route
 */
app.get("/", (req: Request, res: Response) => {
  res.json({
    status: "online",
    message: "BUX API is running",
    version: "1.0.0",
    environment: config.nodeEnv,
    timestamp: new Date().toISOString(),
  })
})

/**
 * 404 handler
 */
app.use((req: Request, res: Response) => {
  res.status(404).json({
    status: "error",
    message: "Route not found",
  })
})

/**
 * Global error handling middleware
 */
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error(`${req.method} ${req.url}: ${err.message}`)
  console.error(err.stack || "No stack trace available")

  res.status(500).json({
    status: "error",
    message: "An unexpected error occurred",
    error: config.nodeEnv === "production" ? undefined : err.message,
  })
})

/**
 * Start the server
 */
app.listen(PORT, () => {
  console.log(`✅ Server is running on http://${config.host}:${PORT}`)
  console.log(`✅ Environment: ${config.nodeEnv}`)
})

/**
 * Handle unhandled promise rejections
 */
process.on("unhandledRejection", (reason: any) => {
  console.error("Unhandled Promise Rejection:")
  console.error(reason)
})

/**
 * Handle uncaught exceptions
 */
process.on("uncaughtException", (error: Error) => {
  console.error("Uncaught Exception:")
  console.error(error)

  // Exit with error
  process.exit(1)
})

