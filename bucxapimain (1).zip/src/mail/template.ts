import nodemailer from "nodemailer"
import { OTPTYPE } from "../constant"
import { OtpService } from "../otp/service"
import { config } from "../config"

// Create reusable transporter
const createTransporter = () => {
  // For Gmail
  if (config.emailService === "gmail") {
    return nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: config.emailUser,
        pass: config.emailPass,
      },
    })
  }

  // For other SMTP services
  return nodemailer.createTransport({
    host: config.emailHost,
    port: config.emailPort,
    secure: config.emailSecure,
    auth: {
      user: config.emailUser,
      pass: config.emailPass,
    },
  })
}

export class MailTemplate {
  static async sendVerificationEmail(email: string) {
    try {
      const otp = await OtpService.generateOtp({ email, type: OTPTYPE.emailVerification })

      const mailOptions = {
        from: `"BUX App" <${config.emailFrom || config.emailUser}>`,
        to: email,
        subject: "Your OTP for Email Verification",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
            <div style="text-align: center; margin-bottom: 20px;">
              <h1 style="color: #333;">BUX</h1>
              <p style="color: #666;">BORDERLESS BANKING EXPERIENCE</p>
            </div>
            <h2 style="color: #333;">Verify Your Email</h2>
            <p>Thank you for signing up. To complete your registration, please use the following verification code:</p>
            <div style="background-color: #f7f7f7; padding: 15px; border-radius: 5px; font-size: 24px; text-align: center; letter-spacing: 5px; font-weight: bold; margin: 20px 0;">
              ${otp}
            </div>
            <p style="margin-top: 20px; font-size: 14px; color: #777;">This code will expire in 10 minutes.</p>
            <p style="margin-top: 30px; font-size: 14px; color: #777;">If you didn't request this verification, please ignore this email.</p>
          </div>
        `,
      }

      const transporter = createTransporter()
      await transporter.sendMail(mailOptions)
      console.log(`Verification email sent to ${email}`)

      return otp
    } catch (error) {
      console.error("Failed to send verification email:", error)
      throw new Error("Failed to send verification email")
    }
  }

  static async sendForgotPasswordEmail(email: string) {
    try {
      const otp = await OtpService.generateOtp({ email, type: OTPTYPE.forgotPassword })

      const mailOptions = {
        from: `"BUX App" <${config.emailFrom || config.emailUser}>`,
        to: email,
        subject: "Password Reset Request",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
            <div style="text-align: center; margin-bottom: 20px;">
              <h1 style="color: #333;">BUX</h1>
              <p style="color: #666;">BORDERLESS BANKING EXPERIENCE</p>
            </div>
            <h2 style="color: #333;">Reset Your Password</h2>
            <p>We received a request to reset your password. Please use the following code to reset your password:</p>
            <div style="background-color: #f7f7f7; padding: 15px; border-radius: 5px; font-size: 24px; text-align: center; letter-spacing: 5px; font-weight: bold; margin: 20px 0;">
              ${otp}
            </div>
            <p style="margin-top: 20px; font-size: 14px; color: #777;">This code will expire in 10 minutes.</p>
            <p style="margin-top: 30px; font-size: 14px; color: #777;">If you didn't request a password reset, please ignore this email or contact support if you have concerns.</p>
          </div>
        `,
      }

      const transporter = createTransporter()
      await transporter.sendMail(mailOptions)
      console.log(`Password reset email sent to ${email}`)

      return otp
    } catch (error) {
      console.error("Failed to send password reset email:", error)
      throw new Error("Failed to send password reset email")
    }
  }

  static async sendWelcomeEmail(email: string, name: string) {
    try {
      const mailOptions = {
        from: `"BUX App" <${config.emailFrom || config.emailUser}>`,
        to: email,
        subject: "Welcome to BUX!",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 5px;">
            <div style="text-align: center; margin-bottom: 20px;">
              <h1 style="color: #333;">BUX</h1>
              <p style="color: #666;">BORDERLESS BANKING EXPERIENCE</p>
            </div>
            <h2 style="color: #333;">Welcome, ${name}!</h2>
            <p>Thank you for joining BUX. Your account has been successfully verified and is now ready to use.</p>
            <p>With BUX, you can:</p>
            <ul style="margin-top: 20px; margin-bottom: 20px;">
              <li>Manage your digital assets securely</li>
              <li>Send and receive payments</li>
              <li>Access exclusive features and services</li>
            </ul>
            <p>If you have any questions or need assistance, please don't hesitate to contact our support team.</p>
          </div>
        `,
      }

      const transporter = createTransporter()
      await transporter.sendMail(mailOptions)
      console.log(`Welcome email sent to ${email}`)
    } catch (error) {
      console.error("Failed to send welcome email:", error)
      // Don't throw here as this is not critical for the user flow
    }
  }
}

