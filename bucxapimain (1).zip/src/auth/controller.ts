import { AuthSevice } from "./service"
import type { Request, Response } from "express"
import { OTPTYPE } from "../constant"
import { User } from "../models/user"

export class AuthController {
  // Step 1: Create account with email only
  async createAccount(req: Request, res: Response) {
    const { email } = req.body
    try {
      if (!email) {
        return res.status(400).json({ message: "Email is required" })
      }

      const data = await AuthSevice.createAccount({ email })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Account creation failed" })
    }
  }

  // Step 2: Verify email with OTP
  async verifyEmail(req: Request, res: Response) {
    const { email, otp } = req.body
    try {
      if (!email || !otp) {
        return res.status(400).json({ message: "Email and OTP are required" })
      }

      const data = await AuthSevice.verifyEmail({ email, otp })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Email verification failed" })
    }
  }

  // Step 3: Update profile with full name, country, account type, and phone number
  async updateProfile(req: Request, res: Response) {
    const { userId, firstname, lastname, country, accountType, phone } = req.body
    try {
      if (!userId || !firstname || !lastname || !country || !accountType || !phone) {
        return res.status(400).json({ message: "All fields are required" })
      }

      const data = await AuthSevice.updateProfile({ userId, firstname, lastname, country, accountType, phone })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Profile update failed" })
    }
  }

  // Step 4: Set password
  async setPassword(req: Request, res: Response) {
    const { userId, password, confirmPassword } = req.body
    try {
      if (!userId || !password || !confirmPassword) {
        return res.status(400).json({ message: "All fields are required" })
      }

      if (password !== confirmPassword) {
        return res.status(400).json({ message: "Passwords do not match" })
      }

      const data = await AuthSevice.setPassword({ userId, password, confirmPassword })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Password setup failed" })
    }
  }

  // Login with email and password
  async login(req: Request, res: Response) {
    const { email, password } = req.body
    try {
      const data = await AuthSevice.authenticateUser({ email, password })
      return res.json(data)
    } catch (e: any) {
      return res.status(401).json({ message: e.message || "Authentication failed" })
    }
  }

  async thirdPartyLogin(req: Request, res: Response) {
    const { type, token } = req.body
    try {
      const data = await AuthSevice.thirdPartyLogin({ type, token })
      return res.json(data)
    } catch (e: any) {
      return res.status(401).json({ message: e.message || "Authentication failed" })
    }
  }

  // Request password reset
  async forgotPassword(req: Request, res: Response) {
    const { email } = req.body
    try {
      const data = await AuthSevice.forgotPassword({ email })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to process request" })
    }
  }

  // Verify reset password OTP
  async verifyResetPasswordOtp(req: Request, res: Response) {
    const { email, otp } = req.body
    try {
      const data = await AuthSevice.verifyResetPasswordOtp({ email, otp })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to verify OTP" })
    }
  }

  // Reset password with new password
  async resetPassword(req: Request, res: Response) {
    const { email, newPassword, resetToken } = req.body
    try {
      const data = await AuthSevice.resetPassword({ email, newPassword, resetToken })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to reset password" })
    }
  }

  async resendOtp(req: Request, res: Response) {
    const { email, type } = req.body
    try {
      if (!email || !type) {
        return res.status(400).json({ message: "Email and type are required" })
      }

      if (type !== OTPTYPE.emailVerification && type !== OTPTYPE.forgotPassword) {
        return res.status(400).json({ message: "Invalid OTP type" })
      }

      await AuthSevice.resendOtp({ email, type })
      return res.json({ message: "OTP sent successfully" })
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to resend OTP" })
    }
  }

  /**
   * Check Bridge KYC status for the authenticated user
   */
  async checkBridgeKycStatus(req: Request, res: Response) {
    try {
      const user = req.user as any
      if (!user) {
        return res.status(401).json({ message: "Authentication required" })
      }

      const updatedUser = await AuthSevice.checkBridgeKycStatus(user._id)

      return res.json({
        bridgeKycStatus: updatedUser.bridgeKycStatus,
        bridgeTosStatus: updatedUser.bridgeTosStatus,
        bridgeCustomerId: updatedUser.bridgeCustomerId,
      })
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to check KYC status" })
    }
  }

  /**
   * Create a Bridge KYC link for a business
   */
  async createBusinessKycLink(req: Request, res: Response) {
    const { businessName, email } = req.body
    try {
      const user = req.user as any
      if (!user) {
        return res.status(401).json({ message: "Authentication required" })
      }

      if (!businessName || !email) {
        return res.status(400).json({ message: "Business name and email are required" })
      }

      const kycLink = await AuthSevice.createBusinessKycLink({
        businessName,
        email,
        userId: user._id,
      })

      return res.json(kycLink)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to create business KYC link" })
    }
  }

  /**
   * Update Bridge info for the authenticated user
   */
  async updateBridgeInfo(req: Request, res: Response) {
    try {
      const user = req.user as any
      if (!user) {
        return res.status(401).json({ message: "Authentication required" })
      }

      const { bridgeCustomerId, bridgeKycStatus, bridgeTosStatus, bridgeKycLinkId } = req.body

      // Update only the fields that are provided
      const updateData: any = {}
      if (bridgeCustomerId) updateData.bridgeCustomerId = bridgeCustomerId
      if (bridgeKycStatus) updateData.bridgeKycStatus = bridgeKycStatus
      if (bridgeTosStatus) updateData.bridgeTosStatus = bridgeTosStatus
      if (bridgeKycLinkId) updateData.bridgeKycLinkId = bridgeKycLinkId

      if (Object.keys(updateData).length === 0) {
        return res.status(400).json({ message: "No update data provided" })
      }

      // Update the user
      const updatedUser = await User.findByIdAndUpdate(user._id, updateData, { new: true })

      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" })
      }

      return res.json({
        message: "Bridge info updated successfully",
        user: {
          id: updatedUser._id,
          email: updatedUser.email,
          bridgeCustomerId: updatedUser.bridgeCustomerId,
          bridgeKycStatus: updatedUser.bridgeKycStatus,
          bridgeTosStatus: updatedUser.bridgeTosStatus,
          bridgeKycLinkId: updatedUser.bridgeKycLinkId,
        },
      })
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Failed to update Bridge info" })
    }
  }
}

