# BUX API

BUX API is a backend service for the Borderless Banking Experience platform. It provides authentication, wallet management, and integration with Bridge API for virtual accounts.

## Features

- User authentication (email/password and Google OAuth)
- Email verification with OTP
- Password reset functionality
- Solana wallet creation and management
- Bridge API integration for virtual accounts
- MongoDB database integration

## Prerequisites

- Node.js (v16+)
- npm or yarn
- MongoDB (v4.4+)
- Gmail account (for sending emails)

## MongoDB Setup

### Local Development

1. Install MongoDB Community Edition:
   - [MongoDB Installation Guide](https://docs.mongodb.com/manual/installation/)

2. Start MongoDB service:
   ```bash
   # On Linux
   sudo systemctl start mongod
   
   # On macOS with Homebrew
   brew services start mongodb-community
   
   # On Windows
   net start MongoDB

