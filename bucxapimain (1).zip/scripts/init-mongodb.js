/**
 * MongoDB Database Initialization Script
 *
 * This script initializes the MongoDB database with the required collections and indexes.
 * Run with: node scripts/init-mongodb.js
 */

const mongoose = require("mongoose")
const dotenv = require("dotenv")

// Load environment variables
dotenv.config()

// MongoDB connection URI
const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/bux"

// Connect to MongoDB
mongoose
  .connect(MONGODB_URI)
  .then(() => console.log("Connected to MongoDB"))
  .catch((err) => {
    console.error("Failed to connect to MongoDB:", err)
    process.exit(1)
  })

// Define schemas
const userSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true },
    firstname: { type: String, required: true },
    lastname: { type: String, required: true },
    password: { type: String },
    usdcWallet: { type: String },
    googleId: { type: String },
    emailIsVerified: { type: Boolean, default: false },
    resetPasswordToken: { type: String },
    resetPasswordExpires: { type: Date },
  },
  { timestamps: true },
)

const otpSchema = new mongoose.Schema(
  {
    email: { type: String, required: true },
    otp: { type: String, required: true },
    type: { type: String, required: true },
    genratedCount: { type: Number, default: 1 },
    expiresAt: { type: Date, required: true },
  },
  { timestamps: true },
)

const walletSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    solWallet: { type: mongoose.Schema.Types.ObjectId, ref: "solWallet" },
    usdWallet: { type: mongoose.Schema.Types.ObjectId, ref: "usdWallet" },
    nairaWallet: { type: String },
    seedPhrase: { type: String, required: true },
  },
  { timestamps: true },
)

const solWalletSchema = new mongoose.Schema(
  {
    wid: { type: String, required: true },
    address: { type: String, required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true },
)

const usdWalletSchema = new mongoose.Schema(
  {
    wid: { type: String, required: true },
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, required: true },
    customer_id: { type: String, required: true },
    source_deposit_instructions: {
      currency: { type: String },
      bank_beneficiary_name: { type: String },
      bank_name: { type: String },
      bank_address: { type: String },
      bank_routing_number: { type: String },
      bank_account_number: { type: String },
      payment_rails: [String],
      payment_rail: { type: String },
    },
    destination: {
      currency: { type: String },
      payment_rail: { type: String },
      address: { type: String },
    },
    developer_fee_percent: { type: String },
  },
  { timestamps: true },
)

// Create models
const User = mongoose.model("User", userSchema)
const Otp = mongoose.model("Otp", otpSchema)
const Wallet = mongoose.model("Wallet", walletSchema)
const SolWallet = mongoose.model("solWallet", solWalletSchema)
const UsdWallet = mongoose.model("usdWallet", usdWalletSchema)

// Create indexes
async function createIndexes() {
  try {
    console.log("Creating indexes...")

    // User indexes
    await User.collection.createIndex({ email: 1 }, { unique: true })
    await User.collection.createIndex({ googleId: 1 }, { sparse: true })

    // OTP indexes
    await Otp.collection.createIndex({ email: 1, type: 1 })
    await Otp.collection.createIndex({ expiresAt: 1 }, { expireAfterSeconds: 0 }) // TTL index

    // Wallet indexes
    await Wallet.collection.createIndex({ user: 1 }, { unique: true })

    // SolWallet indexes
    await SolWallet.collection.createIndex({ user: 1 })
    await SolWallet.collection.createIndex({ address: 1 }, { unique: true })

    // UsdWallet indexes
    await UsdWallet.collection.createIndex({ user: 1 })
    await UsdWallet.collection.createIndex({ wid: 1 }, { unique: true })

    console.log("Indexes created successfully")
  } catch (error) {
    console.error("Error creating indexes:", error)
    process.exit(1)
  }
}

// Run initialization
async function initializeDatabase() {
  try {
    await createIndexes()
    console.log("Database initialization completed successfully")
  } catch (error) {
    console.error("Database initialization failed:", error)
  } finally {
    mongoose.disconnect()
  }
}

initializeDatabase()

