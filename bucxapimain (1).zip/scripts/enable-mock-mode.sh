#!/bin/bash

# Script to enable mock mode for testing
# Usage: source ./enable-mock-mode.sh

export USE_MOCKS="true"
echo "✅ Mock mode enabled. All Bridge API requests will use mock responses."
echo "To disable mock mode, run: export USE_MOCKS=\"false\""

