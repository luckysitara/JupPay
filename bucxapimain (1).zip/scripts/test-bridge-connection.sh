#!/bin/bash

# Script to test Bridge API connection
# Usage: ./test-bridge-connection.sh [API_KEY]

# Set API key from argument or environment variable
API_KEY=${1:-$BRIDGE_API_KEY}

if [ -z "$API_KEY" ]; then
  echo "Error: No API key provided. Please provide an API key as an argument or set BRIDGE_API_KEY environment variable."
  exit 1
fi

# Determine base URL based on API key prefix
if [[ "$API_KEY" == sk-test-* ]]; then
  BASE_URL=${BRIDGE_BASE_URL:-"https://api.sandbox.bridge.xyz/v0"}
  echo "Detected sandbox API key, using sandbox URL"
else
  BASE_URL=${BRIDGE_BASE_URL:-"https://api.bridge.xyz/v0"}
  echo "Using production URL"
fi

# Generate a unique idempotency key
IDEMPOTENCY_KEY="test-$(date +%s)"

echo "Testing Bridge API connection..."
echo "Base URL: $BASE_URL"
echo "API Key: ${API_KEY:0:8}...${API_KEY: -4}"

# Make a request to the TOS endpoint
response=$(curl --silent --location --request POST "$BASE_URL/customers/tos_links" \
  --header "Content-Type: application/json" \
  --header "Api-Key: $API_KEY" \
  --header "Idempotency-Key: $IDEMPOTENCY_KEY" \
  -w "\n%{http_code}")

# Extract status code and response body
http_code=$(echo "$response" | tail -n1)
body=$(echo "$response" | sed '$d')

echo "Response status code: $http_code"
echo "Response body: $body"

if [[ $http_code -ge 200 && $http_code -lt 300 ]]; then
  echo "✅ Bridge API connection successful!"
  exit 0
else
  echo "❌ Bridge API connection failed!"
  exit 1
fi

