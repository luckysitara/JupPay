/**
 * TypeScript version of the delete-all-users script
 *
 * Usage:
 * ts-node scripts/delete-all-users.ts
 *
 * Options:
 * --related-data    Also delete related data (OTPs, wallets, etc.)
 * --confirm         Skip confirmation prompt
 *
 * Example:
 * ts-node scripts/delete-all-users.ts --related-data --confirm
 */

import dotenv from "dotenv"
import mongoose from "mongoose"
import readline from "readline"

// Load environment variables
dotenv.config()

// Parse command line arguments
const args = process.argv.slice(2)
const shouldDeleteRelatedData = args.includes("--related-data")
const skipConfirmation = args.includes("--confirm")

// Create readline interface for user input
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

// MongoDB connection URI
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGODB_URL || "mongodb://localhost:27017/bux"

// Connect to MongoDB
async function connectToDatabase(): Promise<boolean> {
  try {
    console.log(`Connecting to MongoDB at ${MONGODB_URI.split("@").pop()}...`)
    await mongoose.connect(MONGODB_URI)
    console.log("Connected to MongoDB")
    return true
  } catch (error: any) {
    console.error("Failed to connect to MongoDB:", error.message)
    return false
  }
}

// Define schemas (simplified versions of your actual schemas)
const userSchema = new mongoose.Schema({
  email: String,
  firstname: String,
  lastname: String,
  password: String,
  emailIsVerified: Boolean,
})

const otpSchema = new mongoose.Schema({
  email: String,
  otp: String,
  type: String,
})

const walletSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
})

const solWalletSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
})

const usdWalletSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
})

// Create models
const User = mongoose.model("User", userSchema)
const Otp = mongoose.model("Otp", otpSchema)
const Wallet = mongoose.model("Wallet", walletSchema)
const SolWallet = mongoose.model("solWallet", solWalletSchema)
const UsdWallet = mongoose.model("usdWallet", usdWalletSchema)

// Delete all users
async function deleteAllUsers(): Promise<number> {
  try {
    // Count users before deletion
    const userCount = await User.countDocuments()
    console.log(`Found ${userCount} users in the database`)

    if (userCount === 0) {
      console.log("No users to delete")
      return 0
    }

    // Delete all users
    const result = await User.deleteMany({})
    console.log(`Deleted ${result.deletedCount} users`)

    return result.deletedCount
  } catch (error: any) {
    console.error("Error deleting users:", error.message)
    throw error
  }
}

// Delete related data (OTPs, wallets)
async function deleteRelatedData(): Promise<{
  otps: number
  wallets: number
  solWallets: number
  usdWallets: number
}> {
  try {
    // Delete OTPs
    const otpResult = await Otp.deleteMany({})
    console.log(`Deleted ${otpResult.deletedCount} OTPs`)

    // Delete wallets and related documents
    const walletResult = await Wallet.deleteMany({})
    console.log(`Deleted ${walletResult.deletedCount} wallets`)

    const solWalletResult = await SolWallet.deleteMany({})
    console.log(`Deleted ${solWalletResult.deletedCount} Solana wallets`)

    const usdWalletResult = await UsdWallet.deleteMany({})
    console.log(`Deleted ${usdWalletResult.deletedCount} USD wallets`)

    return {
      otps: otpResult.deletedCount,
      wallets: walletResult.deletedCount,
      solWallets: solWalletResult.deletedCount,
      usdWallets: usdWalletResult.deletedCount,
    }
  } catch (error: any) {
    console.error("Error deleting related data:", error.message)
    throw error
  }
}

// Main function
async function main(): Promise<void> {
  // Connect to database
  const connected = await connectToDatabase()
  if (!connected) {
    process.exit(1)
  }

  try {
    // Get confirmation unless --confirm flag is used
    if (!skipConfirmation) {
      await new Promise<void>((resolve) => {
        rl.question(
          `⚠️ WARNING: This will delete ALL users${shouldDeleteRelatedData ? " and related data" : ""} from the database.\nAre you sure you want to continue? (yes/no): `,
          (answer) => {
            if (answer.toLowerCase() !== "yes") {
              console.log("Operation cancelled")
              process.exit(0)
            }
            resolve()
          },
        )
      })
    }

    console.log("Starting deletion process...")

    // Delete users
    const deletedUsers = await deleteAllUsers()

    // Delete related data if requested
    if (shouldDeleteRelatedData) {
      await deleteRelatedData()
    }

    console.log("Deletion process completed successfully")
  } catch (error) {
    console.error("An error occurred during the deletion process:", error)
  } finally {
    // Close readline interface
    rl.close()

    // Disconnect from database
    await mongoose.disconnect()
    console.log("Disconnected from MongoDB")
  }
}

// Run the script
main()

