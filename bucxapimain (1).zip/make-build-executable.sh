#!/bin/bash
chmod +x build.sh

