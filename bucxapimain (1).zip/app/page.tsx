"use client"

import  from "../src/app"

export default function SyntheticV0PageForDeployment() {
  return < />
}