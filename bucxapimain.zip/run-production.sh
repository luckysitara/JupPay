#!/bin/bash

# Exit on error
set -e

echo "Starting BUX API in production mode..."

# Check if .env file exists
if [ ! -f .env ]; then
  echo "Error: .env file not found. Please create one based on .env.example"
  exit 1
fi

# Check if dist directory exists
if [ ! -d dist ]; then
  echo "Error: dist directory not found. Please run the production build first."
  echo "Run: ./production-build.sh"
  exit 1
fi

# Set production environment
export NODE_ENV=production

# Start the server
node dist/app.js

