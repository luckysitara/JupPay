/**
 * Application Configuration
 *
 * This file centralizes all configuration variables used throughout the application.
 */

export const config = {
  // Server configuration
  port: process.env.PORT ? Number(process.env.PORT) : 5002,
  host: process.env.HOST || "localhost",
  nodeEnv: process.env.NODE_ENV || "development",

  // MongoDB configuration
  mongodbUri: process.env.MONGODB_URI || process.env.MONGODB_URL || "mongodb://localhost:27017/bux",

  // JWT configuration
  jwtSecret: process.env.JWT_SECRET || "your-jwt-secret-key-should-be-long-and-random",
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || "24h",

  // Email configuration
  emailFrom: process.env.EMAIL_FROM || process.env.EMAIL_USER || "",
  emailUser: process.env.EMAIL_USER || "",
  emailPass: process.env.EMAIL_PASS || "",
  emailService: process.env.EMAIL_SERVICE || "gmail",
  emailHost: process.env.EMAIL_HOST || "",
  emailPort: process.env.EMAIL_PORT ? Number(process.env.EMAIL_PORT) : 587,
  emailSecure: process.env.EMAIL_SECURE === "true",

  // Google OAuth configuration
  googleClientId: process.env.GOOGLE_CLIENT_ID || "",
  googleClientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
  googleCallbackUrl: process.env.GOOGLE_CALLBACK_URL || "",

  // Bridge API configuration
  bridgeApiKey: process.env.BRIDGE_API_KEY || "",
  bridgeBaseUrl: process.env.BRIDGE_API_KEY?.startsWith("sk-test-")
    ? process.env.BRIDGE_BASE_URL || "https://api.sandbox.bridge.xyz/v0"
    : process.env.BRIDGE_BASE_URL || "https://api.bridge.xyz/v0",
  bridgeEnvironment: process.env.BRIDGE_API_KEY?.startsWith("sk-test-") ? "sandbox" : "production",

  // CORS configuration
  corsOrigins: process.env.CORS_ORIGINS ? process.env.CORS_ORIGINS.split(",") : ["http://localhost:3000"],

  // Logging configuration
  logLevel: process.env.LOG_LEVEL || "info",

  // Debug mode
  debug: process.env.DEBUG === "true",
}

