/**
 * Application Constants
 *
 * This file defines constants used throughout the application.
 */

// Evervault API endpoints for secure data encryption/decryption
export const EVERVAULT_ENCRYPT_URL = "https://api.evervault.com/encrypt"
export const EVERVAULT_DECRYPT_URL = "https://api.evervault.com/decrypt"

// Bridge API base URL and endpoints
export const BRIDGE_API_URL = "https://api.bridge.xyz/v0"
export const BRIDGE_CUSTOMERS_URL = `${BRIDGE_API_URL}/customers`
export const BRIDGE_TOS_URL = `${BRIDGE_API_URL}/customers/tos_links`
export const BRIDGE_KYC_URL = `${BRIDGE_API_URL}/customers/{customerId}/kyc`
export const BRIDGE_WALLETS_URL = `${BRIDGE_API_URL}/customers/{customerId}/wallets`
export const BRIDGE_VIRTUAL_ACCOUNTS_URL = `${BRIDGE_API_URL}/customers/{customerId}/virtual_accounts`
export const BRIDGE_VIRTUALACCOUNT_URL = `${BRIDGE_API_URL}/customers/{customerId}/virtual_accounts`

/**
 * OTP Types
 * Different types of one-time passwords used in the application
 */
export enum OTPTYPE {
  forgotPassword = "forgotPassword",
  emailVerification = "emailVerification",
}

/**
 * Authentication Types
 * Different methods of third-party authentication
 */
export enum AUTHTYPEWITHTHIRDPARTY {
  google = "google",
}

/**
 * Bridge Customer Status
 * Possible states for a customer in the Bridge API
 */
export enum BRIDGE_CUSTOMER_STATUS {
  NOT_STARTED = "not_started",
  PENDING = "pending",
  ACTIVE = "active",
  UNDER_REVIEW = "under_review",
  REJECTED = "rejected",
}

/**
 * Bridge KYC Status
 * Possible states for KYC verification in the Bridge API
 */
export enum BRIDGE_KYC_STATUS {
  NOT_STARTED = "not_started",
  PENDING = "pending",
  APPROVED = "approved",
  REJECTED = "rejected",
}

/**
 * Bridge Account Status
 * Possible states for a virtual account in the Bridge API
 */
export enum BRIDGE_ACCOUNT_STATUS {
  ACTIVE = "active",
  INACTIVE = "inactive",
  SUSPENDED = "suspended",
}

/**
 * Bridge Wallet Types
 * Types of wallets supported by Bridge API
 */
export enum BRIDGE_WALLET_TYPE {
  SOLANA = "solana",
  ETHEREUM = "ethereum",
}

/**
 * Bridge Currency Types
 * Types of currencies supported by Bridge API
 */
export enum BRIDGE_CURRENCY {
  USD = "usd",
  USDC = "usdc",
}

/**
 * Bridge Payment Rails
 * Payment methods supported by Bridge API
 */
export enum BRIDGE_PAYMENT_RAIL {
  SOLANA = "solana",
  ETHEREUM = "ethereum",
  ACH = "ach",
  WIRE = "wire",
}

