/**
 * Application Constants
 *
 * This file defines constants used throughout the application.
 */

// Bridge API endpoints for customer management and transactions
export const BRIDGE_API_URL = process.env.BRIDGE_BASE_URL || "https://api.bridge.xyz/v0"
export const BRIDGE_CUSTOMERS_URL = `${BRIDGE_API_URL}/customers`
export const BRIDGE_TOS_URL = `${BRIDGE_API_URL}/customers/tos_links`
export const BRIDGE_KYC_URL = `${BRIDGE_API_URL}/customers/{customerId}/kyc`
export const BRIDGE_VIRTUAL_ACCOUNTS_URL = `${BRIDGE_API_URL}/customers/{customerId}/virtual_accounts`

/**
 * OTP Types
 * Different types of one-time passwords used in the application
 */
export enum OTPTYPE {
  forgotPassword = "forgotPassword",
  emailVerification = "emailVerification",
}

/**
 * Authentication Types
 * Different methods of third-party authentication
 */
export enum AUTHTYPEWITHTHIRDPARTY {
  google = "google",
}

/**
 * Bridge Customer Status
 * Possible states for a customer in the Bridge API
 */
export enum BRIDGE_CUSTOMER_STATUS {
  NOT_STARTED = "not_started",
  PENDING = "pending",
  ACTIVE = "active",
  UNDER_REVIEW = "under_review",
  REJECTED = "rejected",
}

/**
 * Bridge KYC Status
 * Possible states for KYC verification in the Bridge API
 */
export enum BRIDGE_KYC_STATUS {
  NOT_STARTED = "not_started",
  PENDING = "pending",
  APPROVED = "approved",
  REJECTED = "rejected",
}

/**
 * Bridge Account Status
 * Possible states for a virtual account in the Bridge API
 */
export enum BRIDGE_ACCOUNT_STATUS {
  ACTIVE = "active",
  INACTIVE = "inactive",
  SUSPENDED = "suspended",
}

/**
 * Bridge Payment Rails
 * Payment methods supported by Bridge API
 */
export enum BRIDGE_PAYMENT_RAIL {
  SOLANA = "solana",
  ETHEREUM = "ethereum",
  ACH = "ach",
  WIRE = "wire",
}

/**
 * Bridge Currency Types
 * Types of currencies supported by Bridge API
 */
export enum BRIDGE_CURRENCY {
  USD = "usd",
  USDC = "usdc",
}

/**
 * Bridge Environments
 * Available Bridge API environments
 */
export enum BRIDGE_ENVIRONMENT {
  PRODUCTION = "production",
  SANDBOX = "sandbox",
}

