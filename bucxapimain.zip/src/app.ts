/**
 * BUX API - Main Application Entry Point
 *
 * This file initializes the Express application, connects to MongoDB,
 * sets up middleware, and defines the main routes.
 */

// Load environment variables first
import dotenv from "dotenv"
dotenv.config()

// Import dependencies
import express, { type Application, type Request, type Response, type NextFunction } from "express"
import cors from "cors"
import helmet from "helmet"
import mongoose from "mongoose"
import logger from "./utils/logger"

// Import routes
import { Authroute } from "./auth/route"
import { BridgeRoute } from "./routes/bridge.route"
import { DebugRoute } from "./routes/debug.route"

// Create Express application
const app: Application = express()
const PORT = process.env.PORT || 5002

// Connect to MongoDB
const MONGODB_URI = process.env.MONGODB_URI || process.env.MONGODB_URL || "mongodb://localhost:27017/bux"

mongoose
  .connect(MONGODB_URI)
  .then(() => {
    logger.info("MongoDB Connected")
  })
  .catch((err) => {
    logger.error("MongoDB Connection Error:", err)
    logger.warn("Running without database connection. Some features may not work.")
  })

// Apply middleware
app.use(helmet()) // Security headers
app.use(cors()) // Cross-Origin Resource Sharing
app.use(express.json()) // Parse JSON request bodies
app.use(express.urlencoded({ extended: true })) // Parse URL-encoded request bodies

// Initialize routes
const authRoutes = new Authroute()
const bridgeRoutes = new BridgeRoute()
const debugRoutes = new DebugRoute()

// Register routes
app.use("/api/auth", authRoutes.router)
app.use("/api/bridge", bridgeRoutes.router)

// Only enable debug routes in development mode
if (process.env.NODE_ENV === "development" || process.env.DEBUG === "true") {
  app.use("/api/debug", debugRoutes.router)
}

// Default route
app.get("/", (req: Request, res: Response) => {
  res.json({
    status: "online",
    message: "BUX API is running",
    version: "1.0.0",
    environment: process.env.NODE_ENV || "development",
    timestamp: new Date().toISOString(),
  })
})

// Health check route
app.get("/health", (req: Request, res: Response) => {
  res.status(200).json({ status: "healthy" })
})

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).json({
    status: "error",
    message: `Route not found: ${req.method} ${req.url}`,
  })
})

// Global error handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  logger.error(`${req.method} ${req.url}: ${err.message}`)
  logger.error(err.stack || "No stack trace available")

  res.status(500).json({
    status: "error",
    message: "An unexpected error occurred",
    error: process.env.NODE_ENV === "production" ? undefined : err.message,
  })
})

// Start the server
app.listen(PORT, () => {
  logger.info(`✅ Server is running on http://localhost:${PORT}`)
  logger.info(`✅ Environment: ${process.env.NODE_ENV || "development"}`)
})

// Handle unhandled promise rejections
process.on("unhandledRejection", (reason: any) => {
  logger.error("Unhandled Promise Rejection:")
  logger.error(reason)
})

// Handle uncaught exceptions
process.on("uncaughtException", (error: Error) => {
  logger.error("Uncaught Exception:")
  logger.error(error)

  // Exit with error
  process.exit(1)
})

export default app

