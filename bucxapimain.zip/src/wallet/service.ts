import * as bip39 from "bip39"
import { Keypair } from "@solana/web3.js"
import { config } from "../config"
import type { Types } from "mongoose"
import { solWallet, usdWallet, Wallet } from "../models/wallet"
import { BridgeService } from "../services/bridge.service"
import { User } from "../models/user"
import logger from "../utils/logger"

export class WalletService {
  static async createWallet({ userId }: { userId: Types.ObjectId | string }) {
    try {
      console.log(`Creating wallet for user: ${userId}`)

      // Generate a seed phrase
      const seedPhrase = bip39.generateMnemonic()
      console.log("Generated seed phrase")

      // Generate a keypair from the seed phrase
      const seed = await bip39.mnemonicToSeed(seedPhrase)
      const keypair = Keypair.fromSeed(seed.slice(0, 32))

      // Get the address and private key
      const address = keypair.publicKey.toString()
      console.log(`Generated Solana address: ${address}`)

      // Create Solana wallet
      const solW = await solWallet.create({
        user: userId,
        address,
        wid: address.substring(0, 8), // Use first 8 chars of address as wallet ID
      })
      console.log(`Created solWallet record with ID: ${solW._id}`)

      // Create wallet record
      const wallet = await Wallet.create({
        user: userId,
        solWallet: solW._id,
        seedPhrase: seedPhrase, // In production, this should be encrypted
      })
      console.log(`Created main wallet record with ID: ${wallet._id}`)

      // Create USDC wallet if Bridge API is configured
      if (config.bridgeApiKey) {
        try {
          await this.createUsdWallet({ user: userId, solAddress: address })
          console.log("Created USDC wallet successfully")
        } catch (error) {
          console.error("Failed to create USDC wallet, but continuing:", error)
          // Continue even if USDC wallet creation fails
        }
      } else {
        console.log("Skipping USDC wallet creation - Bridge API key not configured")
      }

      return wallet
    } catch (error) {
      console.error("Error creating wallet:", error)
      throw new Error("Failed to create wallet")
    }
  }

  static async createUsdWallet({ user, solAddress }: { user: Types.ObjectId | string; solAddress: string }) {
    try {
      logger.info(`Creating USD wallet for user: ${user} with Solana address: ${solAddress}`)

      // If Bridge API key is not configured, create a mock USDC wallet
      if (!config.bridgeApiKey) {
        logger.info("Using mock USDC wallet (Bridge API key not configured)")
        const mockUsdcWallet = await usdWallet.create({
          user,
          wid: `mock-${Date.now()}`,
          status: "active",
          customer_id: `mock-customer-${Date.now()}`,
          source_deposit_instructions: {
            currency: "usd",
            bank_beneficiary_name: "Mock Bank",
            bank_name: "Mock Bank",
            bank_address: "123 Mock St",
            bank_routing_number: "123456789",
            bank_account_number: "987654321",
            payment_rails: ["ach", "wire"],
            payment_rail: "ach",
          },
          destination: {
            currency: "usdc",
            payment_rail: "solana",
            address: solAddress,
          },
          developer_fee_percent: "1.0",
        })

        // Update wallet record with USDC wallet
        await Wallet.findOneAndUpdate({ user }, { usdWallet: mockUsdcWallet._id })

        logger.info(`Created mock USDC wallet with ID: ${mockUsdcWallet._id}`)
        return mockUsdcWallet
      }

      // Get the user's Bridge customer ID
      const userDoc = await User.findById(user)
      if (!userDoc || !userDoc.bridgeCustomerId) {
        throw new Error("User does not have a Bridge customer ID. Please onboard the user first.")
      }

      // Create virtual account using Bridge service
      const virtualAccountData = {
        source: {
          currency: "usd",
        },
        destination: {
          payment_rail: "solana",
          currency: "usdc",
          address: solAddress,
        },
        developer_fee_percent: "1.0", // Standard fee
      }

      logger.info("Creating virtual account via Bridge service")
      const response = await BridgeService.createVirtualAccount(userDoc.bridgeCustomerId, virtualAccountData)

      // Create USDC wallet record
      const usdcWallet = await usdWallet.create({
        user,
        wid: response.id,
        status: response.status,
        customer_id: response.customer_id,
        source_deposit_instructions: response.source_deposit_instructions,
        destination: response.destination,
        developer_fee_percent: response.developer_fee_percent,
      })

      logger.info(`Created USDC wallet record with ID: ${usdcWallet._id}`)

      // Update wallet record with USDC wallet
      await Wallet.findOneAndUpdate({ user }, { usdWallet: usdcWallet._id })

      return usdcWallet
    } catch (error) {
      logger.error("Error creating USDC wallet:", error)
      throw new Error("Failed to create USDC wallet")
    }
  }
}

