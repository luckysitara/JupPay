import type { Request, Response } from "express"
import { AuthService } from "../services/auth.service"
import { AUTHTYPEWITHTHIRDPARTY } from "../constant"

class AuthController {
  async register(req: Request, res: Response) {
    try {
      const data = await AuthService.register(req.body)
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Registration failed" })
    }
  }

  async login(req: Request, res: Response) {
    try {
      const data = await AuthService.login(req.body)
      return res.json(data)
    } catch (e: any) {
      return res.status(401).json({ message: e.message || "Authentication failed" })
    }
  }

  async forgotPassword(req: Request, res: Response) {
    try {
      const { email } = req.body
      const data = await AuthService.forgotPassword(email)
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Request failed" })
    }
  }

  async resetPassword(req: Request, res: Response) {
    try {
      const { password, token } = req.body
      const data = await AuthService.resetPassword({ password, token })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Password reset failed" })
    }
  }

  async verifyEmail(req: Request, res: Response) {
    const { email, otp } = req.body
    try {
      if (!email || !otp) {
        return res.status(400).json({ message: "Email and OTP are required" })
      }

      const data = await AuthService.verifyEmail({ email, otp })
      return res.json(data)
    } catch (e: any) {
      return res.status(400).json({ message: e.message || "Email verification failed" })
    }
  }

  async googleAuth(req: Request, res: Response) {
    const { token } = req.body
    try {
      const data = await AuthService.thirdPartyLogin({ token, type: AUTHTYPEWITHTHIRDPARTY.google })
      return res.json(data)
    } catch (e: any) {
      return res.status(401).json({ message: e.message || "Authentication failed" })
    }
  }
}

export default new AuthController()

