import type { Request, Response } from "express"
import { BridgeService } from "../services/bridge.service"
import logger from "../utils/logger"
import { User } from "../models/User"
import { config } from "../config"
import axios from "axios"

export class BridgeController {
  /**
   * Generate a Terms of Service link
   */
  async generateTosLink(req: Request, res: Response) {
    try {
      const { redirect_uri } = req.body

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      // Log configuration for debugging
      logger.info(`Bridge API Key prefix: ${config.bridgeApiKey.substring(0, 8)}`)
      logger.info(`Bridge Base URL: ${config.bridgeBaseUrl}`)
      logger.info(`Bridge Environment: ${config.bridgeEnvironment}`)

      logger.info(`Generating TOS link${redirect_uri ? " with redirect to " + redirect_uri : ""}`)
      const tosLink = await BridgeService.generateTosLink(redirect_uri)

      return res.status(200).json(tosLink)
    } catch (error: any) {
      logger.error(`TOS link generation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to generate TOS link" })
    }
  }

  /**
   * Create a KYC link for a new customer
   */
  async createKycLink(req: Request, res: Response) {
    try {
      const { full_name, email, type, endorsements, redirect_uri } = req.body

      // Validate required fields
      if (!full_name || !email || !type) {
        return res.status(400).json({
          message: "Missing required fields: full_name, email, and type are required",
        })
      }

      // Validate type
      if (type !== "individual" && type !== "business") {
        return res.status(400).json({
          message: "Type must be either 'individual' or 'business'",
        })
      }

      const kycLink = await BridgeService.createKycLink({ full_name, email, type }, endorsements, redirect_uri)

      return res.status(201).json(kycLink)
    } catch (error: any) {
      logger.error(`KYC link creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create KYC link" })
    }
  }

  /**
   * Get KYC link status
   */
  async getKycLinkStatus(req: Request, res: Response) {
    try {
      const { kycLinkId } = req.params

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      if (!kycLinkId) {
        return res.status(400).json({ message: "KYC link ID is required" })
      }

      const kycLinkStatus = await BridgeService.getKycLinkStatus(kycLinkId)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(kycLinkStatus)
    } catch (error: any) {
      logger.error(`Get KYC link status error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get KYC link status" })
    }
  }

  /**
   * Get KYC link for an existing customer
   */
  async getKycLinkForExistingCustomer(req: Request, res: Response) {
    try {
      const { customerId } = req.params
      const { endorsement } = req.query

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      if (!customerId) {
        return res.status(400).json({ message: "Customer ID is required" })
      }

      const kycLink = await BridgeService.getKycLinkForExistingCustomer(customerId, endorsement as string)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(kycLink)
    } catch (error: any) {
      logger.error(`Get KYC link for existing customer error: ${error.message}`)
      return res.status(500).json({
        message: error.message || "Failed to get KYC link for existing customer",
      })
    }
  }

  /**
   * Get ToS acceptance link for an existing customer
   */
  async getTosAcceptanceLinkForExistingCustomer(req: Request, res: Response) {
    try {
      const { customerId } = req.params

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      if (!customerId) {
        return res.status(400).json({ message: "Customer ID is required" })
      }

      const tosLink = await BridgeService.getTosAcceptanceLinkForExistingCustomer(customerId)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(tosLink)
    } catch (error: any) {
      logger.error(`Get ToS acceptance link error: ${error.message}`)
      return res.status(500).json({
        message: error.message || "Failed to get ToS acceptance link",
      })
    }
  }

  /**
   * Create an individual customer in Bridge
   */
  async createIndividualCustomer(req: Request, res: Response) {
    try {
      const customerData = req.body

      // Log the received data for debugging
      logger.info(`Received individual customer data: ${JSON.stringify(customerData)}`)

      // Validate required fields
      const requiredFields = [
        "first_name",
        "last_name",
        "email",
        "address", // Note: Bridge API uses "address" not "residential_address"
        "birth_date",
        "signed_agreement_id",
        "identifying_information",
      ]

      for (const field of requiredFields) {
        if (!customerData[field]) {
          return res.status(400).json({ message: `Missing required field: ${field}` })
        }
        return res.status(400).json({ message: `Missing required field: ${field}` })
      }

      // Validate address fields
      const requiredAddressFields = ["street_line_1", "city", "subdivision", "postal_code", "country"]
      for (const field of requiredAddressFields) {
        if (!customerData.address[field]) {
          return res.status(400).json({ message: `Missing required address field: ${field}` })
        }
      }

      // Ensure country is in the correct format (3-character ISO code)
      if (customerData.address.country && customerData.address.country.length !== 3) {
        if (customerData.address.country === "USA" || customerData.address.country === "US") {
          customerData.address.country = "USA"
        } else {
          logger.warn(`Country code may not be in ISO 3166-1 format: ${customerData.address.country}`)
        }
      }

      // Validate identifying_information
      if (!Array.isArray(customerData.identifying_information) || customerData.identifying_information.length === 0) {
        return res.status(400).json({
          message: "identifying_information must be an array with at least one item",
        })
      }

      // Validate each identifying_information item
      let hasPhotoId = false
      for (const info of customerData.identifying_information) {
        if (!info.type || !info.issuing_country) {
          return res.status(400).json({
            message: "Each identifying_information item must have type and issuing_country",
          })
        }

        // Bridge API uses "number" not "value" for ID numbers
        if (!info.number && info.value) {
          info.number = info.value
          delete info.value
        }

        // Check if this is a photo ID
        if (info.type === "drivers_license" || info.type === "passport") {
          if (info.type === "drivers_license" && (!info.image_front || !info.image_back)) {
            logger.warn(`Driver's license requires both front and back images`)
          } else if (info.type === "passport" && !info.image_front) {
            logger.warn(`Passport requires a front image`)
          } else {
            hasPhotoId = true
          }
        }
      }

      // Warn if no photo ID is provided
      if (!hasPhotoId) {
        logger.warn(`No government-issued photo ID provided. Bridge API may require this.`)
      }

      // Set type to individual
      customerData.type = "individual"

      const customer = await BridgeService.createIndividualCustomer(customerData)

      // If user is authenticated, associate Bridge customer ID with user
      if (req.user) {
        const user = req.user as any
        await User.findByIdAndUpdate(user._id, { bridgeCustomerId: customer.id })
      }

      return res.status(201).json(customer)
    } catch (error: any) {
      logger.error(`Individual customer creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create individual customer" })
    }
  }

  /**
   * Create a business customer in Bridge
   */
  async createBusinessCustomer(req: Request, res: Response) {
    try {
      const customerData = req.body

      // Log the received data for debugging
      logger.info(`Received business customer data: ${JSON.stringify(customerData)}`)

      // Validate required fields for business
      const requiredFields = [
        "business_legal_name",
        "registered_address",
        "business_type",
        "business_industry",
        "email",
        "signed_agreement_id",
        "identifying_information",
        "has_material_intermediary_ownership",
        "account_purpose",
        "source_of_funds",
        "operates_in_prohibited_countries",
        "conducts_money_services",
        "conducts_money_services_using_bridge",
      ]

      for (const field of requiredFields) {
        if (customerData[field] === undefined) {
          return res.status(400).json({ message: `Missing required field: ${field}` })
        }
      }

      // Validate registered address fields
      const requiredAddressFields = ["street_line_1", "city", "subdivision", "postal_code", "country"]
      for (const field of requiredAddressFields) {
        if (!customerData.registered_address[field]) {
          return res.status(400).json({ message: `Missing required registered address field: ${field}` })
        }
      }

      // Ensure country is in the correct format (3-character ISO code)
      if (customerData.registered_address.country && customerData.registered_address.country.length !== 3) {
        if (customerData.registered_address.country === "USA" || customerData.registered_address.country === "US") {
          customerData.registered_address.country = "USA"
        } else {
          logger.warn(`Country code may not be in ISO 3166-1 format: ${customerData.registered_address.country}`)
        }
      }

      // Validate identifying_information
      if (!Array.isArray(customerData.identifying_information) || customerData.identifying_information.length === 0) {
        return res.status(400).json({
          message: "identifying_information must be an array with at least one item",
        })
      }

      // Validate each identifying_information item and convert value to number if needed
      for (const info of customerData.identifying_information) {
        if (!info.type || !info.issuing_country) {
          return res.status(400).json({
            message: "Each identifying_information item must have type and issuing_country",
          })
        }

        // Bridge API uses "number" not "value" for ID numbers
        if (!info.number && info.value) {
          info.number = info.value
          delete info.value
        }
      }

      // Validate ultimate_beneficial_owners if provided
      if (customerData.ultimate_beneficial_owners) {
        if (
          !Array.isArray(customerData.ultimate_beneficial_owners) ||
          customerData.ultimate_beneficial_owners.length === 0
        ) {
          return res.status(400).json({
            message: "ultimate_beneficial_owners must be an array with at least one item",
          })
        }

        // Validate each UBO
        for (const ubo of customerData.ultimate_beneficial_owners) {
          const requiredUboFields = ["first_name", "last_name", "birth_date", "email", "address"]
          for (const field of requiredUboFields) {
            if (!ubo[field]) {
              return res.status(400).json({
                message: `Missing required field in ultimate_beneficial_owner: ${field}`,
              })
            }
          }

          // Validate UBO identifying_information
          if (
            !ubo.identifying_information ||
            !Array.isArray(ubo.identifying_information) ||
            ubo.identifying_information.length === 0
          ) {
            return res.status(400).json({
              message: "Each ultimate_beneficial_owner must have identifying_information array",
            })
          }

          // Convert value to number if needed in UBO identifying_information
          for (const info of ubo.identifying_information) {
            if (!info.number && info.value) {
              info.number = info.value
              delete info.value
            }
          }
        }
      }

      // Set type to business
      customerData.type = "business"

      const customer = await BridgeService.createBusinessCustomer(customerData)

      // If user is authenticated, associate Bridge customer ID with user
      if (req.user) {
        const user = req.user as any
        await User.findByIdAndUpdate(user._id, { bridgeCustomerId: customer.id })
      }

      return res.status(201).json(customer)
    } catch (error: any) {
      logger.error(`Business customer creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create business customer" })
    }
  }

  /**
   * Get customer details from Bridge
   */
  async getCustomer(req: Request, res: Response) {
    try {
      const { customerId } = req.params

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      if (!customerId) {
        return res.status(400).json({ message: "Customer ID is required" })
      }

      const customer = await BridgeService.getCustomer(customerId)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(customer)
    } catch (error: any) {
      logger.error(`Get customer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get customer" })
    }
  }

  /**
   * Update customer information in Bridge
   */
  async updateCustomer(req: Request, res: Response) {
    try {
      const { customerId } = req.params
      const customerData = req.body

      if (!customerId) {
        return res.status(400).json({ message: "Customer ID is required" })
      }

      // Validate that we have data to update
      if (!customerData || Object.keys(customerData).length === 0) {
        return res.status(400).json({ message: "No data provided for update" })
      }

      const updatedCustomer = await BridgeService.updateCustomer(customerId, customerData)

      return res.status(200).json(updatedCustomer)
    } catch (error: any) {
      logger.error(`Update customer error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to update customer" })
    }
  }

  /**
   * Add an external account via direct API
   */
  async addExternalAccount(req: Request, res: Response) {
    try {
      const { customerId } = req.params
      const accountData = req.body

      // Validate required fields
      const requiredFields = ["bank_name", "account_number", "routing_number", "account_owner_name", "address"]

      for (const field of requiredFields) {
        if (!accountData[field]) {
          return res.status(400).json({ message: `Missing required field: ${field}` })
        }
      }

      // Validate address fields
      const requiredAddressFields = ["street_line_1", "city", "state", "postal_code", "country"]
      for (const field of requiredAddressFields) {
        if (!accountData.address[field]) {
          return res.status(400).json({ message: `Missing required address field: ${field}` })
        }
      }

      const externalAccount = await BridgeService.addExternalAccount(customerId, accountData)

      return res.status(201).json(externalAccount)
    } catch (error: any) {
      logger.error(`External account creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to add external account" })
    }
  }

  /**
   * Create a Plaid link request
   */
  async createPlaidLinkRequest(req: Request, res: Response) {
    try {
      const { customerId } = req.params

      const linkRequest = await BridgeService.createPlaidLinkRequest(customerId)

      return res.status(200).json(linkRequest)
    } catch (error: any) {
      logger.error(`Plaid link request error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create Plaid link request" })
    }
  }

  /**
   * Exchange a Plaid public token
   */
  async exchangePlaidPublicToken(req: Request, res: Response) {
    try {
      const { linkToken } = req.params
      const { public_token } = req.body

      if (!public_token) {
        return res.status(400).json({ message: "Missing public_token" })
      }

      const result = await BridgeService.exchangePlaidPublicToken(linkToken, public_token)

      return res.status(200).json(result)
    } catch (error: any) {
      logger.error(`Plaid token exchange error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to exchange Plaid public token" })
    }
  }

  /**
   * Get external accounts for a customer
   */
  async getExternalAccounts(req: Request, res: Response) {
    try {
      const { customerId } = req.params

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      const accounts = await BridgeService.getExternalAccounts(customerId)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(accounts)
    } catch (error: any) {
      logger.error(`Get external accounts error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get external accounts" })
    }
  }

  /**
   * Create a transfer
   */
  async createTransfer(req: Request, res: Response) {
    try {
      const transferData = req.body

      // Validate required fields
      const requiredFields = ["amount", "on_behalf_of", "source", "destination"]
      for (const field of requiredFields) {
        if (!transferData[field]) {
          return res.status(400).json({ message: `Missing required field: ${field}` })
        }
      }

      // Validate source fields
      if (!transferData.source.payment_rail || !transferData.source.currency) {
        return res.status(400).json({ message: "Source must include payment_rail and currency" })
      }

      // Validate destination fields
      if (!transferData.destination.payment_rail || !transferData.destination.currency) {
        return res.status(400).json({ message: "Destination must include payment_rail and currency" })
      }

      const transfer = await BridgeService.createTransfer(transferData)

      return res.status(201).json(transfer)
    } catch (error: any) {
      logger.error(`Transfer creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create transfer" })
    }
  }

  /**
   * Create a transfer for a specific customer
   */
  async createCustomerTransfer(req: Request, res: Response) {
    try {
      const { customerId } = req.params
      const transferData = req.body

      // Validate required fields
      if (!transferData.amount) {
        return res.status(400).json({ message: "Amount is required" })
      }

      if (!transferData.source) {
        transferData.source = {
          payment_rail: "ach",
          currency: "usd",
        }
      }

      if (!transferData.destination) {
        return res.status(400).json({ message: "Destination is required" })
      }

      // Set the customer ID from the path parameter
      transferData.on_behalf_of = customerId

      const transfer = await BridgeService.createTransfer(transferData)

      return res.status(201).json(transfer)
    } catch (error: any) {
      logger.error(`Transfer creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create transfer" })
    }
  }

  /**
   * Create a virtual account
   */
  async createVirtualAccount(req: Request, res: Response) {
    try {
      const { customerId } = req.params
      const accountData = req.body

      // Validate required fields
      if (!accountData.source || !accountData.destination) {
        return res.status(400).json({ message: "Missing required fields: source and destination" })
      }

      if (!accountData.source.currency) {
        return res.status(400).json({ message: "Source must include currency" })
      }

      if (
        !accountData.destination.payment_rail ||
        !accountData.destination.currency ||
        !accountData.destination.address
      ) {
        return res.status(400).json({
          message: "Destination must include payment_rail, currency, and address",
        })
      }

      const virtualAccount = await BridgeService.createVirtualAccount(customerId, accountData)

      return res.status(201).json(virtualAccount)
    } catch (error: any) {
      logger.error(`Virtual account creation error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to create virtual account" })
    }
  }

  /**
   * Get virtual accounts for a customer
   */
  async getVirtualAccounts(req: Request, res: Response) {
    try {
      const { customerId } = req.params

      // Enable mock mode for testing if needed
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "true"
        logger.info("Enabling mock mode for this request")
      }

      const accounts = await BridgeService.getVirtualAccounts(customerId)

      // Reset mock mode
      if (req.query.mock === "true") {
        process.env.USE_MOCKS = "false"
      }

      return res.status(200).json(accounts)
    } catch (error: any) {
      logger.error(`Get virtual accounts error: ${error.message}`)
      return res.status(500).json({ message: error.message || "Failed to get virtual accounts" })
    }
  }

  // Add a test connection method to the BridgeController
  /**
   * Test Bridge API connection directly
   */
  async testConnection(req: Request, res: Response) {
    try {
      // Check if Bridge API key is configured
      if (!process.env.BRIDGE_API_KEY) {
        return res.status(400).json({
          success: false,
          message: "Bridge API key is not configured in environment variables",
        })
      }

      // Log configuration
      logger.info(`Testing Bridge API connection...`)
      logger.info(
        `Bridge API Key: ${process.env.BRIDGE_API_KEY.substring(0, 8)}...${process.env.BRIDGE_API_KEY.substring(process.env.BRIDGE_API_KEY.length - 4)}`,
      )
      logger.info(`Bridge Base URL: ${process.env.BRIDGE_BASE_URL || "https://api.sandbox.bridge.xyz/v0"}`)

      // Determine base URL based on API key prefix
      const baseUrl = process.env.BRIDGE_API_KEY.startsWith("sk-test-")
        ? process.env.BRIDGE_BASE_URL || "https://api.sandbox.bridge.xyz/v0"
        : process.env.BRIDGE_BASE_URL || "https://api.bridge.xyz/v0"

      // Make a simple request to the TOS endpoint
      const url = `${baseUrl}/customers/tos_links`
      const method = "POST"
      const idempotencyKey = `test-${Date.now()}`

      const headers = {
        "Content-Type": "application/json",
        "Api-Key": process.env.BRIDGE_API_KEY,
        "Idempotency-Key": idempotencyKey,
      }

      logger.info(`Making request to ${url}`)

      const response = await axios({
        method,
        url,
        headers,
        validateStatus: null,
      })

      logger.info(`Response status: ${response.status}`)

      if (response.status >= 200 && response.status < 300) {
        return res.status(200).json({
          success: true,
          message: "Bridge API connection successful",
          status: response.status,
          data: response.data,
        })
      } else {
        return res.status(response.status).json({
          success: false,
          message: "Bridge API connection failed",
          status: response.status,
          error: response.data,
        })
      }
    } catch (error: any) {
      logger.error(`Test connection error: ${error.message}`)
      return res.status(500).json({
        success: false,
        message: error.message || "Failed to test Bridge API connection",
      })
    }
  }
}

