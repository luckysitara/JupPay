import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import dotenv from "dotenv"

dotenv.config()
import { User } from "../models/user"
import { OtpService } from "../otp/service"
import { AUTHTYPEWITHTHIRDPARTY, OTPTYPE } from "../constant"
import { WalletService } from "../wallet/service"
import { MailTemplate as EmailService } from "../mail/template"
import { OAuth2Client } from "google-auth-library"
import { BridgeService } from "../services/bridge.service"
import logger from "../utils/logger"

const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID)

export class AuthSevice {
  static generateToken = (userId: string) => {
    return jwt.sign({ userId }, process.env.JWT_SECRET || "secret", { expiresIn: "1h" })
  }

  // Step 1: Create account with email only (no password yet)
  static createAccount = async (data: { email: string }) => {
    const { email } = data
    try {
      const existingUser = await User.findOne({ email })

      if (existingUser) {
        throw new Error("User already exists")
      }

      // Create a new user with just the email
      const newUser = new User({
        email,
        emailIsVerified: false,
        // Other fields will be added later
        firstname: "",
        lastname: "",
        password: "",
        bridgeKycStatus: "not_started",
        bridgeTosStatus: "pending",
      })

      await newUser.save()

      // Send verification email with OTP
      await EmailService.sendVerificationEmail(email)

      const token = this.generateToken(newUser._id)

      return {
        message: "Account created. Please verify your email.",
        token,
        userId: newUser._id,
      }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  // Step 2: Verify email with OTP
  static verifyEmail = async (data: { otp: number; email: string }) => {
    const { otp, email } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        throw new Error("User not found")
      }

      const isValid = await OtpService.verifyOtp({
        otp,
        email,
        type: OTPTYPE.emailVerification,
      })

      if (!isValid) {
        throw new Error("Invalid or expired OTP")
      }

      user.emailIsVerified = true
      await user.save()

      // Return token and user ID for the next step
      return {
        message: "Email verified successfully",
        token: this.generateToken(user._id),
        userId: user._id,
      }
    } catch (error: any) {
      console.error("Email verification error:", error)
      throw new Error(error.message || "Failed to verify email")
    }
  }

  // Step 3: Update profile with full name, country, account type, and phone number
  static updateProfile = async (data: {
    userId: string
    firstname: string
    lastname: string
    country: string
    accountType: string
    phone: string
  }) => {
    const { userId, firstname, lastname, country, accountType, phone } = data

    try {
      const user = await User.findById(userId)
      if (!user) {
        throw new Error("User not found")
      }

      if (!user.emailIsVerified) {
        throw new Error("Email not verified. Please verify your email first.")
      }

      user.firstname = firstname
      user.lastname = lastname
      user.country = country
      user.accountType = accountType
      user.phone = phone

      await user.save()

      return {
        message: "Profile updated successfully",
        token: this.generateToken(user._id),
        userId: user._id,
      }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  // Step 4: Set password
  static setPassword = async (data: {
    userId: string
    password: string
    confirmPassword: string
  }) => {
    const { userId, password, confirmPassword } = data

    try {
      if (password !== confirmPassword) {
        throw new Error("Passwords do not match")
      }

      const user = await User.findById(userId)
      if (!user) {
        throw new Error("User not found")
      }

      if (!user.emailIsVerified) {
        throw new Error("Email not verified. Please verify your email first.")
      }

      // Check if profile is completed
      if (!user.firstname || !user.lastname || !user.country || !user.accountType || !user.phone) {
        throw new Error("Please complete your profile first")
      }

      const hashedPassword = await bcrypt.hash(password, 12)
      user.password = hashedPassword
      await user.save()

      // Create wallet for verified user with completed profile
      try {
        await WalletService.createWallet({ userId: user._id })
        console.log(`Created wallet for verified user: ${user._id}`)

        // Send welcome email
        await EmailService.sendWelcomeEmail(user.email, user.firstname)
      } catch (error) {
        console.error(`Failed to create wallet for verified user: ${user._id}`, error)
        // Continue even if wallet creation fails
      }

      // Generate a Bridge ToS link for the user
      try {
        const tosLink = await BridgeService.generateTosLink()
        logger.info(`Generated Bridge ToS link for ${user.email}: ${tosLink.url}`)

        // Store the ToS link in the user's session or return it to the client
        // This is just a placeholder - you'll need to implement this based on your app's needs
      } catch (error) {
        logger.error(`Failed to generate Bridge ToS link for ${user.email}: ${error}`)
        // Continue even if Bridge ToS link generation fails
      }

      // Create a Bridge KYC link for the user
      try {
        const kycLink = await BridgeService.createKycLink({
          full_name: `${user.firstname} ${user.lastname}`,
          email: user.email,
          type: "individual",
        })

        logger.info(`Generated Bridge KYC link for ${user.email}: ${kycLink.kyc_link}`)

        // Store the KYC link ID in the user record
        user.bridgeKycLinkId = kycLink.id
        await user.save()

        // Return the KYC link to the client
        return {
          message: "Password set successfully",
          token: this.generateToken(user._id),
          user: {
            id: user._id,
            email: user.email,
            firstname: user.firstname,
            lastname: user.lastname,
            emailIsVerified: true,
            bridgeKycStatus: user.bridgeKycStatus,
            bridgeTosStatus: user.bridgeTosStatus,
            bridgeCustomerId: user.bridgeCustomerId,
          },
          kycLink: kycLink.kyc_link,
          tosLink: kycLink.tos_link,
        }
      } catch (error) {
        logger.error(`Failed to generate Bridge KYC link for ${user.email}: ${error}`)

        // Continue even if Bridge KYC link generation fails
        return {
          message: "Password set successfully",
          token: this.generateToken(user._id),
          user: {
            id: user._id,
            email: user.email,
            firstname: user.firstname,
            lastname: user.lastname,
            emailIsVerified: true,
            bridgeKycStatus: user.bridgeKycStatus,
            bridgeTosStatus: user.bridgeTosStatus,
            bridgeCustomerId: user.bridgeCustomerId,
          },
        }
      }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  // Login with email and password
  static authenticateUser = async (data: { email: string; password: string }) => {
    const { email, password } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        throw new Error("Invalid credentials")
      }

      // Check if user has completed profile
      if (!user.password) {
        throw new Error("Please complete your profile setup")
      }

      const isMatch = await bcrypt.compare(password, user.password)
      if (!isMatch) {
        throw new Error("Invalid credentials")
      }

      // Check if email is verified
      if (!user.emailIsVerified) {
        throw new Error("Email not verified. Please verify your email before logging in.")
      }

      // If the user has a Bridge KYC link ID, check the KYC status
      if (user.bridgeKycLinkId) {
        try {
          const kycLinkStatus = await BridgeService.getKycLinkStatus(user.bridgeKycLinkId)

          // Update the user's Bridge KYC status
          user.bridgeKycStatus = kycLinkStatus.kyc_status
          user.bridgeTosStatus = kycLinkStatus.tos_status

          // If the KYC is approved and a customer ID is available, store it
          if (kycLinkStatus.customer_id) {
            user.bridgeCustomerId = kycLinkStatus.customer_id
          }

          await user.save()
        } catch (error) {
          logger.error(`Failed to check Bridge KYC status for ${user.email}: ${error}`)
          // Continue even if Bridge KYC status check fails
        }
      }

      const token = this.generateToken(user._id.toString())
      return {
        message: "Login successful",
        token,
        user: {
          id: user._id,
          email: user.email,
          firstname: user.firstname,
          lastname: user.lastname,
          bridgeKycStatus: user.bridgeKycStatus,
          bridgeTosStatus: user.bridgeTosStatus,
          bridgeCustomerId: user.bridgeCustomerId,
        },
      }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  // Request password reset
  static forgotPassword = async (data: { email: string }) => {
    const { email } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        // For security reasons, still return success message even if user doesn't exist
        return { message: "If your email is registered, you will receive a password reset OTP." }
      }

      await EmailService.sendForgotPasswordEmail(email)
      return {
        message: "Password reset OTP sent to your email",
        email: user.email,
      }
    } catch (err: any) {
      console.error(err)
      throw new Error("Server error")
    }
  }

  // Verify reset password OTP
  static verifyResetPasswordOtp = async (data: { otp: number; email: string }) => {
    const { email, otp } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        throw new Error("Invalid email.")
      }

      const isValid = await OtpService.verifyOtp({ otp, email, type: OTPTYPE.forgotPassword })
      if (!isValid) {
        throw new Error("Invalid or expired OTP.")
      }

      // Generate a temporary token for password reset
      const resetToken = this.generateToken(user._id.toString())

      return {
        message: "OTP verified successfully",
        resetToken,
        email: user.email,
      }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  // Reset password with new password
  static resetPassword = async (data: { email: string; newPassword: string; resetToken: string }) => {
    const { email, newPassword, resetToken } = data

    try {
      // Verify the reset token
      let userId
      try {
        const decoded = jwt.verify(resetToken, process.env.JWT_SECRET || "secret") as { userId: string }
        userId = decoded.userId
      } catch (error) {
        throw new Error("Invalid or expired reset token.")
      }

      const user = await User.findOne({ email, _id: userId })
      if (!user) {
        throw new Error("Invalid email or token.")
      }

      const hashedPassword = await bcrypt.hash(newPassword, 12)
      user.password = hashedPassword
      await user.save()

      return { message: "Password successfully reset" }
    } catch (err: any) {
      console.error(err)
      throw new Error(err.message || "Server error")
    }
  }

  static async thirdPartyLogin(data: { token: string; type: AUTHTYPEWITHTHIRDPARTY }) {
    const { type, token } = data

    if (type !== AUTHTYPEWITHTHIRDPARTY.google) {
      throw new Error("Unsupported authentication type")
    }

    try {
      // Verify the token using Google's OAuth2 client
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: process.env.GOOGLE_CLIENT_ID,
      })

      const payload = ticket.getPayload()
      if (!payload || !payload.email) {
        throw new Error("Invalid token")
      }

      let user = await User.findOne({ email: payload.email })

      if (!user) {
        // Create a new user if they don't exist
        user = await User.create({
          email: payload.email,
          firstname: payload.given_name || "",
          lastname: payload.family_name || "",
          googleId: payload.sub,
          emailIsVerified: true, // Google accounts are pre-verified
          bridgeKycStatus: "not_started",
          bridgeTosStatus: "pending",
        })

        // Create a Bridge KYC link for the user
        try {
          const kycLink = await BridgeService.createKycLink({
            full_name: `${payload.given_name || ""} ${payload.family_name || ""}`,
            email: payload.email,
            type: "individual",
          })

          logger.info(`Generated Bridge KYC link for ${payload.email}: ${kycLink.kyc_link}`)

          // Store the KYC link ID in the user record
          user.bridgeKycLinkId = kycLink.id
          await user.save()
        } catch (error) {
          logger.error(`Failed to generate Bridge KYC link for ${payload.email}: ${error}`)
          // Continue even if Bridge KYC link generation fails
        }

        // Create wallet for new user
        try {
          await WalletService.createWallet({ userId: user._id })
          console.log(`Created wallet for Google user: ${user._id}`)
        } catch (error) {
          console.error(`Failed to create wallet for Google user: ${user._id}`, error)
          // Continue even if wallet creation fails
        }
      } else if (!user.googleId) {
        // Update existing user with Google ID if not set
        user.googleId = payload.sub
        await user.save()
      }

      // If the user has a Bridge KYC link ID, check the KYC status
      if (user.bridgeKycLinkId) {
        try {
          const kycLinkStatus = await BridgeService.getKycLinkStatus(user.bridgeKycLinkId)

          // Update the user's Bridge KYC status
          user.bridgeKycStatus = kycLinkStatus.kyc_status
          user.bridgeTosStatus = kycLinkStatus.tos_status

          // If the KYC is approved and a customer ID is available, store it
          if (kycLinkStatus.customer_id) {
            user.bridgeCustomerId = kycLinkStatus.customer_id
          }

          await user.save()
        } catch (error) {
          logger.error(`Failed to check Bridge KYC status for ${user.email}: ${error}`)
          // Continue even if Bridge KYC status check fails
        }
      }

      const authToken = this.generateToken(user._id.toString())

      return {
        message: "User authenticated",
        token: authToken,
        user: {
          id: user._id,
          email: user.email,
          firstname: user.firstname,
          lastname: user.lastname,
          bridgeKycStatus: user.bridgeKycStatus,
          bridgeTosStatus: user.bridgeTosStatus,
          bridgeCustomerId: user.bridgeCustomerId,
        },
      }
    } catch (error: any) {
      console.error("Error verifying token:", error)
      throw new Error(error.message || "Server error")
    }
  }

  static async resendOtp(data: { email: string; type: OTPTYPE }) {
    const { email, type } = data

    try {
      const user = await User.findOne({ email })
      if (!user) {
        // For security reasons, still return success message even if user doesn't exist
        return { message: "If your email is registered, you will receive an OTP." }
      }

      if (type === OTPTYPE.emailVerification) {
        await EmailService.sendVerificationEmail(email)
      } else if (type === OTPTYPE.forgotPassword) {
        await EmailService.sendForgotPasswordEmail(email)
      }

      return { message: "OTP sent successfully" }
    } catch (error: any) {
      console.error("Resend OTP error:", error)
      throw new Error(error.message || "Failed to resend OTP")
    }
  }

  /**
   * Check Bridge KYC status for a user
   *
   * @param userId - The user ID
   * @returns The updated user with Bridge KYC status
   */
  static async checkBridgeKycStatus(userId: string) {
    try {
      const user = await User.findById(userId)
      if (!user) {
        throw new Error("User not found")
      }

      // If the user has a Bridge KYC link ID, check the KYC status
      if (user.bridgeKycLinkId) {
        const kycLinkStatus = await BridgeService.getKycLinkStatus(user.bridgeKycLinkId)

        // Update the user's Bridge KYC status
        user.bridgeKycStatus = kycLinkStatus.kyc_status
        user.bridgeTosStatus = kycLinkStatus.tos_status

        // If the KYC is approved and a customer ID is available, store it
        if (kycLinkStatus.customer_id) {
          user.bridgeCustomerId = kycLinkStatus.customer_id
        }

        await user.save()
      } else if (user.bridgeCustomerId) {
        // If the user has a Bridge customer ID but no KYC link ID, get the customer details
        const customer = await BridgeService.getCustomer(user.bridgeCustomerId)

        // Update the user's Bridge KYC status
        if (customer.kyc_status) {
          user.bridgeKycStatus = customer.kyc_status
        }

        await user.save()
      }

      return user
    } catch (error: any) {
      logger.error(`Failed to check Bridge KYC status for user ${userId}: ${error.message}`)
      throw new Error(error.message || "Failed to check Bridge KYC status")
    }
  }

  /**
   * Create a Bridge KYC link for a business
   *
   * @param data - Business information
   * @returns The KYC link object
   */
  static async createBusinessKycLink(data: {
    businessName: string
    email: string
    userId: string
  }) {
    const { businessName, email, userId } = data

    try {
      const user = await User.findById(userId)
      if (!user) {
        throw new Error("User not found")
      }

      // Create a Bridge KYC link for the business
      const kycLink = await BridgeService.createKycLink({
        full_name: businessName,
        email,
        type: "business",
      })

      logger.info(`Generated Bridge KYC link for business ${businessName}: ${kycLink.kyc_link}`)

      // Store the KYC link ID in the user record
      user.bridgeKycLinkId = kycLink.id
      await user.save()

      return kycLink
    } catch (error: any) {
      logger.error(`Failed to create Bridge KYC link for business ${businessName}: ${error.message}`)
      throw new Error(error.message || "Failed to create Bridge KYC link for business")
    }
  }
}

