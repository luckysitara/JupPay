import passport from "passport"
import { Strategy as GoogleStrategy } from "passport-google-oauth20"
import { User } from "../../models/User"
import { WalletService } from "../../wallet/service"
import mongoose from "mongoose"

passport.use(
  new GoogleStrategy(
    {
      clientID: process.env.GOOGLE_CLIENT_ID || "",
      clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
      callbackURL: process.env.GOOGLE_CALLBACK_URL || "",
    },
    async (accessToken, refreshToken, profile, done) => {
      const session = await mongoose.startSession()
      session.startTransaction()
      try {
        let user = await User.findOne({ googleId: profile.id })

        if (!user) {
          const [user_] = await User.create(
            [
              {
                email: profile.emails ? profile.emails[0].value : "",
                googleId: profile.id,
                emailIsVerified: true,
              },
            ],
            { session },
          )

          user = user_
        }

        const usdcWallet = await WalletService.createWallet({ userId: user._id.toString() })
        if (usdcWallet) {
          // Store the wallet ID instead of the whole wallet object
          user.usdcWallet = usdcWallet._id.toString()
        } else {
          throw new Error("Failed to create wallet")
        }
        await user.save()
        await session.commitTransaction()
        session.endSession()
        done(null, user)
      } catch (err) {
        console.error(err)
        await session.abortTransaction()
        session.endSession()
        done(err, false)
      }
    },
  ),
)

