import express from "express"
import { AuthController } from "./controller"
import { authenticate } from "../middleware/auth.middleware"

export class Authroute {
  router: express.Router
  private authController: AuthController

  constructor() {
    this.router = express.Router()
    this.authController = new AuthController()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    // New authentication flow routes
    this.router.post("/create-account", this.authController.createAccount.bind(this.authController))
    this.router.post("/verify-email", this.authController.verifyEmail.bind(this.authController))
    this.router.post("/update-profile", this.authController.updateProfile.bind(this.authController))
    this.router.post("/set-password", this.authController.setPassword.bind(this.authController))

    // Login routes
    this.router.post("/login", this.authController.login.bind(this.authController))
    this.router.post("/google", this.authController.thirdPartyLogin.bind(this.authController))

    // Password reset flow
    this.router.post("/forgot-password", this.authController.forgotPassword.bind(this.authController))
    this.router.post("/verify-reset-otp", this.authController.verifyResetPasswordOtp.bind(this.authController))
    this.router.post("/reset-password", this.authController.resetPassword.bind(this.authController))

    // Utility routes
    this.router.post("/resend-otp", this.authController.resendOtp.bind(this.authController))

    // Add Bridge info update route
    this.router.put("/update-bridge-info", authenticate, this.authController.updateBridgeInfo.bind(this.authController))

    // Check Bridge KYC status
    this.router.get(
      "/check-kyc-status",
      authenticate,
      this.authController.checkBridgeKycStatus.bind(this.authController),
    )

    // Create business KYC link
    this.router.post(
      "/create-business-kyc-link",
      authenticate,
      this.authController.createBusinessKycLink.bind(this.authController),
    )
  }
}

