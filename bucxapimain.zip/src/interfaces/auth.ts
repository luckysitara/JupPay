export enum AUTHTYPEWITHTHIRDPARTY {
  google = "google",
}

