import { BridgeService } from "../services/bridge.service"

async function initBridgeCustomer() {
  try {
    // Example data - replace with your actual data
    const customerData = {
      type: "individual", // or 'business'
      firstName: "John",
      lastName: "Doe",
      email: "john.doe@example.com",
      phone: "+15551234567",
      dateOfBirth: "1990-01-01",
      address: {
        line1: "123 Main St",
        city: "Anytown",
        state: "CA",
        postalCode: "91234",
        country: "US",
      },
      // Add other required fields based on your BridgeService implementation
    }

    const externalAccountData = {
      accountNumber: "1234567890",
      routingNumber: "021000021",
      accountType: "checking", // or 'savings'
      // Add other required fields
    }

    const liquidationData = {
      accountNumber: "9876543210",
      routingNumber: "121000248",
      accountType: "checking",
      // Add other required fields
    }

    // 1. Generate Terms of Service Link
    const tosResponse = await BridgeService.generateTosLink()
    console.log("Terms of Service Link:", tosResponse)

    // 2. Create Customer
    const customer =
      customerData.type === "individual"
        ? await BridgeService.createIndividualCustomer(customerData)
        : await BridgeService.createBusinessCustomer(customerData)
    console.log("Customer created:", customer)

    // 3. Create External Account
    const externalAccount = await BridgeService.addExternalAccount(customer.id, externalAccountData)
    console.log("External Account created:", externalAccount)

    // 4. Create Liquidation Address (Virtual Account)
    // Use createVirtualAccount instead as createLiquidationAddress doesn't exist
    const liquidationAddress = await BridgeService.createVirtualAccount(customer.id, liquidationData)
    console.log("Liquidation Address (Virtual Account) created:", liquidationAddress)

    console.log("Bridge Customer initialization complete.")
  } catch (error) {
    console.error("Error initializing Bridge Customer:", error)
  }
}

initBridgeCustomer()

