import dotenv from "dotenv"
import { BridgeService } from "../services/bridge.service"
import logger from "../utils/logger"

// Load environment variables
dotenv.config()

async function initBridgeCustomer() {
  try {
    logger.info("Starting Bridge customer initialization")

    // Step 1: Generate a Terms of Service link
    logger.info("Generating Terms of Service link")
    // Use the correct method name
    const tosResponse = await BridgeService.generateTosLink()

    logger.info(`ToS link generated: ${tosResponse.url}`)
    logger.info("Please visit this URL to accept the Terms of Service")
    logger.info("After accepting, you will receive a signed_agreement_id")

    // Prompt for signed_agreement_id (in a real script, you'd use readline or similar)
    const signedAgreementId = process.env.BRIDGE_SIGNED_AGREEMENT_ID || "mock_signed_agreement_id"

    if (!signedAgreementId) {
      throw new Error("No signed_agreement_id provided")
    }

    // Step 2: Create a customer
    logger.info("Creating Bridge customer")

    const customerData = {
      type: "individual",
      first_name: "John",
      last_name: "Doe",
      email: "john.doe@example.com",
      phone: "+15555555555",
      address: {
        street_line_1: "123 Main St",
        city: "San Francisco",
        subdivision: "CA",
        postal_code: "94105",
        country: "USA",
      },
      birth_date: "1990-01-01",
      signed_agreement_id: signedAgreementId,
      identifying_information: [
        {
          type: "ssn",
          value: "123-45-6789",
          issuing_country: "USA",
        },
      ],
    }

    // Use the correct method name
    const customer = await BridgeService.createIndividualCustomer(customerData)

    logger.info(`Customer created with ID: ${customer.id}`)

    // Step 3: Add an external account
    logger.info("Adding external account")

    const externalAccountData = {
      bank_name: "Test Bank",
      account_number: "123456789",
      routing_number: "987654321",
      account_owner_name: "John Doe",
      active: true,
      address: {
        street_line_1: "123 Main St",
        city: "San Francisco",
        state: "CA",
        postal_code: "94105",
        country: "USA",
      },
    }

    // Use the correct method name
    const externalAccount = await BridgeService.addExternalAccount(customer.id, externalAccountData)

    logger.info(`External account added with ID: ${externalAccount.id}`)

    // Step 4: Create a virtual account instead of liquidation address
    logger.info("Creating virtual account")

    const virtualAccountData = {
      source: {
        currency: "usd",
      },
      destination: {
        payment_rail: "solana",
        currency: "usdc",
        address: "solana_address_here",
      },
      developer_fee_percent: "1.0",
    }

    // Use the correct method
    const virtualAccount = await BridgeService.createVirtualAccount(customer.id, virtualAccountData)

    logger.info(`Virtual account created with ID: ${virtualAccount.id}`)

    logger.info("Bridge customer initialization completed successfully")
    return {
      customerId: customer.id,
      externalAccountId: externalAccount.id,
      virtualAccountId: virtualAccount.id,
    }
  } catch (error: any) {
    logger.error(`Bridge customer initialization failed: ${error.message}`)
    throw error
  }
}

// Run the script if executed directly
if (require.main === module) {
  initBridgeCustomer()
    .then((result) => {
      console.log("Success:", result)
      process.exit(0)
    })
    .catch((error) => {
      console.error("Error:", error)
      process.exit(1)
    })
}

export default initBridgeCustomer

