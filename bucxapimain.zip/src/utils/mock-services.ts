/**
 * Mock Services Utility
 * 
 * Provides mock implementations of external services for testing and development.
 * This allows developers to work without actual API credentials during development.
 */

import logger from "./logger"

/**
 * Mock Bridge API requests for testing and development
 *
 * @param url - The API endpoint URL
 * @param method - The HTTP method
 * @param data - The request data (for POST, PUT, etc.)
 * @returns Mock response data
 */
export async function mockBridgeRequest(url: string, method: string, data?: any): Promise<any> {
  logger.info(`MOCK: ${method} ${url}`)
  if (data) {
    logger.debug(`MOCK: Request data: ${JSON.stringify(data)}`)
  }

  // Extract the endpoint from the URL
  const endpoint = url.split("/").slice(-2).join("/")

  // Generate a mock ID
  const mockId = `mock_${Date.now()}_${Math.floor(Math.random() * 1000)}`

  // Handle different endpoints
  if (url.includes("/customers/tos_links")) {
    return {
      id: mockId,
      url: `https://mock-bridge-api.example.com/tos/${mockId}`,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    }
  }

  if (url.includes("/kyc_links")) {
    return {
      id: mockId,
      kyc_link: `https://mock-bridge-api.example.com/kyc/${mockId}`,
      tos_link: `https://mock-bridge-api.example.com/tos/${mockId}`,
      expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    }
  }

  if (url.includes("/customers") && method.toUpperCase() === "POST") {
    return {
      id: mockId,
      type: data?.type || "individual",
      email: data?.email || "mock@example.com",
      kyc_status: "not_started",
      tos_status: "pending",
      created_at: new Date().toISOString(),
    }
  }

  if (url.includes("/virtual_accounts") && method.toUpperCase() === "POST") {
    return {
      id: mockId,
      status: "active",
      customer_id: url.split("/")[url.split("/").indexOf("customers") + 1],
      source_deposit_instructions: {
        currency: data?.source?.currency || "usd",
        bank_beneficiary_name: "Mock Bank",
        bank_name: "Mock Bank NA",
        bank_address: "123 Mock St, Mock City, MC 12345",
        bank_routing_number: "123456789",
        bank_account_number: "987654321",
        payment_rails: ["ach", "wire"],
        payment_rail: "ach",
      },
      destination: {
        currency: data?.destination?.currency || "usdc",
        payment_rail: data?.destination?.payment_rail || "solana",
        address: data?.destination?.address || `mock_address_${mockId}`,
      },
      developer_fee_percent: "0.5",
      created_at: new Date().toISOString(),
    }
  }

  if (url.includes("/transfers") && method.toUpperCase() === "POST") {
    return {
      id: mockId,
      status: "pending",
      amount: data?.amount || "100.00",
      on_behalf_of: data?.on_behalf_of || "mock_customer",
      source: data?.source || {
        payment_rail: "ach",
        currency: "usd",
      },
      destination: data?.destination || {
        payment_rail: "solana",
        currency: "usdc",
        address: `mock_address_${mockId}`,
      },
      created_at: new Date().toISOString(),
    }
  }

  // Default mock response
  return {
    id: mockId,
    status: "success",
    message: "Mock response",
    data: [],
    created_at: new Date().toISOString(),
  }
}

