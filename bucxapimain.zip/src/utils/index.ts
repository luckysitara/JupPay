import nodemailer from "nodemailer"

export const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
})

export const sessionCheck = async (modelFunc: any, args: any, tx: any) => {
  if (tx) {
    const [d] = await modelFunc(args, tx)
    return d
  } else {
    const d = await modelFunc(...args)

    return d
  }
}

