import axios from "axios"
import logger from "./logger"

/**
 * Debug helper to test Bridge API connectivity directly
 * This can be used to verify if the API key is valid
 */
export async function testBridgeApiConnection(apiKey: string, baseUrl?: string) {
  try {
    logger.info("Testing Bridge API connection...")

    // Determine base URL based on API key prefix if not provided
    if (!baseUrl) {
      if (apiKey.startsWith("sk-test-")) {
        baseUrl = "https://api.sandbox.bridge.xyz/v0"
        logger.info("Detected sandbox API key, using sandbox URL")
      } else {
        baseUrl = "https://api.bridge.xyz/v0"
        logger.info("Using production URL")
      }
    }

    // Generate a unique idempotency key
    const idempotencyKey = `test-${Date.now()}`

    logger.info(`Using base URL: ${baseUrl}`)

    // Make a simple request to the TOS endpoint
    const response = await axios({
      method: "POST",
      url: `${baseUrl}/customers/tos_links`,
      headers: {
        "Content-Type": "application/json",
        "Api-Key": apiKey,
        "Idempotency-Key": idempotencyKey,
      },
      validateStatus: null, // Don't throw on any status code
    })

    logger.info(`Bridge API test response status: ${response.status}`)

    if (response.status >= 200 && response.status < 300) {
      logger.info("Bridge API connection successful!")
      return {
        success: true,
        status: response.status,
        data: response.data,
        environment: apiKey.startsWith("sk-test-") ? "sandbox" : "production",
        baseUrl,
      }
    } else {
      logger.error(`Bridge API connection failed with status ${response.status}`)
      logger.error(`Response data: ${JSON.stringify(response.data)}`)
      return {
        success: false,
        status: response.status,
        error: response.data,
        environment: apiKey.startsWith("sk-test-") ? "sandbox" : "production",
        baseUrl,
      }
    }
  } catch (error: any) {
    logger.error(`Bridge API connection test error: ${error.message}`)
    if (error.response) {
      logger.error(`Response data: ${JSON.stringify(error.response.data)}`)
      return {
        success: false,
        status: error.response.status,
        error: error.response.data,
        environment: apiKey.startsWith("sk-test-") ? "sandbox" : "production",
        baseUrl,
      }
    }
    return {
      success: false,
      error: error.message,
      environment: apiKey.startsWith("sk-test-") ? "sandbox" : "production",
      baseUrl,
    }
  }
}

