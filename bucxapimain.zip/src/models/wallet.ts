import mongoose, { Schema, type Document } from "mongoose"

export interface IWallet extends Document {
  user: mongoose.Types.ObjectId
  solWallet?: mongoose.Types.ObjectId
  usdWallet?: mongoose.Types.ObjectId
  nairaWallet?: string
  seedPhrase: string
  createdAt: Date
  updatedAt: Date
}

export interface ISolWallet extends Document {
  wid: string
  address: string
  user: mongoose.Types.ObjectId
  createdAt: Date
  updatedAt: Date
}

export interface IUsdWallet extends Document {
  wid: string
  user: mongoose.Types.ObjectId
  status: string
  customer_id: string
  source_deposit_instructions: {
    currency: string
    bank_beneficiary_name?: string
    bank_name?: string
    bank_address?: string
    bank_routing_number?: string
    bank_account_number?: string
    payment_rails?: string[]
    payment_rail?: string
  }
  destination: {
    currency: string
    payment_rail: string
    address: string
  }
  developer_fee_percent: string
  createdAt: Date
  updatedAt: Date
}

const WalletSchema = new Schema<IWallet>(
  {
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },
    solWallet: { type: Schema.Types.ObjectId, ref: "solWallet" },
    usdWallet: { type: Schema.Types.ObjectId, ref: "usdWallet" },
    nairaWallet: { type: String },
    seedPhrase: { type: String, required: true },
  },
  { timestamps: true },
)

const SolWalletSchema = new Schema<ISolWallet>(
  {
    wid: { type: String, required: true },
    address: { type: String, required: true },
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true },
)

const UsdWalletSchema = new Schema<IUsdWallet>(
  {
    wid: { type: String, required: true },
    user: { type: Schema.Types.ObjectId, ref: "User", required: true },
    status: { type: String, required: true },
    customer_id: { type: String, required: true },
    source_deposit_instructions: {
      currency: { type: String },
      bank_beneficiary_name: { type: String },
      bank_name: { type: String },
      bank_address: { type: String },
      bank_routing_number: { type: String },
      bank_account_number: { type: String },
      payment_rails: [String],
      payment_rail: { type: String },
    },
    destination: {
      currency: { type: String },
      payment_rail: { type: String },
      address: { type: String },
    },
    developer_fee_percent: { type: String },
  },
  { timestamps: true },
)

export const Wallet = mongoose.model<IWallet>("Wallet", WalletSchema)
export const solWallet = mongoose.model<ISolWallet>("solWallet", SolWalletSchema)
export const usdWallet = mongoose.model<IUsdWallet>("usdWallet", UsdWalletSchema)

