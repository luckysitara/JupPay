/**
 * User Model
 *
 * Defines the schema and interface for user data in the database.
 * Contains user authentication information and Bridge API integration data.
 */

import mongoose, { type Document, Schema } from "mongoose"

export interface IUser extends Document {
  _id: mongoose.Types.ObjectId
  email: string
  firstname: string
  lastname: string
  password: string
  country?: string
  accountType?: string
  phone?: string
  googleId?: string
  resetPasswordToken?: string
  resetPasswordExpires?: Date
  emailIsVerified: boolean

  // Bridge API integration fields
  bridgeCustomerId?: string
  bridgeKycStatus?: string
  bridgeTosStatus?: string
  bridgeKycLinkId?: string
  bridgeEndorsements?: string[]
  bridgeSignedAgreementId?: string
  bridgeVirtualAccountId?: string
}

const userSchema = new Schema<IUser>(
  {
    // Basic user information
    email: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      lowercase: true,
    },
    firstname: {
      type: String,
      default: "",
    },
    lastname: {
      type: String,
      default: "",
    },
    password: {
      type: String,
    },
    country: {
      type: String,
    },
    accountType: {
      type: String,
    },
    phone: {
      type: String,
    },

    // Authentication fields
    googleId: {
      type: String,
    },
    emailIsVerified: {
      type: Boolean,
      default: false,
    },
    resetPasswordToken: {
      type: String,
    },
    resetPasswordExpires: {
      type: Date,
    },

    // Bridge API integration fields
    bridgeCustomerId: {
      type: String,
    },
    bridgeKycStatus: {
      type: String,
      enum: ["not_started", "incomplete", "under_review", "approved", "rejected"],
    },
    bridgeTosStatus: {
      type: String,
      enum: ["pending", "approved"],
    },
    bridgeKycLinkId: {
      type: String,
    },
    bridgeEndorsements: [
      {
        type: String,
      },
    ],
    bridgeSignedAgreementId: {
      type: String,
    },
    bridgeVirtualAccountId: {
      type: String,
    },
  },
  {
    timestamps: true, // Automatically add createdAt and updatedAt fields
  },
)

// Create indexes for better query performance
userSchema.index({ email: 1 }, { unique: true })
userSchema.index({ googleId: 1 }, { sparse: true })
userSchema.index({ bridgeCustomerId: 1 }, { sparse: true })

export const User = mongoose.model<IUser>("User", userSchema)

