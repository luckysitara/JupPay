/**
 * OTP Model
 * 
 * Defines the schema and interface for one-time passwords (OTPs) used for
 * email verification and password reset.
 */

import mongoose, { type Document, Schema } from "mongoose"

/**
 * OTP Document Interface
 * Represents a one-time password record in the database
 */
export interface IOtp extends Document {
  otp: string;              // The OTP code
  email: string;            // Email address associated with the OTP
  type: string;             // Type of OTP (e.g., emailVerification, forgotPassword)
  genratedCount: number;    // Number of times OTP has been generated for this email/type
  expiresAt: Date;          // Expiration timestamp
}

const OtpSchema = new Schema<IOtp>(
  {
    email: { 
      type: String, 
      required: true 
    },
    otp: { 
      type: String, 
      required: true 
    },
    type: { 
      type: String, 
      required: true 
    },
    genratedCount: { 
      type: Number, 
      default: 1 
    },
    expiresAt: { 
      type: Date, 
      required: true 
    },
  },
  { 
    timestamps: true // Automatically add createdAt and updatedAt fields
  }
)

// Set default expiration time if not provided
OtpSchema.pre<IOtp>("save", function (next) {
  if (!this.expiresAt) {
    this.expiresAt = new Date(Date.now() + 10 * 60 * 1000) // 10 minutes
  }
  next()
})

// Create indexes for better query performance
OtpSchema.index({ email: 1, type: 1 })
OtpSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 }) // TTL index for automatic deletion

export const Otp = mongoose.model<IOtp>("Otp", OtpSchema)

