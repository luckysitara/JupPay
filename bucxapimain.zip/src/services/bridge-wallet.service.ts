import axios from "axios"
import { config } from "../config"
import { v4 as uuidv4 } from "uuid"
import logger from "../utils/logger"
import { mockBridgeRequest } from "../utils/mock-services"
import { User } from "../models/user"
import mongoose, { type Types } from "mongoose"

/**
 * Bridge Wallet Service
 *
 * Handles all interactions with the Bridge API for wallet management
 * and transfers.
 */
export class BridgeWalletService {
  /**
   * Generate a unique idempotency key
   */
  private static generateIdempotencyKey(): string {
    return `${Date.now()}-${uuidv4()}`
  }

  /**
   * Create headers for Bridge API requests
   */
  private static getHeaders(idempotencyKey?: string): Record<string, string> {
    const apiKey = process.env.BRIDGE_API_KEY || config.bridgeApiKey

    if (!apiKey || apiKey.trim() === "") {
      logger.error("Bridge API key is missing or empty")
      throw new Error("Bridge API key is not configured")
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "Api-Key": apiKey.trim(),
    }

    if (idempotencyKey) {
      headers["Idempotency-Key"] = idempotencyKey
    } else if (idempotencyKey !== null) {
      headers["Idempotency-Key"] = this.generateIdempotencyKey()
    }

    return headers
  }

  /**
   * Make a request to the Bridge API
   */
  private static async makeRequest(url: string, method: string, data?: any, idempotencyKey?: string) {
    try {
      // Use mock service if configured
      if (process.env.USE_MOCKS === "true") {
        logger.info(`Using mock Bridge API for ${method} ${url}`)
        return await mockBridgeRequest(url, method, data)
      }

      const apiKey = process.env.BRIDGE_API_KEY || config.bridgeApiKey
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl

      if (!apiKey || apiKey.trim() === "") {
        throw new Error("Bridge API key is not configured")
      }

      logger.info(`Making Bridge API request: ${method} ${url}`)

      const headers =
        method.toUpperCase() === "GET"
          ? this.getHeaders(null) // No idempotency key for GET requests
          : this.getHeaders(idempotencyKey)

      if (data) {
        logger.debug(`Request data: ${JSON.stringify(data)}`)
      }

      const response = await axios({
        method,
        url,
        data,
        headers,
        validateStatus: null, // Don't throw on any status code
      })

      logger.debug(`Response status: ${response.status}`)
      logger.debug(`Response data: ${JSON.stringify(response.data)}`)

      if (response.status >= 400) {
        logger.error(`Bridge API error: ${JSON.stringify(response.data)}`)
        let errorMessage = "Bridge API error"

        if (response.data) {
          if (response.data.message) {
            errorMessage = response.data.message
          } else if (response.data.error) {
            errorMessage = response.data.error
          }
        }

        throw new Error(`Bridge API error: ${errorMessage}`)
      }

      return response.data
    } catch (error: any) {
      if (error.response) {
        logger.error(`Bridge API error response: ${JSON.stringify(error.response.data)}`)
        throw new Error(`Bridge API error (${error.response.status}): ${error.response.data.message || error.message}`)
      } else if (error.request) {
        logger.error(`Bridge API no response received: ${error.message}`)
        throw new Error(`Bridge API connection error: ${error.message}`)
      } else {
        logger.error(`Bridge API request setup error: ${error.message}`)
        throw error
      }
    }
  }

  /**
   * Create a wallet for a customer
   *
   * @param customerId - Bridge customer ID
   * @param chain - Blockchain chain (e.g., "solana")
   * @returns The created wallet object
   */
  static async createWallet(customerId: string, chain = "solana") {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/wallets`
      const method = "POST"
      const data = { chain }

      logger.info(`Creating ${chain} wallet for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Wallet created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create wallet: ${error}`)
      throw error
    }
  }

  /**
   * Get wallet balance
   *
   * @param customerId - Bridge customer ID
   * @param walletId - Bridge wallet ID
   * @returns The wallet with balance information
   */
  static async getWalletBalance(customerId: string, walletId: string) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/wallets/${walletId}`
      const method = "GET"

      logger.info(`Getting wallet balance for wallet ${walletId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Wallet balance retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get wallet balance: ${error}`)
      throw error
    }
  }

  /**
   * Get total balance of all wallets
   *
   * @returns Array of balances by currency and chain
   */
  static async getTotalWalletsBalance() {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/wallets/total_balances`
      const method = "GET"

      logger.info(`Getting total balance of all wallets`)
      const response = await this.makeRequest(url, method)

      logger.info(`Total wallet balance retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get total wallet balance: ${error}`)
      throw error
    }
  }

  /**
   * Get all wallets for a customer
   *
   * @param customerId - Bridge customer ID
   * @returns List of wallets
   */
  static async getCustomerWallets(customerId: string) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/wallets`
      const method = "GET"

      logger.info(`Getting wallets for customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Retrieved ${response.data?.length || 0} wallets`)
      return response
    } catch (error) {
      logger.error(`Failed to get customer wallets: ${error}`)
      throw error
    }
  }

  /**
   * Get all wallets for the developer
   *
   * @returns List of all wallets
   */
  static async getAllWallets() {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/wallets`
      const method = "GET"

      logger.info(`Getting all wallets`)
      const response = await this.makeRequest(url, method)

      logger.info(`Retrieved ${response.data?.length || 0} wallets`)
      return response
    } catch (error) {
      logger.error(`Failed to get all wallets: ${error}`)
      throw error
    }
  }

  /**
   * Create a virtual account to wallet transfer
   *
   * @param customerId - Bridge customer ID
   * @param walletId - Bridge wallet ID
   * @param sourceCurrency - Source currency (e.g., "usd")
   * @param destinationCurrency - Destination currency (e.g., "usdb")
   * @returns The created virtual account
   */
  static async createVirtualAccountToWallet(
    customerId: string,
    walletId: string,
    sourceCurrency = "usd",
    destinationCurrency = "usdb",
  ) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/virtual_accounts`
      const method = "POST"

      const data = {
        source: {
          currency: sourceCurrency,
        },
        destination: {
          currency: destinationCurrency,
          payment_rail: "solana",
          bridge_wallet_id: walletId,
        },
      }

      logger.info(`Creating virtual account to wallet transfer for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Virtual account created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create virtual account to wallet: ${error}`)
      throw error
    }
  }

  /**
   * Create a transfer to a wallet
   *
   * @param customerId - Bridge customer ID
   * @param walletId - Bridge wallet ID
   * @param amount - Amount to transfer
   * @param sourceCurrency - Source currency (e.g., "usd")
   * @param sourcePaymentRail - Source payment rail (e.g., "wire")
   * @param destinationCurrency - Destination currency (e.g., "usdb")
   * @param developerFee - Optional developer fee
   * @returns The created transfer
   */
  static async createTransferToWallet(
    customerId: string,
    walletId: string,
    amount: string,
    sourceCurrency = "usd",
    sourcePaymentRail = "wire",
    destinationCurrency = "usdb",
    developerFee = "0.0",
  ) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/transfers`
      const method = "POST"

      const data = {
        amount,
        on_behalf_of: customerId,
        developer_fee: developerFee,
        source: {
          payment_rail: sourcePaymentRail,
          currency: sourceCurrency,
        },
        destination: {
          payment_rail: "solana",
          currency: destinationCurrency,
          bridge_wallet_id: walletId,
        },
      }

      logger.info(`Creating transfer to wallet for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Transfer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create transfer to wallet: ${error}`)
      throw error
    }
  }

  /**
   * Create a transfer from a wallet
   *
   * @param customerId - Bridge customer ID
   * @param walletId - Bridge wallet ID
   * @param amount - Amount to transfer
   * @param destinationAddress - Destination blockchain address
   * @param sourceCurrency - Source currency (e.g., "usdb")
   * @param destinationCurrency - Destination currency (e.g., "usdc")
   * @param destinationPaymentRail - Destination payment rail (e.g., "ethereum")
   * @param developerFee - Optional developer fee
   * @returns The created transfer
   */
  static async createTransferFromWallet(
    customerId: string,
    walletId: string,
    amount: string,
    destinationAddress: string,
    sourceCurrency = "usdb",
    destinationCurrency = "usdc",
    destinationPaymentRail = "ethereum",
    developerFee = "0.0",
  ) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/transfers`
      const method = "POST"

      const data = {
        amount,
        on_behalf_of: customerId,
        developer_fee: developerFee,
        source: {
          payment_rail: "bridge_wallet",
          currency: sourceCurrency,
          bridge_wallet_id: walletId,
        },
        destination: {
          payment_rail: destinationPaymentRail,
          currency: destinationCurrency,
          to_address: destinationAddress,
        },
      }

      logger.info(`Creating transfer from wallet for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Transfer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create transfer from wallet: ${error}`)
      throw error
    }
  }

  /**
   * Create a transfer between Bridge wallets
   *
   * @param customerId - Bridge customer ID
   * @param sourceWalletId - Source Bridge wallet ID
   * @param destinationWalletId - Destination Bridge wallet ID
   * @param amount - Amount to transfer
   * @param currency - Currency (e.g., "usdb")
   * @param developerFee - Optional developer fee
   * @returns The created transfer
   */
  static async createWalletToWalletTransfer(
    customerId: string,
    sourceWalletId: string,
    destinationWalletId: string,
    amount: string,
    currency = "usdb",
    developerFee = "0.0",
  ) {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/transfers`
      const method = "POST"

      const data = {
        amount,
        on_behalf_of: customerId,
        developer_fee: developerFee,
        source: {
          payment_rail: "bridge_wallet",
          currency,
          bridge_wallet_id: sourceWalletId,
        },
        destination: {
          payment_rail: "solana",
          currency,
          bridge_wallet_id: destinationWalletId,
        },
      }

      logger.info(`Creating wallet to wallet transfer for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Transfer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create wallet to wallet transfer: ${error}`)
      throw error
    }
  }

  /**
   * Create a wallet for a user and store the wallet ID in the user document
   *
   * @param userId - MongoDB user ID
   * @returns The created wallet
   */
  static async createWalletForUser(userId: string | Types.ObjectId) {
    const session = await mongoose.startSession()
    session.startTransaction()

    try {
      // Get the user
      const user = await User.findById(userId).session(session)
      if (!user) {
        throw new Error("User not found")
      }

      // Check if the user has a Bridge customer ID
      if (!user.bridgeCustomerId) {
        throw new Error("User does not have a Bridge customer ID. Please onboard the user first.")
      }

      // Create a wallet
      const wallet = await this.createWallet(user.bridgeCustomerId)

      // Update the user with the wallet ID
      user.bridgeWalletId = wallet.id
      await user.save({ session })

      await session.commitTransaction()
      session.endSession()

      return wallet
    } catch (error) {
      await session.abortTransaction()
      session.endSession()
      throw error
    }
  }

  /**
   * Get a user's wallet balance
   *
   * @param userId - MongoDB user ID
   * @returns The wallet with balance information
   */
  static async getUserWalletBalance(userId: string | Types.ObjectId) {
    try {
      // Get the user
      const user = await User.findById(userId)
      if (!user) {
        throw new Error("User not found")
      }

      // Check if the user has a Bridge customer ID and wallet ID
      if (!user.bridgeCustomerId) {
        throw new Error("User does not have a Bridge customer ID")
      }

      if (!user.bridgeWalletId) {
        throw new Error("User does not have a Bridge wallet ID")
      }

      // Get the wallet balance
      return await this.getWalletBalance(user.bridgeCustomerId, user.bridgeWalletId)
    } catch (error) {
      throw error
    }
  }
}

