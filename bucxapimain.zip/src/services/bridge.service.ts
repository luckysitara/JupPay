/**
 * Bridge Service
 *
 * Handles all interactions with the Bridge API for customer onboarding,
 * external account management, and money transfers.
 */

import axios from "axios"
import { config } from "../config"
import { v4 as uuidv4 } from "uuid"
import logger from "../utils/logger"
import { mockBridgeRequest } from "../utils/mock-services"

export class BridgeService {
  /**
   * Generate a unique idempotency key for Bridge API requests
   * @returns A unique idempotency key
   */
  private static generateIdempotencyKey(): string {
    return `${Date.now()}-${uuidv4()}`
  }

  /**
   * Create headers for Bridge API requests
   * @param idempotencyKey - Optional idempotency key
   * @returns Headers object for API requests
   */
  private static getHeaders(idempotencyKey?: string): Record<string, string> {
    // Use environment variables directly to ensure we're using the correct values
    const apiKey = process.env.BRIDGE_API_KEY || config.bridgeApiKey

    // Ensure API key is available and properly formatted
    if (!apiKey || apiKey.trim() === "") {
      logger.error("Bridge API key is missing or empty")
      logger.error(`Environment BRIDGE_API_KEY: ${process.env.BRIDGE_API_KEY || "Not set"}`)
      logger.error(`Config bridgeApiKey: ${config.bridgeApiKey || "Not set"}`)
      throw new Error("Bridge API key is not configured")
    }

    const headers: Record<string, string> = {
      "Content-Type": "application/json",
      "Api-Key": apiKey.trim(),
    }

    // Add idempotency key
    if (idempotencyKey) {
      headers["Idempotency-Key"] = idempotencyKey
    } else {
      headers["Idempotency-Key"] = this.generateIdempotencyKey()
    }

    return headers
  }

  /**
   * Make a request to the Bridge API
   * @param url - API endpoint URL
   * @param method - HTTP method (GET, POST, PUT, etc.)
   * @param data - Request data (for POST, PUT, etc.)
   * @param idempotencyKey - Optional idempotency key
   * @returns Response data from the API
   */
  private static async makeRequest(url: string, method: string, data?: any, idempotencyKey?: string) {
    try {
      // Use mock service if configured
      if (process.env.USE_MOCKS === "true") {
        logger.info(`Using mock Bridge API for ${method} ${url}`)
        return await mockBridgeRequest(url, method, data)
      }

      // Use environment variables directly to ensure we're using the correct values
      const apiKey = process.env.BRIDGE_API_KEY || config.bridgeApiKey
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl

      // Check if Bridge API key is configured
      if (!apiKey || apiKey.trim() === "") {
        throw new Error("Bridge API key is not configured")
      }

      // Log request details (without sensitive data)
      logger.info(`Making Bridge API request: ${method} ${url}`)
      logger.info(`Using Bridge API key: ${apiKey.substring(0, 8)}...`)
      logger.info(`Using Bridge Base URL: ${baseUrl}`)

      const headers =
        method.toUpperCase() === "GET"
          ? {
              "Content-Type": "application/json",
              "Api-Key": apiKey.trim(),
            }
          : this.getHeaders(idempotencyKey)

      // Log headers for debugging (excluding the actual API key)
      logger.debug(
        `Request headers: ${JSON.stringify({
          ...headers,
          "Api-Key":
            headers["Api-Key"].substring(0, 8) + "..." + headers["Api-Key"].substring(headers["Api-Key"].length - 4),
        })}`,
      )

      if (data) {
        logger.debug(`Request data: ${JSON.stringify(data)}`)
      }

      const response = await axios({
        method,
        url,
        data,
        headers,
        validateStatus: null, // Don't throw on any status code
      })

      // Log response for debugging
      logger.debug(`Response status: ${response.status}`)
      logger.debug(`Response data: ${JSON.stringify(response.data)}`)

      // Handle error status codes
      if (response.status >= 400) {
        logger.error(`Bridge API error: ${JSON.stringify(response.data)}`)

        // Enhanced error message with more details
        let errorMessage = "Bridge API error"

        if (response.data) {
          if (response.data.message) {
            errorMessage = response.data.message
          } else if (response.data.error) {
            errorMessage = response.data.error
          } else if (typeof response.data === "string") {
            errorMessage = response.data
          }
        } else {
          errorMessage = response.statusText || "Unknown error"
        }

        // Add detailed error information if available
        let errorDetails = ""
        if (response.data && response.data.errors) {
          if (Array.isArray(response.data.errors)) {
            errorDetails = response.data.errors
              .map((e: any) => (e.field ? `${e.field}: ${e.message}` : e.message || e))
              .join(", ")
          } else {
            errorDetails = JSON.stringify(response.data.errors)
          }
        }

        throw new Error(`Bridge API error: ${errorMessage}${errorDetails ? " - Details: " + errorDetails : ""}`)
      }

      return response.data
    } catch (error: any) {
      if (error.response) {
        logger.error(`Bridge API error response: ${JSON.stringify(error.response.data)}`)

        // Enhanced error message with more details from response
        let errorMessage = "Bridge API error"

        if (error.response.data) {
          if (error.response.data.message) {
            errorMessage = error.response.data.message
          } else if (error.response.data.error) {
            errorMessage = error.response.data.error
          } else if (typeof error.response.data === "string") {
            errorMessage = error.response.data
          }
        } else {
          errorMessage = error.response.statusText || "Unknown error"
        }

        // Add detailed error information if available
        let errorDetails = ""
        if (error.response.data && error.response.data.errors) {
          if (Array.isArray(error.response.data.errors)) {
            errorDetails = error.response.data.errors
              .map((e: any) => (e.field ? `${e.field}: ${e.message}` : e.message || e))
              .join(", ")
          } else {
            errorDetails = JSON.stringify(error.response.data.errors)
          }
        }

        // Add status code to error message
        errorMessage = `Bridge API error (${error.response.status}): ${errorMessage}`

        throw new Error(`${errorMessage}${errorDetails ? " - Details: " + errorDetails : ""}`)
      } else if (error.request) {
        logger.error(`Bridge API no response received: ${error.message}`)
        throw new Error(`Bridge API connection error: ${error.message}`)
      } else {
        logger.error(`Bridge API request setup error: ${error.message}`)
        throw error
      }
    }
  }

  /**
   * Generate a Terms of Service link for a customer
   *
   * @param redirectUri - Optional redirect URI after TOS acceptance
   * @returns The TOS URL and session token
   */
  static async generateTosLink(redirectUri?: string): Promise<{ url: string }> {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/tos_links`
      const method = "POST"
      const data = redirectUri ? { redirect_uri: redirectUri } : undefined

      logger.info(`Generating TOS link${redirectUri ? " with redirect to " + redirectUri : ""}`)
      logger.info(`Using URL: ${url}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`TOS link generated successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to generate TOS link: ${error}`)
      throw error
    }
  }

  /**
   * Create a KYC link for a new customer
   *
   * @param data - Customer information (full_name, email, type)
   * @param endorsements - Optional endorsements array
   * @param redirectUri - Optional redirect URI after KYC completion
   * @returns The KYC link object
   */
  static async createKycLink(
    data: {
      full_name: string
      email: string
      type: "individual" | "business"
    },
    endorsements?: string[],
    redirectUri?: string,
  ): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/kyc_links`
      const method = "POST"

      // Prepare request data
      const requestData: any = {
        full_name: data.full_name,
        email: data.email,
        type: data.type,
      }

      // Add endorsements if provided
      if (endorsements && endorsements.length > 0) {
        requestData.endorsements = endorsements
      }

      // Add redirect URI if provided
      if (redirectUri) {
        requestData.redirect_uri = redirectUri
      }

      logger.info(`Creating KYC link for ${data.email} (${data.type})`)
      const response = await this.makeRequest(url, method, requestData)

      logger.info(`KYC link created successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to create KYC link: ${error}`)
      throw error
    }
  }

  /**
   * Get KYC link status
   *
   * @param kycLinkId - The KYC link ID
   * @returns The KYC link status
   */
  static async getKycLinkStatus(kycLinkId: string): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/kyc_links/${kycLinkId}`
      const method = "GET"

      logger.info(`Getting KYC link status for ${kycLinkId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`KYC link status retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get KYC link status: ${error}`)
      throw error
    }
  }

  /**
   * Get KYC link for an existing customer
   *
   * @param customerId - The Bridge customer ID
   * @param endorsement - Optional endorsement type
   * @returns The KYC link URL
   */
  static async getKycLinkForExistingCustomer(customerId: string, endorsement?: string): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      let url = `${baseUrl}/customers/${customerId}/kyc_link`

      // Add endorsement if provided
      if (endorsement) {
        url += `?endorsement=${endorsement}`
      }

      const method = "GET"

      logger.info(`Getting KYC link for existing customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`KYC link for existing customer retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get KYC link for existing customer: ${error}`)
      throw error
    }
  }

  /**
   * Get ToS acceptance link for an existing customer
   *
   * @param customerId - The Bridge customer ID
   * @returns The ToS acceptance link URL
   */
  static async getTosAcceptanceLinkForExistingCustomer(customerId: string): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/tos_acceptance_link`
      const method = "GET"

      logger.info(`Getting ToS acceptance link for existing customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`ToS acceptance link for existing customer retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get ToS acceptance link for existing customer: ${error}`)
      throw error
    }
  }

  /**
   * Create an individual customer in Bridge
   *
   * @param customerData - Individual customer information
   * @returns The created customer object
   */
  static async createIndividualCustomer(customerData: any) {
    try {
      // Ensure the type is set to individual
      customerData.type = "individual"

      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers`
      const method = "POST"

      // Generate a unique idempotency key for this request
      const idempotencyKey = this.generateIdempotencyKey()

      logger.info(`Creating individual customer for ${customerData.email}`)
      logger.info(`Using idempotency key: ${idempotencyKey}`)

      // Log the request data for debugging
      logger.debug(`Request data: ${JSON.stringify(customerData)}`)

      const response = await this.makeRequest(url, method, customerData, idempotencyKey)

      logger.info(`Individual customer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create individual customer: ${error}`)
      throw error
    }
  }

  /**
   * Create a business customer in Bridge
   *
   * @param customerData - Business customer information
   * @returns The created business customer object
   */
  static async createBusinessCustomer(customerData: any) {
    try {
      // Ensure the type is set to business
      customerData.type = "business"

      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers`
      const method = "POST"

      // Generate a unique idempotency key for this request
      const idempotencyKey = this.generateIdempotencyKey()

      logger.info(`Creating business customer for ${customerData.email}`)
      logger.info(`Using idempotency key: ${idempotencyKey}`)

      // Log the request data for debugging
      logger.debug(`Request data: ${JSON.stringify(customerData)}`)

      const response = await this.makeRequest(url, method, customerData, idempotencyKey)

      logger.info(`Business customer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create business customer: ${error}`)
      throw error
    }
  }

  /**
   * Get customer details from Bridge
   *
   * @param customerId - The Bridge customer ID
   * @returns The customer details
   */
  static async getCustomer(customerId: string): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}`
      const method = "GET"

      logger.info(`Getting customer details for ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Customer details retrieved successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to get customer details: ${error}`)
      throw error
    }
  }

  /**
   * Update customer information in Bridge
   *
   * @param customerId - The Bridge customer ID
   * @param customerData - Updated customer information
   * @returns The updated customer object
   */
  static async updateCustomer(customerId: string, customerData: any): Promise<any> {
    try {
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}`
      const method = "PUT"

      // Generate a unique idempotency key for this request
      const idempotencyKey = this.generateIdempotencyKey()

      logger.info(`Updating customer ${customerId}`)
      logger.info(`Using idempotency key: ${idempotencyKey}`)

      const response = await this.makeRequest(url, method, customerData, idempotencyKey)

      logger.info(`Customer updated successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to update customer: ${error}`)
      throw error
    }
  }

  /**
   * Add an external account for a customer via direct API
   *
   * @param customerId - Bridge customer ID
   * @param accountData - External account information
   * @returns The created external account object
   */
  static async addExternalAccount(
    customerId: string,
    accountData: {
      bank_name: string
      account_number: string
      routing_number: string
      account_name?: string
      account_owner_name: string
      active: boolean
      address: {
        street_line_1: string
        street_line_2?: string
        city: string
        state: string
        postal_code: string
        country: string
      }
    },
  ) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/external_accounts`
      const method = "POST"

      // Add required 'type' field
      const data = {
        ...accountData,
        type: "raw",
      }

      logger.info(`Adding external account for customer ${customerId}`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`External account added successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to add external account: ${error}`)
      throw error
    }
  }

  /**
   * Create a Plaid link request for a customer
   *
   * @param customerId - Bridge customer ID
   * @returns Plaid link token and callback URL
   */
  static async createPlaidLinkRequest(customerId: string) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/plaid_link_requests`
      const method = "POST"

      logger.info(`Creating Plaid link request for customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Plaid link request created successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to create Plaid link request: ${error}`)
      throw error
    }
  }

  /**
   * Exchange a Plaid public token
   *
   * @param linkToken - Plaid link token
   * @param publicToken - Plaid public token
   * @returns Success message
   */
  static async exchangePlaidPublicToken(linkToken: string, publicToken: string) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/plaid_exchange_public_token/${linkToken}`
      const method = "POST"
      const data = { public_token: publicToken }

      logger.info(`Exchanging Plaid public token`)
      const response = await this.makeRequest(url, method, data)

      logger.info(`Plaid public token exchanged successfully`)
      return response
    } catch (error) {
      logger.error(`Failed to exchange Plaid public token: ${error}`)
      throw error
    }
  }

  /**
   * Get external accounts for a customer
   *
   * @param customerId - Bridge customer ID
   * @returns List of external accounts
   */
  static async getExternalAccounts(customerId: string) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/external_accounts`
      const method = "GET"

      logger.info(`Getting external accounts for customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Retrieved ${response.data?.length || 0} external accounts`)
      return response
    } catch (error) {
      logger.error(`Failed to get external accounts: ${error}`)
      throw error
    }
  }

  /**
   * Create a transfer
   *
   * @param transferData - Transfer information
   * @returns The created transfer object
   */
  static async createTransfer(transferData: {
    amount: string
    on_behalf_of: string
    source: {
      payment_rail: string
      currency: string
      from_address?: string
    }
    destination: {
      payment_rail: string
      currency: string
      external_account_id?: string
      to_address?: string
    }
  }) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/transfers`
      const method = "POST"

      logger.info(`Creating transfer of ${transferData.amount} for customer ${transferData.on_behalf_of}`)
      const response = await this.makeRequest(url, method, transferData)

      logger.info(`Transfer created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create transfer: ${error}`)
      throw error
    }
  }

  /**
   * Create a virtual account
   *
   * @param customerId - Bridge customer ID
   * @param accountData - Virtual account information
   * @returns The created virtual account object
   */
  static async createVirtualAccount(
    customerId: string,
    accountData: {
      source: {
        currency: string
      }
      destination: {
        payment_rail: string
        currency: string
        address: string
      }
      developer_fee_percent?: string
    },
  ) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/virtual_accounts`
      const method = "POST"

      logger.info(`Creating virtual account for customer ${customerId}`)
      const response = await this.makeRequest(url, method, accountData)

      logger.info(`Virtual account created successfully with ID: ${response.id}`)
      return response
    } catch (error) {
      logger.error(`Failed to create virtual account: ${error}`)
      throw error
    }
  }

  /**
   * Get virtual accounts for a customer
   *
   * @param customerId - Bridge customer ID
   * @returns List of virtual accounts
   */
  static async getVirtualAccounts(customerId: string) {
    try {
      // Use environment variables directly to ensure we're using the correct values
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/virtual_accounts`
      const method = "GET"

      logger.info(`Getting virtual accounts for customer ${customerId}`)
      const response = await this.makeRequest(url, method)

      logger.info(`Retrieved ${response.data?.length || 0} virtual accounts`)
      return response
    } catch (error) {
      logger.error(`Failed to get virtual accounts: ${error}`)
      throw error
    }
  }
}

