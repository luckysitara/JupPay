import { BridgeService } from "./bridge.service"
import { useMocks } from "../utils"

export class WalletService {
  private static evervault = useMocks ? null : null // Remove Evervault initialization for now

  public static async createWallet(
    userId: string,
    bridgeCustomerId: string,
  ): Promise<{ address: string; walletId: string; accountId: string }> {
    // Mock the Solana wallet creation since the method doesn't exist
    const address = "solana_address_mock"
    const walletId = "wallet_" + Date.now()

    const virtualAccountData = {
      source: {
        currency: "usd",
      },
      destination: {
        payment_rail: "solana",
        currency: "usdc",
        address: address,
      },
      developer_fee_percent: "1.0",
    }
    const response = await BridgeService.createVirtualAccount(bridgeCustomerId, virtualAccountData)
    const accountId = response.id

    return { address, walletId, accountId }
  }
}

