import express from "express"
import { config } from "../config"
import { testBridgeApiConnection } from "../utils/debug-helper"
import logger from "../utils/logger"
import axios from "axios"

export class DebugRoute {
  router: express.Router

  constructor() {
    this.router = express.Router()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    // Only enable in development mode
    if (config.nodeEnv === "development" || config.debug) {
      this.router.get("/test-bridge-connection", this.testBridgeConnection)
      this.router.get("/config", this.getConfig)
      this.router.get("/env", this.getEnv) // Add this line
      this.router.get("/virtual-accounts/:customerId", this.debugVirtualAccounts)
    }
  }

  private async testBridgeConnection(req: express.Request, res: express.Response) {
    try {
      // Get API key from query param or use the one from config
      const apiKey = (req.query.apiKey as string) || config.bridgeApiKey

      if (!apiKey) {
        return res.status(400).json({
          success: false,
          message:
            "No API key provided. Please provide an API key via query parameter or set BRIDGE_API_KEY environment variable.",
        })
      }

      // Get base URL from query param or determine based on API key
      let baseUrl = req.query.baseUrl as string
      if (!baseUrl) {
        if (apiKey.startsWith("sk-test-")) {
          baseUrl = "https://api.sandbox.bridge.xyz/v0"
        } else {
          baseUrl = "https://api.bridge.xyz/v0"
        }
      }

      logger.info(
        `Testing Bridge API connection with key: ${apiKey.substring(0, 8)}...${apiKey.substring(apiKey.length - 4)}`,
      )
      logger.info(`Using base URL: ${baseUrl}`)

      const result = await testBridgeApiConnection(apiKey, baseUrl)

      return res.json(result)
    } catch (error: any) {
      logger.error(`Error testing Bridge API connection: ${error.message}`)
      return res.status(500).json({
        success: false,
        message: error.message,
      })
    }
  }

  private getConfig(req: express.Request, res: express.Response) {
    // Return a safe subset of configuration (no secrets)
    const safeConfig = {
      environment: config.nodeEnv,
      bridgeEnvironment: config.bridgeEnvironment,
      bridgeBaseUrl: config.bridgeBaseUrl,
      bridgeApiKeyConfigured: !!config.bridgeApiKey,
      bridgeApiKeyPrefix: config.bridgeApiKey ? config.bridgeApiKey.substring(0, 8) : null,
      bridgeApiKeySuffix: config.bridgeApiKey ? config.bridgeApiKey.substring(config.bridgeApiKey.length - 4) : null,
      mongodbUri: config.mongodbUri
        ? config.mongodbUri.includes("mongodb://")
          ? "Valid MongoDB URI"
          : "Invalid MongoDB URI"
        : "Not set",
      debug: config.debug,
      mockMode: process.env.USE_MOCKS === "true",
      port: config.port,
      host: config.host,
      corsOrigins: config.corsOrigins,
    }

    return res.json(safeConfig)
  }

  // Add this method
  private getEnv(req: express.Request, res: express.Response) {
    // Return a safe subset of environment variables (no secrets)
    const safeEnv = {
      NODE_ENV: process.env.NODE_ENV,
      PORT: process.env.PORT,
      HOST: process.env.HOST,
      MONGODB_URI: process.env.MONGODB_URI ? "Set" : "Not set",
      MONGODB_URL: process.env.MONGODB_URL ? "Set" : "Not set",
      BRIDGE_API_KEY: process.env.BRIDGE_API_KEY
        ? `${process.env.BRIDGE_API_KEY.substring(0, 8)}...${process.env.BRIDGE_API_KEY.substring(process.env.BRIDGE_API_KEY.length - 4)}`
        : "Not set",
      BRIDGE_BASE_URL: process.env.BRIDGE_BASE_URL,
      GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID ? "Set" : "Not set",
      EMAIL_USER: process.env.EMAIL_USER ? "Set" : "Not set",
      CORS_ORIGINS: process.env.CORS_ORIGINS,
      USE_MOCKS: process.env.USE_MOCKS,
    }

    return res.json(safeEnv)
  }

  private async debugVirtualAccounts(req: express.Request, res: express.Response) {
    try {
      const { customerId } = req.params

      if (!customerId) {
        return res.status(400).json({
          success: false,
          message: "Customer ID is required",
        })
      }

      // Force mock mode for debugging
      process.env.USE_MOCKS = "true"

      // Use the Bridge service directly
      const baseUrl = process.env.BRIDGE_BASE_URL || config.bridgeBaseUrl
      const url = `${baseUrl}/customers/${customerId}/virtual_accounts`

      // Make a direct request without Idempotency-Key
      const apiKey = process.env.BRIDGE_API_KEY || config.bridgeApiKey

      if (!apiKey) {
        return res.status(400).json({
          success: false,
          message: "Bridge API key is not configured",
        })
      }

      const headers = {
        "Content-Type": "application/json",
        "Api-Key": apiKey,
      }

      logger.info(`Making debug request to ${url}`)

      try {
        const response = await axios({
          method: "GET",
          url,
          headers,
          validateStatus: null,
        })

        logger.info(`Debug response status: ${response.status}`)

        return res.json({
          success: true,
          status: response.status,
          data: response.data,
        })
      } catch (error: any) {
        if (error.response) {
          return res.status(error.response.status).json({
            success: false,
            status: error.response.status,
            data: error.response.data,
          })
        } else {
          return res.status(500).json({
            success: false,
            message: error.message,
          })
        }
      } finally {
        // Reset mock mode
        process.env.USE_MOCKS = "false"
      }
    } catch (error: any) {
      logger.error(`Debug virtual accounts error: ${error.message}`)
      return res.status(500).json({
        success: false,
        message: error.message || "Failed to debug virtual accounts",
      })
    }
  }
}

