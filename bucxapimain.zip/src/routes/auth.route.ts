// Fix the import statement
import { AuthController } from "../auth/controller"

