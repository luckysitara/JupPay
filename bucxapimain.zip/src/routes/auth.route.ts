import express from "express"
import { AuthController } from "../auth/controller"
import { validateRequest } from "../middleware/validateRequest"
import { registerSchema, loginSchema } from "../zod.schema"

const router = express.Router()
const authController = new AuthController()

router.post("/register", validateRequest(registerSchema), authController.register)

router.post("/login", validateRequest(loginSchema), authController.login)

router.get("/logout", authController.logout)

router.get("/refresh", authController.refresh)

export default router

