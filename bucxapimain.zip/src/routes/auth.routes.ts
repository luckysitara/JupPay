import express from "express"
import AuthController from "../controllers/auth.controller"

export class AuthRoutes {
  router: express.Router

  constructor() {
    this.router = express.Router()
    this.initializeRoutes()
  }

  private initializeRoutes() {
    this.router.post("/register", AuthController.register)
    this.router.post("/login", AuthController.login)
    this.router.post("/forgot-password", AuthController.forgotPassword)
    this.router.post("/reset-password", AuthController.resetPassword)
    this.router.post("/verify-email", AuthController.verifyEmail)
    this.router.post("/google", AuthController.googleAuth)
  }
}

export default new AuthRoutes().router

