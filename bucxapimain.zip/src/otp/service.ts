/**
 * OTP Service
 *
 * Handles the generation and verification of one-time passwords (OTPs)
 * used for email verification and password reset.
 */

import type { OTPTYPE } from "../constant"
import { Otp } from "../models/otp"
import logger from "../utils/logger"

export class OtpService {
  /**
   * Generate a new OTP for a given email and type
   *
   * @param data - Object containing email and OTP type
   * @returns The generated OTP
   */
  static async generateOtp(data: { email: string; type: OTPTYPE }) {
    const { email, type } = data

    try {
      // Generate a 6-digit OTP
      const otp = Math.floor(100000 + Math.random() * 900000).toString()

      // Set expiration time (10 minutes from now)
      const expiresAt = new Date()
      expiresAt.setMinutes(expiresAt.getMinutes() + 10)

      // Check if an OTP already exists for this email and type
      const existingOtp = await Otp.findOne({ email, type })

      if (existingOtp) {
        // Update existing OTP
        existingOtp.otp = otp
        existingOtp.expiresAt = expiresAt
        existingOtp.genratedCount = (existingOtp.genratedCount || 0) + 1
        await existingOtp.save()

        logger.info(`Updated OTP for ${email} (type: ${type}), generation count: ${existingOtp.genratedCount}`)
        return otp
      } else {
        // Create new OTP
        await Otp.create({
          email,
          type,
          otp,
          expiresAt,
          genratedCount: 1,
        })

        logger.info(`Created new OTP for ${email} (type: ${type})`)
        return otp
      }
    } catch (error) {
      logger.error(`Error generating OTP: ${error}`)
      throw new Error("Failed to generate OTP")
    }
  }

  /**
   * Verify an OTP for a given email and type
   *
   * @param data - Object containing OTP, email, and type
   * @returns Boolean indicating if the OTP is valid
   */
  static async verifyOtp(data: { otp: number; email: string; type: OTPTYPE }): Promise<boolean> {
    const { otp, email, type } = data

    try {
      const now = new Date()

      // Find a valid OTP that matches the criteria and hasn't expired
      const otpRecord = await Otp.findOne({
        email,
        otp: otp.toString(),
        type,
        expiresAt: { $gt: now },
      })

      if (!otpRecord) {
        logger.warn(`Invalid or expired OTP attempt for ${email} (type: ${type})`)
        return false
      }

      // Delete the OTP after successful verification to prevent reuse
      await Otp.deleteOne({ _id: otpRecord._id })

      logger.info(`Successfully verified OTP for ${email} (type: ${type})`)
      return true
    } catch (error) {
      logger.error(`Error verifying OTP: ${error}`)
      throw new Error("Failed to verify OTP")
    }
  }
}

