import { AuthService } from "../services/auth.service"
import jwt from "jsonwebtoken"
import { config } from "../config"

// Mock dependencies
jest.mock("@supabase/supabase-js", () => ({
  createClient: jest.fn(() => ({
    from: jest.fn(() => ({
      select: jest.fn(() => ({
        eq: jest.fn(() => ({
          single: jest.fn(() => ({
            data: null,
            error: { code: "PGRST116" },
          })),
        })),
      })),
      insert: jest.fn(() => ({
        select: jest.fn(() => ({
          single: jest.fn(() => ({
            data: { id: "test-id", email: "test@example.com" },
            error: null,
          })),
        })),
      })),
    })),
  })),
}))

jest.mock("bcryptjs", () => ({
  hash: jest.fn(() => Promise.resolve("hashed-password")),
  compare: jest.fn(() => Promise.resolve(true)),
}))

jest.mock("../services/email.service", () => ({
  EmailService: {
    sendVerificationEmail: jest.fn(() => Promise.resolve("1234")),
    sendForgotPasswordEmail: jest.fn(() => Promise.resolve("1234")),
    sendWelcomeEmail: jest.fn(() => Promise.resolve()),
  },
}))

describe("AuthService", () => {
  describe("generateToken", () => {
    it("should generate a JWT token", () => {
      // Mock jwt.sign
      const signSpy = jest.spyOn(jwt, "sign")
      signSpy.mockImplementation(() => "test-token")

      const token = AuthService.generateToken("test-user-id")

      expect(signSpy).toHaveBeenCalledWith({ userId: "test-user-id" }, config.jwtSecret, {
        expiresIn: config.jwtExpiresIn,
      })
      expect(token).toBe("test-token")

      // Restore original implementation
      signSpy.mockRestore()
    })
  })

  // Add more tests as needed
})

