#!/bin/bash

# Exit on error
set -e

echo "Running BUX API server directly..."

# Compile TypeScript on the fly and run
npx ts-node src/app.ts

