# BUX API

BUX API is a backend service for the Borderless Banking Experience platform. It provides authentication, Bridge API integration for virtual accounts, and more.

## Features

- User authentication (email/password and Google OAuth)
- Email verification with OTP
- Password reset functionality
- Bridge API integration for KYC/AML
- Virtual account management

## Prerequisites

- Node.js (v16+)
- npm or yarn
- MongoDB (v4.4+)
- Gmail account (for sending emails)
- Bridge API credentials

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/bux-api.git
   cd bux-api

