import express from "express"
import mongoose from "mongoose"

const app = express()
app.use(express.json())

// Define Mongoose Schemas
const UserSchema = new mongoose.Schema({
  name: String,
  balance: Number,
})

const TransactionSchema = new mongoose.Schema({
  senderId: mongoose.Schema.Types.ObjectId,
  receiverId: mongoose.Schema.Types.ObjectId,
  amount: Number,
  status: String,
})

const User = mongoose.model("User", UserSchema)
const Transaction = mongoose.model("Transaction", TransactionSchema)

// Route to Transfer Money Using Transactions
app.post("/transfer", async (req, res) => {
  const { senderId, receiverId, amount } = req.body

  const session = await mongoose.startSession()
  session.startTransaction()

  try {
    // Step 1: Deduct amount from sender
    const sender = await User.findById(senderId).session(session)
    if (!sender || sender.balance < amount) {
      throw new Error("Insufficient funds")
    }
    sender.balance -= amount
    await sender.save({ session })

    // Step 2: Add amount to receiver
    const receiver = await User.findById(receiverId).session(session)
    if (!receiver) {
      throw new Error("Receiver not found")
    }
    receiver.balance += amount
    await receiver.save({ session })

    // Step 3: Record Transaction
    await Transaction.create([{ senderId, receiverId, amount, status: "success" }], { session })

    // Commit the transaction
    await session.commitTransaction()
    session.endSession()

    res.json({ message: "Transaction successful" })
  } catch (error) {
    // Rollback transaction on failure
    await session.abortTransaction()
    session.endSession()

    res.status(500).json({ message: error.message })
  }
})

// Connect to MongoDB
mongoose
  .connect("mongodb://127.0.0.1:27017/transactionsDB")
  .then(() => console.log("MongoDB Connected"))
  .catch((err) => console.log(err))

app.listen(3000, () => console.log("Server running on port 3000"))

