#!/bin/bash

# Exit on error
set -e

echo "Building simplified BUX API backend..."

# Create logs directory
mkdir -p logs

# Create dist directory
mkdir -p dist

# Compile only the simplified app.ts file
echo "Compiling TypeScript..."
npx tsc src/app.ts src/utils/logger.ts src/config.ts --outDir dist --esModuleInterop true --skipLibCheck true

echo "✅ Build completed successfully!"
echo "You can now run the backend with: node dist/app.js"

