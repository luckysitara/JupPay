"use client"

import app from "../src/app"

export default function SyntheticV0PageForDeployment() {
  return <app />
}