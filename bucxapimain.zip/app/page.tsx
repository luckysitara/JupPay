"use client"

import  from "../src/components/ExternalAccountForm"

export default function SyntheticV0PageForDeployment() {
  return < />
}