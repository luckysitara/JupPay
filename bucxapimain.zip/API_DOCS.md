# BUX API Documentation

This document provides detailed information about the BUX API endpoints, request/response formats, and authentication requirements.

## Authentication

Most endpoints require authentication using a JWT token. Include the token in the Authorization header:

