#!/bin/bash
chmod +x cleanup.sh
chmod +x build.sh

