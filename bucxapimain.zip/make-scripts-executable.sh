#!/bin/bash

# Make all scripts executable
chmod +x *.sh

echo "All scripts are now executable"

