#!/bin/bash
chmod +x start.sh

