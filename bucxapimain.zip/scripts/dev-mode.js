/**
 * Script to enable development mode with mocks
 * Run with: node scripts/dev-mode.js
 */

const fs = require("fs")
const path = require("path")
const dotenv = require("dotenv")

// Load current .env file
dotenv.config()

// Path to .env file
const envPath = path.resolve(process.cwd(), ".env")

// Read current .env content
let envContent = ""
try {
  envContent = fs.readFileSync(envPath, "utf8")
} catch (error) {
  console.error("Error reading .env file:", error)
  process.exit(1)
}

// Check if USE_MOCKS is already set
if (envContent.includes("USE_MOCKS=")) {
  // Update existing USE_MOCKS value
  envContent = envContent.replace(/USE_MOCKS=.*/g, "USE_MOCKS=true")
} else {
  // Add USE_MOCKS to .env
  envContent += "\n# Development mode with mocks\nUSE_MOCKS=true\n"
}

// Write updated .env file
try {
  fs.writeFileSync(envPath, envContent)
  console.log("✅ Development mode with mocks enabled!")
  console.log("You can now run the application without real API credentials.")
  console.log("Run npm run dev to start the server.")
} catch (error) {
  console.error("Error writing to .env file:", error)
  process.exit(1)
}

