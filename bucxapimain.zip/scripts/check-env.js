/**
 * Script to check if all required environment variables are set
 * Run with: node scripts/check-env.js
 */

require("dotenv").config()

const requiredEnvVars = [
  "PORT",
  "JWT_SECRET",
  "SUPABASE_URL",
  "SUPABASE_ANON_KEY",
  "SUPABASE_SERVICE_ROLE_KEY",
  "EMAIL_USER",
  "EMAIL_PASS",
  "EMAIL_FROM",
  "BRIDGE_API_KEY",
  "EVERVAULT_KEY",
  "EVERVAULT_APP_ID",
  "GOOGLE_CLIENT_ID",
  "GOOGLE_CLIENT_SECRET",
]

const missingEnvVars = requiredEnvVars.filter((envVar) => !process.env[envVar])

if (missingEnvVars.length === 0) {
  console.log("✅ All required environment variables are set!")
} else {
  console.error("❌ Missing required environment variables:")
  missingEnvVars.forEach((envVar) => console.error(`- ${envVar}`))
  console.error("\nPlease check your .env file and ensure all required variables are set.")
}

// Print current environment variables (without sensitive values)
console.log("\nCurrent environment variables:")
console.log("- PORT:", process.env.PORT)
console.log("- HOST:", process.env.HOST)
console.log("- NODE_ENV:", process.env.NODE_ENV)
console.log("- JWT_SECRET:", process.env.JWT_SECRET ? "✓ Set" : "✗ Not set")
console.log("- SUPABASE_URL:", process.env.SUPABASE_URL ? "✓ Set" : "✗ Not set")
console.log("- SUPABASE_ANON_KEY:", process.env.SUPABASE_ANON_KEY ? "✓ Set" : "✗ Not set")
console.log("- SUPABASE_SERVICE_ROLE_KEY:", process.env.SUPABASE_SERVICE_ROLE_KEY ? "✓ Set" : "✗ Not set")
console.log("- EMAIL_USER:", process.env.EMAIL_USER ? "✓ Set" : "✗ Not set")
console.log("- EMAIL_PASS:", process.env.EMAIL_PASS ? "✓ Set" : "✗ Not set")
console.log("- EMAIL_SERVICE:", process.env.EMAIL_SERVICE)
console.log("- EMAIL_FROM:", process.env.EMAIL_FROM ? "✓ Set" : "✗ Not set")
console.log("- BRIDGE_API_KEY:", process.env.BRIDGE_API_KEY ? "✓ Set" : "✗ Not set")
console.log("- BRIDGE_BASE_URL:", process.env.BRIDGE_BASE_URL)
console.log("- EVERVAULT_KEY:", process.env.EVERVAULT_KEY ? "✓ Set" : "✗ Not set")
console.log("- EVERVAULT_APP_ID:", process.env.EVERVAULT_APP_ID ? "✓ Set" : "✗ Not set")
console.log("- GOOGLE_CLIENT_ID:", process.env.GOOGLE_CLIENT_ID ? "✓ Set" : "✗ Not set")
console.log("- GOOGLE_CLIENT_SECRET:", process.env.GOOGLE_CLIENT_SECRET ? "✓ Set" : "✗ Not set")
console.log("- GOOGLE_CALLBACK_URL:", process.env.GOOGLE_CALLBACK_URL)
console.log("- LOG_LEVEL:", process.env.LOG_LEVEL)
console.log("- CORS_ORIGINS:", process.env.CORS_ORIGINS)
console.log("- BLOCKCHAIN_NODE_URL:", process.env.BLOCKCHAIN_NODE_URL)

