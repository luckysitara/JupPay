#!/bin/bash

# Script to set up Bridge sandbox environment
# Usage: source ./setup-bridge-sandbox.sh [API_KEY]

# Set API key from argument or prompt user
API_KEY=${1}

if [ -z "$API_KEY" ]; then
  read -p "Enter your Bridge sandbox API key (starts with sk-test-): " API_KEY
fi

if [[ ! "$API_KEY" == sk-test-* ]]; then
  echo "❌ Error: API key must start with 'sk-test-' for sandbox environment"
  return 1 2>/dev/null || exit 1
fi

# Set environment variables
export BRIDGE_API_KEY="$API_KEY"
export BRIDGE_BASE_URL="https://api.sandbox.bridge.xyz/v0"
export USE_MOCKS="false"

echo "✅ Bridge sandbox environment configured:"
echo "API Key: ${API_KEY:0:8}...${API_KEY: -4}"
echo "Base URL: $BRIDGE_BASE_URL"
echo "Mock Mode: Disabled"
echo ""
echo "To test the connection, run: ./scripts/test-bridge-connection.sh"

