#!/bin/bash

# BUX API Test Script
# This script tests the main endpoints of the BUX API

# Configuration
API_URL="http://localhost:5002"
TOKEN=""
USER_ID=""
EMAIL="test@example.com"
PASSWORD="Test123!"

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to make API requests
function call_api {
  local method=$1
  local endpoint=$2
  local data=$3
  local auth=$4

  echo -e "${BLUE}Testing: ${method} ${endpoint}${NC}"
  
  if [ "$auth" = "true" ] && [ ! -z "$TOKEN" ]; then
    auth_header="Authorization: Bearer ${TOKEN}"
  else
    auth_header=""
  fi

  if [ -z "$data" ]; then
    response=$(curl -s -X ${method} \
      -H "Content-Type: application/json" \
      ${auth_header:+-H "$auth_header"} \
      ${API_URL}${endpoint})
  else
    response=$(curl -s -X ${method} \
      -H "Content-Type: application/json" \
      ${auth_header:+-H "$auth_header"} \
      -d "${data}" \
      ${API_URL}${endpoint})
  fi

  echo $response | jq . || echo $response
  echo ""
  
  # Return the response for further processing
  echo $response
}

# Test health endpoint
echo -e "${BLUE}Testing API Health...${NC}"
health_response=$(call_api "GET" "/health")
if [[ $health_response == *"healthy"* ]]; then
  echo -e "${GREEN}✅ API is healthy${NC}"
else
  echo -e "${RED}❌ API health check failed${NC}"
  exit 1
fi

# Test registration flow
echo -e "\n${BLUE}Testing Registration Flow...${NC}"

# Step 1: Create account
echo -e "\n${BLUE}Step 1: Create Account${NC}"
create_account_response=$(call_api "POST" "/api/auth/create-account" "{\"email\":\"${EMAIL}\"}")
if [[ $create_account_response == *"Account created"* ]]; then
  echo -e "${GREEN}✅ Account created successfully${NC}"
  TOKEN=$(echo $create_account_response | jq -r '.token')
  USER_ID=$(echo $create_account_response | jq -r '.userId')
else
  echo -e "${RED}❌ Account creation failed${NC}"
fi

# Step 2: Verify email (mock OTP)
echo -e "\n${BLUE}Step 2: Verify Email${NC}"
echo -e "${BLUE}Note: In a real scenario, you would get the OTP from your email${NC}"
echo -e "${BLUE}Using mock OTP: 123456${NC}"
verify_email_response=$(call_api "POST" "/api/auth/verify-email" "{\"email\":\"${EMAIL}\",\"otp\":123456}")
if [[ $verify_email_response == *"Email verified"* ]]; then
  echo -e "${GREEN}✅ Email verified successfully${NC}"
  TOKEN=$(echo $verify_email_response | jq -r '.token')
else
  echo -e "${RED}❌ Email verification failed${NC}"
fi

# Step 3: Update profile
echo -e "\n${BLUE}Step 3: Update Profile${NC}"
update_profile_response=$(call_api "POST" "/api/auth/update-profile" "{\"userId\":\"${USER_ID}\",\"firstname\":\"Test\",\"lastname\":\"User\",\"country\":\"USA\",\"accountType\":\"individual\",\"phone\":\"+1234567890\"}")
if [[ $update_profile_response == *"Profile updated"* ]]; then
  echo -e "${GREEN}✅ Profile updated successfully${NC}"
  TOKEN=$(echo $update_profile_response | jq -r '.token')
else
  echo -e "${RED}❌ Profile update failed${NC}"
fi

# Step 4: Set password
echo -e "\n${BLUE}Step 4: Set Password${NC}"
set_password_response=$(call_api "POST" "/api/auth/set-password" "{\"userId\":\"${USER_ID}\",\"password\":\"${PASSWORD}\",\"confirmPassword\":\"${PASSWORD}\"}")
if [[ $set_password_response == *"Password set successfully"* ]]; then
  echo -e "${GREEN}✅ Password set successfully${NC}"
  TOKEN=$(echo $set_password_response | jq -r '.token')
else
  echo -e "${RED}❌ Setting password failed${NC}"
fi

# Test login
echo -e "\n${BLUE}Testing Login...${NC}"
login_response=$(call_api "POST" "/api/auth/login" "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}")
if [[ $login_response == *"Login successful"* ]]; then
  echo -e "${GREEN}✅ Login successful${NC}"
  TOKEN=$(echo $login_response | jq -r '.token')
else
  echo -e "${RED}❌ Login failed${NC}"
fi

# Test Bridge API integration
echo -e "\n${BLUE}Testing Bridge API Integration...${NC}"

# Test generating ToS link
echo -e "\n${BLUE}Generating ToS Link...${NC}"
tos_response=$(call_api "POST" "/api/bridge/tos" "{}" "true")
if [[ $tos_response == *"url"* ]]; then
  echo -e "${GREEN}✅ ToS link generated successfully${NC}"
else
  echo -e "${RED}❌ ToS link generation failed${NC}"
fi

# Test checking KYC status
echo -e "\n${BLUE}Checking KYC Status...${NC}"
kyc_status_response=$(call_api "GET" "/api/auth/check-kyc-status" "" "true")
if [[ $kyc_status_response == *"bridgeKycStatus"* ]]; then
  echo -e "${GREEN}✅ KYC status checked successfully${NC}"
else
  echo -e "${RED}❌ KYC status check failed${NC}"
fi

echo -e "\n${GREEN}API Testing Completed${NC}"

