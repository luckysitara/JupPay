#!/bin/bash

# Exit on error
set -e

echo "Setting up BUX API backend..."

# Make all scripts executable
chmod +x *.sh

# Remove node_modules and package-lock.json
rm -rf node_modules
rm -f package-lock.json

# Install dependencies
npm install

# Create dist directory if it doesn't exist
mkdir -p dist

# Build the project
npm run build

echo "✅ Setup completed successfully!"
echo "You can now run the backend with: npm start"

