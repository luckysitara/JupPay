#!/bin/bash

# Exit on error
set -e

echo "Building BUX API for production..."

# Create logs directory
mkdir -p logs

# Remove previous build artifacts
rm -rf dist
rm -f package-lock.json

# Install dependencies
echo "Installing dependencies..."
npm install --production

# Build TypeScript
echo "Compiling TypeScript..."
npx tsc -p tsconfig.server.json

# Copy necessary files
echo "Copying configuration files..."
cp .env.example dist/.env.example
cp package.json dist/package.json

echo "✅ Production build completed successfully!"
echo "To run in production mode:"
echo "1. cd dist"
echo "2. cp .env.example .env"
echo "3. Edit .env with your production settings"
echo "4. NODE_ENV=production node app.js"

