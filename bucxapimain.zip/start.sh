#!/bin/bash

# Exit on error
set -e

echo "Starting BUX API server..."

# Check if the build exists
if [ ! -d "dist" ]; then
  echo "Build directory not found. Running build first..."
  npm run build
fi

# Start the server
node dist/app.js

