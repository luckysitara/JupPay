#!/bin/bash

# Exit on error
set -e

echo "Cleaning up Next.js related files and directories..."

# Remove Next.js related directories
rm -rf app
rm -rf .next
rm -rf public
rm -rf styles
rm -rf components
rm -rf hooks
rm -rf lib

# Remove Next.js related files
rm -f next.config.mjs
rm -f next-env.d.ts
rm -f postcss.config.mjs
rm -f tailwind.config.ts
rm -f components.json

# Remove package-lock.json and node_modules to ensure clean install
rm -f package-lock.json
rm -rf node_modules

echo "✅ Cleanup completed"

echo "Installing dependencies..."
npm install

echo "✅ Dependencies installed"

echo "Building the project..."
npm run build

echo "✅ Build completed"

echo "The project is now ready to run with: npm start"

