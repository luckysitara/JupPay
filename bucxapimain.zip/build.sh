#!/bin/bash

# Exit on error
set -e

echo "Building BUX API backend..."

# Clean up previous build
rm -rf dist
echo "✅ Cleaned up previous build"

# Install dependencies
npm ci
echo "✅ Installed dependencies"

# Build TypeScript
npm run build
echo "✅ Compiled TypeScript"

# Copy necessary files
cp package.json dist/
cp package-lock.json dist/
cp .env.example dist/
echo "✅ Copied necessary files"

echo "Build completed successfully!"
echo "To start the server, run: node dist/app.js"

