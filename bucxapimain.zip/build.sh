#!/bin/bash

# Exit on error
set -e

echo "Building BUX API backend..."

# Clean up previous build
rm -rf dist
mkdir -p dist

# Build TypeScript
npx tsc -p tsconfig.server.json

echo "✅ Build completed successfully!"

