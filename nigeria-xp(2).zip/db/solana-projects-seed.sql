-- Seed Solana blockchain projects
INSERT INTO projects (name, description, points, weekly_points, monthly_points, yearly_points, created_at, updated_at)
VALUES
  ('Solana Pay Integration', 'Implementation of Solana Pay for Nigerian merchants', 4800, 350, 1200, 4800, NOW() - INTERVAL '3 months', NOW()),
  ('Solana NFT Marketplace', 'A Nigerian-focused NFT marketplace built on Solana', 5600, 420, 1500, 5600, NOW() - INTERVAL '5 months', NOW()),
  ('Solana DeFi Dashboard', 'Analytics dashboard for Solana DeFi protocols', 4200, 280, 950, 4200, NOW() - INTERVAL '2 months', NOW()),
  ('Solana Wallet Adapter', 'Custom wallet adapter for Nigerian Solana users', 3800, 240, 850, 3800, NOW() - INTERVAL '4 months', NOW()),
  ('Solana Hackathon Projects', 'Collection of projects from Nigerian Solana Hackathons', 6200, 480, 1800, 6200, NOW() - INTERVAL '6 months', NOW()),
  ('Solana Education Portal', 'Educational resources for Solana development in Nigeria', 3500, 220, 780, 3500, NOW() - INTERVAL '1 month', NOW()),
  ('Solana Mobile dApp', 'Mobile application for Solana ecosystem access', 4100, 260, 920, 4100, NOW() - INTERVAL '3.5 months', NOW()),
  ('Solana Governance Tool', 'DAO governance tool for Nigerian Solana projects', 3900, 250, 880, 3900, NOW() - INTERVAL '2.5 months', NOW()),
  ('Solana Game Development', 'Blockchain gaming projects built on Solana', 5100, 400, 1400, 5100, NOW() - INTERVAL '7 months', NOW()),
  ('Solana Cross-Chain Bridge', 'Bridge connecting Solana to other blockchains for Nigerian users', 4700, 340, 1150, 4700, NOW() - INTERVAL '4.5 months', NOW());

