"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { supabase } from "@/lib/database"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle } from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  created_at: string
}

export default function AnalyticsPage() {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [timeRange, setTimeRange] = useState<"week" | "month" | "quarter" | "year">("month")
  const [stateDistribution, setStateDistribution] = useState<
    { state_code: string; state_name: string; count: number }[]
  >([])
  const [skillDistribution, setSkillDistribution] = useState<{ skill: string; count: number }[]>([])
  const [userGrowth, setUserGrowth] = useState<{ date: string; count: number }[]>([])
  const [xpDistribution, setXpDistribution] = useState<{ range: string; count: number }[]>([])

  useEffect(() => {
    const getAdminUser = async () => {
      try {
        // Get admin user from cookie
        const adminCookie = document.cookie.split("; ").find((row) => row.startsWith("adminUser="))

        if (!adminCookie) {
          setError("Not authenticated")
          return
        }

        const adminUserData = JSON.parse(adminCookie.split("=")[1])

        // Fetch the latest admin data from the database
        const { data, error } = await supabase.from("admin_users").select("*").eq("id", adminUserData.id).single()

        if (error) {
          throw error
        }

        setAdminUser(data as AdminUser)
      } catch (err) {
        console.error("Error fetching admin user:", err)
        setError("Failed to load admin data")
      } finally {
        setLoading(false)
      }
    }

    getAdminUser()
  }, [])

  useEffect(() => {
    if (!adminUser) return

    const fetchAnalyticsData = async () => {
      try {
        setLoading(true)

        // Get date range
        const startDate = new Date()
        switch (timeRange) {
          case "week":
            startDate.setDate(startDate.getDate() - 7)
            break
          case "month":
            startDate.setMonth(startDate.getMonth() - 1)
            break
          case "quarter":
            startDate.setMonth(startDate.getMonth() - 3)
            break
          case "year":
            startDate.setFullYear(startDate.getFullYear() - 1)
            break
        }

        // Fetch state distribution
        let stateQuery = supabase
          .from("users")
          .select(`
            state_code,
            states(name)
          `)
          .gt("created_at", startDate.toISOString())

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          stateQuery = stateQuery.eq("state_code", adminUser.state_code)
        }

        const { data: stateData } = await stateQuery

        if (stateData) {
          const stateCounts: Record<string, { count: number; name: string }> = {}

          stateData.forEach((user: any) => {
            const stateCode = user.state_code
            const stateName = user.states?.name || stateCode

            if (!stateCounts[stateCode]) {
              stateCounts[stateCode] = { count: 0, name: stateName }
            }

            stateCounts[stateCode].count++
          })

          const stateDistributionData = Object.entries(stateCounts).map(([code, data]) => ({
            state_code: code,
            state_name: data.name,
            count: data.count,
          }))

          // Sort by count descending
          stateDistributionData.sort((a, b) => b.count - a.count)

          setStateDistribution(stateDistributionData)
        }

        // Fetch skill distribution (from user skills)
        let skillQuery = supabase
          .from("user_skills")
          .select(`
            skill,
            created_at,
            users(state_code)
          `)
          .gt("created_at", startDate.toISOString())

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          skillQuery = skillQuery.eq("users.state_code", adminUser.state_code)
        }

        const { data: skillData } = await skillQuery

        if (skillData) {
          const skillCounts: Record<string, number> = {}

          skillData.forEach((entry: any) => {
            const skill = entry.skill

            if (!skillCounts[skill]) {
              skillCounts[skill] = 0
            }

            skillCounts[skill]++
          })

          const skillDistributionData = Object.entries(skillCounts).map(([skill, count]) => ({
            skill,
            count,
          }))

          // Sort by count descending
          skillDistributionData.sort((a, b) => b.count - a.count)

          setSkillDistribution(skillDistributionData.slice(0, 10))
        }

        // Fetch user growth over time
        let userQuery = supabase
          .from("users")
          .select(`
            created_at,
            state_code
          `)
          .gt("created_at", startDate.toISOString())
          .order("created_at")

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          userQuery = userQuery.eq("state_code", adminUser.state_code)
        }

        const { data: userData } = await userQuery

        if (userData) {
          const usersByDate: Record<string, number> = {}

          userData.forEach((user: any) => {
            // Format date based on time range
            let dateKey
            const date = new Date(user.created_at)

            switch (timeRange) {
              case "week":
                dateKey = date.toISOString().split("T")[0] // Daily
                break
              case "month":
                dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(Math.ceil(date.getDate() / 7)).padStart(2, "0")}` // Weekly
                break
              case "quarter":
                dateKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}` // Monthly
                break
              case "year":
                dateKey = `${date.getFullYear()}-Q${Math.ceil((date.getMonth() + 1) / 3)}` // Quarterly
                break
            }

            if (!usersByDate[dateKey]) {
              usersByDate[dateKey] = 0
            }

            usersByDate[dateKey]++
          })

          const userGrowthData = Object.entries(usersByDate).map(([date, count]) => ({
            date,
            count,
          }))

          // Sort by date
          userGrowthData.sort((a, b) => a.date.localeCompare(b.date))

          setUserGrowth(userGrowthData)
        }

        // Fetch XP distribution
        let xpQuery = supabase.from("users").select(`
            total_xp,
            state_code
          `)

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          xpQuery = xpQuery.eq("state_code", adminUser.state_code)
        }

        const { data: xpData } = await xpQuery

        if (xpData) {
          const xpRanges = [
            { min: 0, max: 100, label: "0-100" },
            { min: 101, max: 500, label: "101-500" },
            { min: 501, max: 1000, label: "501-1000" },
            { min: 1001, max: 5000, label: "1001-5000" },
            { min: 5001, max: Number.POSITIVE_INFINITY, label: "5000+" },
          ]

          const xpCounts: Record<string, number> = {}

          // Initialize counts
          xpRanges.forEach((range) => {
            xpCounts[range.label] = 0
          })

          xpData.forEach((user: any) => {
            const xp = user.total_xp || 0

            for (const range of xpRanges) {
              if (xp >= range.min && xp <= range.max) {
                xpCounts[range.label]++
                break
              }
            }
          })

          const xpDistributionData = Object.entries(xpCounts).map(([range, count]) => ({
            range,
            count,
          }))

          setXpDistribution(xpDistributionData)
        }
      } catch (error) {
        console.error("Error fetching analytics data:", error)
        setError("Failed to load analytics data")
      } finally {
        setLoading(false)
      }
    }

    fetchAnalyticsData()
  }, [adminUser, timeRange])

  if (loading && !adminUser) {
    return <AnalyticsSkeleton />
  }

  if (error) {
    return (
      <Alert variant="destructive" className="mt-4">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    )
  }

  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <h2 className="text-3xl font-bold tracking-tight">Analytics</h2>
        <p className="text-muted-foreground">
          {adminUser?.role === "super_admin"
            ? "Platform-wide analytics and insights"
            : `Analytics and insights for ${adminUser?.state_code}`}
        </p>
      </div>

      <div className="flex justify-end">
        <Tabs
          value={timeRange}
          onValueChange={(value) => setTimeRange(value as "week" | "month" | "quarter" | "year")}
          className="w-[400px]"
        >
          <TabsList className="grid grid-cols-4">
            <TabsTrigger value="week">Week</TabsTrigger>
            <TabsTrigger value="month">Month</TabsTrigger>
            <TabsTrigger value="quarter">Quarter</TabsTrigger>
            <TabsTrigger value="year">Year</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>User Growth</CardTitle>
            <CardDescription>New user registrations over time</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : userGrowth.length > 0 ? (
              <div className="h-[200px] w-full">
                <div className="flex h-full items-end space-x-2">
                  {userGrowth.map((item, index) => {
                    const maxCount = Math.max(...userGrowth.map((d) => d.count))
                    const height = (item.count / maxCount) * 100

                    return (
                      <div key={index} className="flex flex-col items-center flex-1">
                        <div className="w-full bg-primary rounded-t" style={{ height: `${height}%` }} />
                        <div className="text-xs text-muted-foreground mt-2 w-full text-center overflow-hidden text-ellipsis whitespace-nowrap">
                          {item.date}
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data available for the selected time range</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>XP Distribution</CardTitle>
            <CardDescription>Users grouped by XP ranges</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : xpDistribution.length > 0 ? (
              <div className="space-y-4">
                {xpDistribution.map((item) => {
                  const maxCount = Math.max(...xpDistribution.map((d) => d.count))
                  const percentage = maxCount > 0 ? (item.count / maxCount) * 100 : 0

                  return (
                    <div key={item.range} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{item.range} XP</p>
                        <p className="text-sm text-muted-foreground">{item.count} users</p>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data available</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>State Distribution</CardTitle>
            <CardDescription>Users by state</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : stateDistribution.length > 0 ? (
              <div className="space-y-4">
                {stateDistribution.slice(0, 10).map((item) => {
                  const maxCount = Math.max(...stateDistribution.map((d) => d.count))
                  const percentage = maxCount > 0 ? (item.count / maxCount) * 100 : 0

                  return (
                    <div key={item.state_code} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{item.state_name}</p>
                        <p className="text-sm text-muted-foreground">{item.count} users</p>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data available for the selected time range</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Skill Distribution</CardTitle>
            <CardDescription>Most common skills among users</CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <Skeleton className="h-[200px] w-full" />
            ) : skillDistribution.length > 0 ? (
              <div className="space-y-4">
                {skillDistribution.map((item) => {
                  const maxCount = Math.max(...skillDistribution.map((d) => d.count))
                  const percentage = maxCount > 0 ? (item.count / maxCount) * 100 : 0

                  return (
                    <div key={item.skill} className="space-y-1">
                      <div className="flex items-center justify-between">
                        <p className="text-sm font-medium">{item.skill}</p>
                        <p className="text-sm text-muted-foreground">{item.count} users</p>
                      </div>
                      <Progress value={percentage} className="h-2" />
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No data available for the selected time range</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function AnalyticsSkeleton() {
  return (
    <div className="flex flex-col space-y-6">
      <div className="flex flex-col space-y-2">
        <Skeleton className="h-8 w-[150px]" />
        <Skeleton className="h-4 w-[300px]" />
      </div>

      <div className="flex justify-end">
        <Skeleton className="h-10 w-[400px]" />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {Array(4)
          .fill(0)
          .map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-5 w-[150px]" />
                <Skeleton className="h-4 w-[250px]" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[200px] w-full" />
              </CardContent>
            </Card>
          ))}
      </div>
    </div>
  )
}

