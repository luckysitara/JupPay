-- Add sample users
INSERT INTO users (name, username, state, total_xp, monthly_xp, skills, joined_at) VALUES
('Oluwaseun Adebayo', 'seun_adebayo', 'LA', 26866, 700, ARRAY['Operations', 'Strategy', 'Development'], '2022-01-15T00:00:00Z'),
('Chioma Okonkwo', 'chioma_o', 'AB', 23965, 650, ARRAY['Operations', 'Strategy', 'Writing'], '2022-02-20T00:00:00Z'),
('Emeka Nwosu', 'emeka_n', 'EN', 23191, 800, ARRAY['Development', 'Operations', 'Strategy', 'Design'], '2022-03-10T00:00:00Z'),
('Amina Ibrahim', 'amina_i', 'KN', 21412, 500, ARRAY['Development', 'Operations'], '2022-04-05T00:00:00Z'),
('Tunde Bakare', 'tunde_b', 'OY', 20910, 750, ARRAY['Operations', 'Strategy', 'Writing'], '2022-05-12T00:00:00Z');

