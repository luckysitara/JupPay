"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"

type StateAdminDashboardProps = {
  stateCode: string
}

type TopUser = {
  id: string
  name: string
  avatar_url: string | null
  total_xp: number
}

export function StateAdminDashboard({ stateCode }: StateAdminDashboardProps) {
  const [topUsers, setTopUsers] = useState<TopUser[]>([])
  const [stateName, setStateName] = useState("")
  const [loading, setLoading] = useState(true)
  const [stateStats, setStateStats] = useState({
    totalXP: 0,
    averageXP: 0,
    userCount: 0,
    projectsCompleted: 0,
  })

  useEffect(() => {
    const fetchStateData = async () => {
      try {
        // Get state name
        const { data: stateData } = await supabase.from("states").select("name").eq("code", stateCode).single()

        if (stateData) {
          setStateName(stateData.name)
        }

        // Get top users in the state
        const { data: usersData } = await supabase
          .from("users")
          .select(`
            id,
            name,
            avatar_url,
            total_xp
          `)
          .eq("state_code", stateCode)
          .order("total_xp", { ascending: false })
          .limit(5)

        if (usersData) {
          setTopUsers(usersData as TopUser[])
        }

        // Get state stats
        const { data: usersCount } = await supabase
          .from("users")
          .select("*", { count: "exact", head: true })
          .eq("state_code", stateCode)

        const { data: xpData } = await supabase.from("users").select("total_xp").eq("state_code", stateCode)

        const { data: projectsData } = await supabase
          .from("project_submissions")
          .select("*", { count: "exact", head: true })
          .eq("state_code", stateCode)
          .eq("status", "completed")

        const totalXP = xpData?.reduce((sum, user) => sum + (user.total_xp || 0), 0) || 0
        const userCount = usersCount?.count || 0

        setStateStats({
          totalXP,
          averageXP: userCount > 0 ? Math.round(totalXP / userCount) : 0,
          userCount,
          projectsCompleted: projectsData?.count || 0,
        })
      } catch (error) {
        console.error("Error fetching state data:", error)
      } finally {
        setLoading(false)
      }
    }

    if (stateCode) {
      fetchStateData()
    }
  }, [stateCode])

  if (loading) {
    return <StateAdminDashboardSkeleton />
  }

  // Calculate the maximum XP for progress bars
  const maxXP = topUsers.length > 0 ? topUsers[0].total_xp : 1000

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>{stateName} Performance</CardTitle>
          <CardDescription>Key metrics for your state</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold">{stateStats.userCount}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Total XP</p>
                <p className="text-2xl font-bold">{stateStats.totalXP.toLocaleString()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Average XP</p>
                <p className="text-2xl font-bold">{stateStats.averageXP.toLocaleString()}</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium text-muted-foreground">Projects Completed</p>
                <p className="text-2xl font-bold">{stateStats.projectsCompleted}</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Top Performers</CardTitle>
          <CardDescription>Users with the highest XP in {stateName}</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topUsers.map((user) => (
              <div key={user.id} className="flex items-center space-x-4">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar_url || ""} alt={user.name} />
                  <AvatarFallback>{user.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium">{user.name}</p>
                    <p className="text-sm text-muted-foreground">{user.total_xp.toLocaleString()} XP</p>
                  </div>
                  <Progress value={(user.total_xp / maxXP) * 100} className="h-2" />
                </div>
              </div>
            ))}

            {topUsers.length === 0 && <p className="text-sm text-muted-foreground">No users found in this state</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function StateAdminDashboardSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-[180px]" />
          <Skeleton className="h-4 w-[250px]" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {Array(4)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="space-y-1">
                    <Skeleton className="h-4 w-[100px]" />
                    <Skeleton className="h-8 w-[80px]" />
                  </div>
                ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-[150px]" />
          <Skeleton className="h-4 w-[200px]" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="flex items-center space-x-4">
                  <Skeleton className="h-8 w-8 rounded-full" />
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center justify-between">
                      <Skeleton className="h-4 w-[100px]" />
                      <Skeleton className="h-4 w-[60px]" />
                    </div>
                    <Skeleton className="h-2 w-full" />
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

