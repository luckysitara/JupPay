"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"

type AdminUser = {
  id: string
  name: string
  email: string
  role: "super_admin" | "state_admin"
  state_code?: string
  created_at: string
}

type RecentActivityProps = {
  adminUser: AdminUser
}

type ActivityItem = {
  id: string
  type: "xp_transaction" | "project_submission" | "user_created" | "admin_action"
  user_name: string
  user_avatar?: string
  description: string
  timestamp: string
  amount?: number
  state_code?: string
}

export function RecentActivity({ adminUser }: RecentActivityProps) {
  const [activities, setActivities] = useState<ActivityItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchRecentActivity = async () => {
      try {
        // Get recent XP transactions
        let xpQuery = supabase
          .from("xp_transactions")
          .select(`
            id,
            amount,
            description,
            created_at,
            users(name, avatar_url),
            state_code
          `)
          .order("created_at", { ascending: false })
          .limit(10)

        // For state admins, filter by state
        if (adminUser.role === "state_admin" && adminUser.state_code) {
          xpQuery = xpQuery.eq("state_code", adminUser.state_code)
        }

        const { data: xpData, error: xpError } = await xpQuery

        if (xpError) {
          throw xpError
        }

        // Get recent project submissions
        let projectQuery = supabase
          .from("project_submissions")
          .select(`
            id,
            status,
            created_at,
            users(name, avatar_url),
            projects(name),
            state_code
          `)
          .order("created_at", { ascending: false })
          .limit(5)

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          projectQuery = projectQuery.eq("state_code", adminUser.state_code)
        }

        const { data: projectData, error: projectError } = await projectQuery

        if (projectError) {
          throw projectError
        }

        // Get recent admin actions
        let adminActionQuery = supabase
          .from("admin_actions")
          .select(`
            id,
            action_type,
            description,
            created_at,
            admin_users(name)
          `)
          .order("created_at", { ascending: false })
          .limit(5)

        if (adminUser.role === "state_admin" && adminUser.state_code) {
          adminActionQuery = adminActionQuery.eq("state_code", adminUser.state_code)
        }

        const { data: adminActionData, error: adminActionError } = await adminActionQuery

        if (adminActionError) {
          throw adminActionError
        }

        // Format XP transactions
        const xpActivities =
          xpData?.map((tx: any) => ({
            id: `xp-${tx.id}`,
            type: "xp_transaction" as const,
            user_name: tx.users?.name || "Unknown User",
            user_avatar: tx.users?.avatar_url,
            description: tx.description || "Earned XP",
            timestamp: tx.created_at,
            amount: tx.amount,
            state_code: tx.state_code,
          })) || []

        // Format project submissions
        const projectActivities =
          projectData?.map((submission: any) => ({
            id: `project-${submission.id}`,
            type: "project_submission" as const,
            user_name: submission.users?.name || "Unknown User",
            user_avatar: submission.users?.avatar_url,
            description: `${submission.status === "completed" ? "Completed" : "Submitted"} project: ${submission.projects?.name || "Unknown Project"}`,
            timestamp: submission.created_at,
            state_code: submission.state_code,
          })) || []

        // Format admin actions
        const adminActivities =
          adminActionData?.map((action: any) => ({
            id: `admin-${action.id}`,
            type: "admin_action" as const,
            user_name: action.admin_users?.name || "Unknown Admin",
            description: action.description || action.action_type,
            timestamp: action.created_at,
          })) || []

        // Combine and sort by timestamp
        const allActivities = [...xpActivities, ...projectActivities, ...adminActivities]
          .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
          .slice(0, 20)

        setActivities(allActivities)
      } catch (error) {
        console.error("Error fetching recent activity:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchRecentActivity()
  }, [adminUser])

  if (loading) {
    return <ActivitySkeleton />
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
        <CardDescription>
          {adminUser.role === "super_admin"
            ? "Recent activity across the platform"
            : `Recent activity in ${adminUser.state_code}`}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {activities.map((activity) => (
            <div key={activity.id} className="flex items-start space-x-4 border-b pb-4 last:border-0 last:pb-0">
              <Avatar className="h-8 w-8">
                {activity.user_avatar ? <AvatarImage src={activity.user_avatar} alt={activity.user_name} /> : null}
                <AvatarFallback>{activity.user_name.substring(0, 2).toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{activity.user_name}</p>
                  <p className="text-xs text-muted-foreground">{new Date(activity.timestamp).toLocaleString()}</p>
                </div>
                <p className="text-sm text-muted-foreground">{activity.description}</p>
                {activity.type === "xp_transaction" && activity.amount && (
                  <p className="text-sm font-medium text-green-600">+{activity.amount} XP</p>
                )}
                {activity.state_code && adminUser.role === "super_admin" && (
                  <p className="text-xs text-muted-foreground">State: {activity.state_code}</p>
                )}
              </div>
            </div>
          ))}

          {activities.length === 0 && <p className="text-sm text-muted-foreground">No recent activity</p>}
        </div>
      </CardContent>
    </Card>
  )
}

function ActivitySkeleton() {
  return (
    <Card>
      <CardHeader>
        <Skeleton className="h-5 w-[150px]" />
        <Skeleton className="h-4 w-[250px]" />
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {Array(5)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="flex items-start space-x-4 border-b pb-4 last:border-0 last:pb-0">
                <Skeleton className="h-8 w-8 rounded-full" />
                <div className="flex-1 space-y-1">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-[120px]" />
                    <Skeleton className="h-3 w-[100px]" />
                  </div>
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-[80px]" />
                </div>
              </div>
            ))}
        </div>
      </CardContent>
    </Card>
  )
}

