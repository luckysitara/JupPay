"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { supabase } from "@/lib/database"
import { Progress } from "@/components/ui/progress"
import { Skeleton } from "@/components/ui/skeleton"

type StatePerformance = {
  state_code: string
  state_name: string
  total_users: number
  total_xp: number
  projects_completed: number
}

export function SuperAdminDashboard() {
  const [statePerformance, setStatePerformance] = useState<StatePerformance[]>([])
  const [loading, setLoading] = useState(true)
  const [recentAdmins, setRecentAdmins] = useState<any[]>([])

  useEffect(() => {
    const fetchSuperAdminData = async () => {
      try {
        // Get all states
        const { data: statesData } = await supabase.from("states").select("code, name").order("name")

        if (!statesData) {
          return
        }

        // For each state, get performance metrics
        const stateMetrics = await Promise.all(
          statesData.map(async (state) => {
            // Get user count
            const { count: userCount } = await supabase
              .from("users")
              .select("*", { count: "exact", head: true })
              .eq("state_code", state.code)

            // Get total XP
            const { data: xpData } = await supabase.from("users").select("total_xp").eq("state_code", state.code)

            const totalXP = xpData?.reduce((sum, user) => sum + (user.total_xp || 0), 0) || 0

            // Get projects completed
            const { count: projectsCompleted } = await supabase
              .from("project_submissions")
              .select("*", { count: "exact", head: true })
              .eq("state_code", state.code)
              .eq("status", "completed")

            return {
              state_code: state.code,
              state_name: state.name,
              total_users: userCount || 0,
              total_xp: totalXP,
              projects_completed: projectsCompleted || 0,
            }
          }),
        )

        // Sort by total XP descending
        stateMetrics.sort((a, b) => b.total_xp - a.total_xp)

        setStatePerformance(stateMetrics)

        // Get recently added admins
        const { data: adminsData } = await supabase
          .from("admin_users")
          .select("id, name, email, role, state_code, created_at")
          .order("created_at", { ascending: false })
          .limit(5)

        if (adminsData) {
          // Fetch state names for state admins
          const adminsWithStateNames = await Promise.all(
            adminsData.map(async (admin) => {
              if (admin.role === "state_admin" && admin.state_code) {
                const { data: stateData } = await supabase
                  .from("states")
                  .select("name")
                  .eq("code", admin.state_code)
                  .single()

                return {
                  ...admin,
                  state_name: stateData?.name || admin.state_code,
                }
              }

              return admin
            }),
          )

          setRecentAdmins(adminsWithStateNames)
        }
      } catch (error) {
        console.error("Error fetching super admin data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchSuperAdminData()
  }, [])

  if (loading) {
    return <SuperAdminDashboardSkeleton />
  }

  // Calculate the maximum XP for progress bars
  const maxXP = statePerformance.length > 0 ? statePerformance[0].total_xp : 1000

  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>State Performance</CardTitle>
          <CardDescription>XP distribution across states</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {statePerformance.slice(0, 10).map((state) => (
              <div key={state.state_code} className="space-y-1">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium">{state.state_name}</p>
                  <p className="text-sm text-muted-foreground">{state.total_xp.toLocaleString()} XP</p>
                </div>
                <Progress value={(state.total_xp / maxXP) * 100} className="h-2" />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{state.total_users} users</span>
                  <span>{state.projects_completed} projects completed</span>
                </div>
              </div>
            ))}

            {statePerformance.length === 0 && <p className="text-sm text-muted-foreground">No state data available</p>}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Admins</CardTitle>
          <CardDescription>Recently added administrators</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentAdmins.map((admin) => (
              <div key={admin.id} className="border-b pb-3 last:border-0 last:pb-0">
                <div className="flex justify-between">
                  <div>
                    <p className="font-medium">{admin.name}</p>
                    <p className="text-sm text-muted-foreground">{admin.email}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">
                      {admin.role === "super_admin" ? "Super Admin" : `${admin.state_name} Admin`}
                    </p>
                    <p className="text-xs text-muted-foreground">{new Date(admin.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            ))}

            {recentAdmins.length === 0 && <p className="text-sm text-muted-foreground">No recent admins</p>}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function SuperAdminDashboardSkeleton() {
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-[180px]" />
          <Skeleton className="h-4 w-[250px]" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-[120px]" />
                    <Skeleton className="h-4 w-[60px]" />
                  </div>
                  <Skeleton className="h-2 w-full" />
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-3 w-[60px]" />
                    <Skeleton className="h-3 w-[80px]" />
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <Skeleton className="h-5 w-[150px]" />
          <Skeleton className="h-4 w-[200px]" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {Array(5)
              .fill(0)
              .map((_, i) => (
                <div key={i} className="border-b pb-3 last:border-0 last:pb-0">
                  <div className="flex justify-between">
                    <div>
                      <Skeleton className="h-4 w-[120px]" />
                      <Skeleton className="h-3 w-[180px] mt-1" />
                    </div>
                    <div className="text-right">
                      <Skeleton className="h-4 w-[100px]" />
                      <Skeleton className="h-3 w-[80px] mt-1" />
                    </div>
                  </div>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

