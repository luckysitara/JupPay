"use client"

import { useState } from "react"
import { getAdminUser } from "@/lib/auth"
import { supabase } from "@/lib/database"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import type { User } from "@/types"

const formSchema = z.object({
  amount: z.coerce.number().positive("Amount must be positive").int("Amount must be a whole number"),
  reason: z.string().min(5, "Reason must be at least 5 characters"),
  skills: z.string().optional(),
})

type FormValues = z.infer<typeof formSchema>

interface AdminAssignXpDialogProps {
  user: User
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function AdminAssignXpDialog({ user, open, onOpenChange }: AdminAssignXpDialogProps) {
  const [submitting, setSubmitting] = useState(false)
  const { toast } = useToast()
  const admin = getAdminUser()

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      amount: 0,
      reason: "",
      skills: "",
    },
  })

  async function onSubmit(values: FormValues) {
    if (!admin) {
      toast({
        title: "Error",
        description: "You must be logged in to assign XP",
        variant: "destructive",
      })
      return
    }

    try {
      setSubmitting(true)

      // Parse skills from comma-separated string
      const skills = values.skills
        ? values.skills
            .split(",")
            .map((skill) => skill.trim())
            .filter(Boolean)
        : []

      // Insert XP transaction
      const { error: insertError } = await supabase.from("xp_transactions").insert({
        user_id: user.id,
        admin_id: admin.id,
        amount: values.amount,
        reason: values.reason,
        skills,
      })

      if (insertError) throw insertError

      toast({
        title: "XP Assigned",
        description: `${values.amount} XP assigned to ${user.name}`,
      })

      // Reset form and close dialog
      form.reset()
      onOpenChange(false)
    } catch (error) {
      console.error("Error assigning XP:", error)
      toast({
        title: "Error",
        description: "Failed to assign XP. Please try again.",
        variant: "destructive",
      })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Assign XP to {user.name}</DialogTitle>
          <DialogDescription>Award XP points for contributions and achievements</DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="amount"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>XP Amount</FormLabel>
                  <FormControl>
                    <Input type="number" min="1" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="reason"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Reason</FormLabel>
                  <FormControl>
                    <Textarea placeholder="Describe the contribution or achievement" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="skills"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Skills (comma-separated)</FormLabel>
                  <FormControl>
                    <Input placeholder="Development, Design, Writing" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button type="submit" disabled={submitting}>
                {submitting ? "Assigning..." : "Assign XP"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  )
}

