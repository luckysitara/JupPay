"use client"

import { useEffect, useRef } from "react"

interface BlockchainAnimationProps {
  className?: string
}

export function BlockchainAnimation({ className = "" }: BlockchainAnimationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas dimensions
    const setCanvasDimensions = () => {
      canvas.width = canvas.clientWidth
      canvas.height = canvas.clientHeight
    }

    setCanvasDimensions()
    window.addEventListener("resize", setCanvasDimensions)

    // Animation parameters
    const nodes: { x: number; y: number; size: number; speed: number }[] = []
    const connections: { from: number; to: number; opacity: number }[] = []
    const nodeCount = 15
    const connectionDistance = 150

    // Create nodes
    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 2,
        speed: Math.random() * 0.5 + 0.1,
      })
    }

    // Create connections
    for (let i = 0; i < nodeCount; i++) {
      for (let j = i + 1; j < nodeCount; j++) {
        connections.push({
          from: i,
          to: j,
          opacity: 0,
        })
      }
    }

    // Animation loop
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      // Update and draw connections
      connections.forEach((connection) => {
        const fromNode = nodes[connection.from]
        const toNode = nodes[connection.to]
        const dx = toNode.x - fromNode.x
        const dy = toNode.y - fromNode.y
        const distance = Math.sqrt(dx * dx + dy * dy)

        if (distance < connectionDistance) {
          connection.opacity = 1 - distance / connectionDistance
          ctx.beginPath()
          ctx.moveTo(fromNode.x, fromNode.y)
          ctx.lineTo(toNode.x, toNode.y)
          ctx.strokeStyle = `rgba(138, 43, 226, ${connection.opacity * 0.5})`
          ctx.lineWidth = 1
          ctx.stroke()
        } else {
          connection.opacity = 0
        }
      })

      // Update and draw nodes
      nodes.forEach((node, index) => {
        // Move nodes
        node.x += Math.sin(Date.now() * 0.001 + index) * node.speed
        node.y += Math.cos(Date.now() * 0.001 + index) * node.speed

        // Bounce off edges
        if (node.x < 0 || node.x > canvas.width) node.speed *= -1
        if (node.y < 0 || node.y > canvas.height) node.speed *= -1

        // Keep nodes within bounds
        node.x = Math.max(0, Math.min(canvas.width, node.x))
        node.y = Math.max(0, Math.min(canvas.height, node.y))

        // Draw node
        ctx.beginPath()
        ctx.arc(node.x, node.y, node.size, 0, Math.PI * 2)
        ctx.fillStyle = index % 3 === 0 ? "#9945FF" : index % 3 === 1 ? "#14F195" : "#00C2FF"
        ctx.fill()
      })

      requestAnimationFrame(animate)
    }

    animate()

    return () => {
      window.removeEventListener("resize", setCanvasDimensions)
    }
  }, [])

  return <canvas ref={canvasRef} className={`w-full h-full ${className}`} />
}

