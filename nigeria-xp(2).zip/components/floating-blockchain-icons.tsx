"use client"

import { useEffect, useState } from "react"

interface Icon {
  id: number
  icon: string
  x: number
  y: number
  size: number
  speed: number
  opacity: number
}

export function FloatingBlockchainIcons() {
  const [icons, setIcons] = useState<Icon[]>([])

  useEffect(() => {
    // Create initial icons
    const initialIcons: Icon[] = []
    const iconTypes = ["₿", "◎", "Ξ"] // Bitcoin, Solana, Ethereum symbols

    for (let i = 0; i < 15; i++) {
      initialIcons.push({
        id: i,
        icon: iconTypes[Math.floor(Math.random() * iconTypes.length)],
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: Math.random() * 1.5 + 0.5,
        speed: Math.random() * 0.5 + 0.1,
        opacity: Math.random() * 0.5 + 0.1,
      })
    }

    setIcons(initialIcons)

    // Animation interval
    const interval = setInterval(() => {
      setIcons((prevIcons) =>
        prevIcons.map((icon) => {
          // Move icons
          let newY = icon.y - icon.speed
          let newOpacity = icon.opacity

          // Reset position when icon goes off screen
          if (newY < -10) {
            newY = 110
            newOpacity = Math.random() * 0.5 + 0.1
          }

          return {
            ...icon,
            y: newY,
            opacity: newOpacity,
          }
        }),
      )
    }, 50)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden">
      {icons.map((icon) => (
        <div
          key={icon.id}
          className="absolute text-primary"
          style={{
            left: `${icon.x}%`,
            top: `${icon.y}%`,
            fontSize: `${icon.size}rem`,
            opacity: icon.opacity,
            transform: `rotate(${Math.random() * 360}deg)`,
          }}
        >
          {icon.icon}
        </div>
      ))}
    </div>
  )
}

