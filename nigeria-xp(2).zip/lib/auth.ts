import { supabase, isSupabaseConfigured } from "@/lib/database"
import type { AdminUser } from "@/types"

// Table and column names - can be customized if your schema is different
// We'll try multiple table names
const POSSIBLE_ADMIN_TABLES = ["admin_users", "admin", "admins", "adminusers", "admin_user"]
const SECRET_KEY_COLUMN = "secret_key"

// Add this function to generate secure keys for admin users
export function generateSecureKey(length = 16): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_"
  let result = ""
  const randomValues = new Uint8Array(length)

  // Use crypto.getRandomValues if available (browser)
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(randomValues)
  } else {
    // Fallback for environments without crypto.getRandomValues
    for (let i = 0; i < length; i++) {
      randomValues[i] = Math.floor(Math.random() * 256)
    }
  }

  for (let i = 0; i < length; i++) {
    result += chars.charAt(randomValues[i] % chars.length)
  }

  return result
}

// Completely rewritten authentication function to handle the specific error
export async function authenticateWithSecretKey(secretKey: string): Promise<{
  user: AdminUser | null
  error: Error | null
}> {
  try {
    console.log("Starting authentication process")

    // Validate input
    if (!secretKey || secretKey.trim() === "") {
      console.log("Empty secret key provided")
      return { user: null, error: new Error("Secret key is required") }
    }

    // Trim the secret key to remove any accidental whitespace
    const trimmedKey = secretKey.trim()
    console.log(`Secret key length after trimming: ${trimmedKey.length}`)

    // Check if Supabase is configured
    if (!isSupabaseConfigured()) {
      console.log("Supabase not configured, using demo authentication")
      // Demo authentication logic
      if (trimmedKey === "demo-super-admin") {
        console.log("Using demo super admin account")
        const mockAdmin: AdminUser = {
          id: "mock-super-admin-id",
          email: "admin@superteamng.com",
          name: "Demo Super Admin",
          role: "SUPER_ADMIN",
          state: null,
          secret_key: "demo-super-admin",
        }

        localStorage.setItem("adminUser", JSON.stringify(mockAdmin))
        document.cookie = `adminUser=${JSON.stringify(mockAdmin)}; path=/; max-age=86400; SameSite=Strict`
        return { user: mockAdmin, error: null }
      }

      if (trimmedKey === "demo-lagos-admin") {
        console.log("Using demo Lagos admin account")
        const mockAdmin: AdminUser = {
          id: "mock-state-admin-id",
          email: "lagos@superteamng.com",
          name: "Demo Lagos Admin",
          role: "STATE_ADMIN",
          state: "LA",
          secret_key: "demo-lagos-admin",
        }

        localStorage.setItem("adminUser", JSON.stringify(mockAdmin))
        document.cookie = `adminUser=${JSON.stringify(mockAdmin)}; path=/; max-age=86400; SameSite=Strict`
        return { user: mockAdmin, error: null }
      }

      console.log("Invalid demo key provided")
      return {
        user: null,
        error: new Error("Invalid secret key"),
      }
    }

    console.log("Supabase is configured, attempting database authentication")

    try {
      // First check if we can connect to the database at all
      const { error: connectionError } = await supabase.from("states").select("code").limit(1)

      if (connectionError) {
        console.error("Database connection error:", connectionError)
        return {
          user: null,
          error: new Error(`Database connection failed: ${connectionError.message}`),
        }
      }

      // Try to authenticate with the provided secret key
      console.log("Querying admin_users table with secret key")
      const { data, error } = await supabase.from("admin_users").select("*").eq("secret_key", trimmedKey).limit(1)

      if (error) {
        console.error("Database query error:", error)
        return {
          user: null,
          error: new Error(`Database query failed: ${error.message}`),
        }
      }

      if (!data || data.length === 0) {
        console.log("No matching admin user found")
        return { user: null, error: new Error("Invalid secret key or admin user not found") }
      }

      const userData = data[0]
      console.log(`Found admin user: ${userData.email || userData.name || "unknown"}`)

      // Transform to AdminUser type
      const adminUser: AdminUser = {
        id: userData.id,
        email: userData.email,
        name: userData.name,
        role: userData.role,
        state: userData.state,
        secret_key: userData.secret_key,
      }

      // Store the admin user in localStorage for persistence
      localStorage.setItem("adminUser", JSON.stringify(adminUser))

      // Also store in cookie for server-side authentication
      document.cookie = `adminUser=${JSON.stringify(adminUser)}; path=/; max-age=86400; SameSite=Strict`

      console.log("Authentication successful")

      return { user: adminUser, error: null }
    } catch (dbErr) {
      console.error("Database operation error:", dbErr)
      return { user: null, error: dbErr instanceof Error ? dbErr : new Error("Database operation failed") }
    }
  } catch (err) {
    console.error("Authentication error:", err)
    return { user: null, error: err instanceof Error ? err : new Error("Authentication failed") }
  }
}

export function getAdminUser(): AdminUser | null {
  if (typeof window === "undefined") return null

  const adminUserJson = localStorage.getItem("adminUser")
  if (!adminUserJson) return null

  try {
    return JSON.parse(adminUserJson) as AdminUser
  } catch {
    return null
  }
}

export function logout() {
  if (typeof window === "undefined") return
  localStorage.removeItem("adminUser")
  document.cookie = "adminUser=; path=/; max-age=0; SameSite=Strict"
}

export function isAuthenticated(): boolean {
  return getAdminUser() !== null
}

export function isStateAdmin(stateCode?: string): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "STATE_ADMIN" && (!stateCode || admin.state === stateCode)
}

export function isSuperAdmin(): boolean {
  const admin = getAdminUser()
  if (!admin) return false
  return admin.role === "SUPER_ADMIN"
}

