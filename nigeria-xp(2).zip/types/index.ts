export interface User {
  id: string
  name: string
  username: string
  state: string
  stateName: string
  totalXp: number
  monthlyXp: number
  skills: string[]
  joinedAt: Date
  walletAddress?: string | null
}

export interface AdminUser {
  id: string
  email: string
  name: string
  role: "SUPER_ADMIN" | "STATE_ADMIN"
  state?: string | null
  secret_key: string
}

export interface XpTransaction {
  id: string
  userId: string
  adminId: string
  amount: number
  reason: string
  skills: string[]
  createdAt: Date
}

export interface Project {
  id: string
  name: string
  description: string | null
  points: number
  weeklyPoints: number
  monthlyPoints: number
  yearlyPoints: number
  createdAt: Date
  updatedAt: Date
}

export interface ProjectContribution {
  id: string
  projectId: string
  userId: string
  adminId: string
  points: number
  reason: string
  createdAt: Date
}

export interface State {
  code: string
  name: string
}

export type AdminRole = "SUPER_ADMIN" | "STATE_ADMIN"

export type TimeFilter = "all" | "weekly" | "monthly" | "yearly"

