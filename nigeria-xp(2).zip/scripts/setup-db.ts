import { createClient } from "@supabase/supabase-js"
import fs from "fs"
import path from "path"

async function setupDatabase() {
  // Load environment variables
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    console.error("Missing environment variables. Please set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY")
    process.exit(1)
  }

  // Create Supabase client with service role key
  const supabase = createClient(supabaseUrl, supabaseServiceKey)

  try {
    console.log("Setting up database...")

    // Read schema SQL file
    const schemaPath = path.join(process.cwd(), "db", "schema.sql")
    const schemaSql = fs.readFileSync(schemaPath, "utf8")

    // Execute schema SQL
    console.log("Creating tables and functions...")
    const { error: schemaError } = await supabase.rpc("exec_sql", { sql: schemaSql })

    if (schemaError) {
      throw new Error(`Error creating schema: ${schemaError.message}`)
    }

    // Read seed SQL file
    const seedPath = path.join(process.cwd(), "db", "seed.sql")
    const seedSql = fs.readFileSync(seedPath, "utf8")

    // Execute seed SQL
    console.log("Seeding database...")
    const { error: seedError } = await supabase.rpc("exec_sql", { sql: seedSql })

    if (seedError) {
      throw new Error(`Error seeding database: ${seedError.message}`)
    }

    console.log("Database setup completed successfully!")
  } catch (error) {
    console.error("Error setting up database:", error)
    process.exit(1)
  }
}

setupDatabase()

